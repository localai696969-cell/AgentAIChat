import 'dart:convert';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../providers/chat_provider.dart';
import '../../models/provider_config.dart';
import '../../services/api_service.dart';
import '../../services/export/code_zip_export.dart';
import '../../services/github_build_service.dart';
import '../../utils/file_saver.dart';
import '../../utils/quick_syntax_check.dart';

/// Cho phép upload 1 file .zip source code BẤT KỲ (không nhất thiết là dự án
/// do chính app này tạo ra), rồi có 2 CÁCH để lấy bản sửa:
///
///  CÁCH 1 — AI trong app tự sửa: chọn file cần xem, gõ yêu cầu, 1 lần gọi
///  API, nhận lại + tải zip ngay.
///
///  CÁCH 2 — đã nhờ 1 nơi khác (AI khác, hoặc 1 người khác) sửa giúp: bấm
///  "Copy nội dung" để lấy toàn bộ file đã chọn dưới dạng text (đúng cú
///  pháp ```đường/dẫn/file``` mà [CodeZipExporter] hiểu được) rồi tự gửi đi
///  bằng bất kỳ cách nào (dán vào WebviewCaptureScreen, gửi qua app khác...);
///  khi có kết quả trả về, dán ngược lại vào ô "Kết quả đã sửa" rồi bấm
///  "Ghép & tải zip" — bước này KHÔNG gọi API của app (0 token), vì việc
///  sửa đã do bên ngoài làm.
///
/// Cả 2 cách đều tái dùng đúng cú pháp
/// ```đường/dẫn/file.ext ... ``` mà [CodeZipExporter] đã hỗ trợ sẵn, và chỉ
/// merge những file thay đổi/thêm mới với các file gốc không đổi.
///
/// Chỉ các file dạng text (đuôi phổ biến: dart/yaml/json/md/kts/gradle/xml/
/// html/js/css/txt/gitignore/properties) được đưa vào ngữ cảnh — file nhị
/// phân (ảnh, font, .g.dart quá dài, ...) bị bỏ qua để tránh vỡ encoding và
/// tốn token vô ích. Người dùng tick chọn thêm/bớt nếu cần.
///
/// [initialBytes]/[initialName]: cho phép nạp sẵn 1 file .zip đã tải về từ
/// nơi khác (ví dụ vừa tải bằng link download trong WebviewCaptureScreen),
/// bỏ qua bước phải tự chọn file lại lần 2.
class ZipEditScreen extends StatefulWidget {
  final Uint8List? initialBytes;
  final String? initialName;
  const ZipEditScreen({super.key, this.initialBytes, this.initialName});

  @override
  State<ZipEditScreen> createState() => _ZipEditScreenState();
}

const _textExtensions = {
  'dart', 'yaml', 'yml', 'json', 'md', 'kts', 'gradle', 'xml', 'html', 'js',
  'css', 'txt', 'properties', 'gitignore', 'toml', 'lock', 'sh',
};

class _ZipEditScreenState extends State<ZipEditScreen> {
  Map<String, String> _allFiles = {}; // path -> nội dung text
  final Set<String> _skippedBinary = {};
  final Set<String> _selectedPaths = {};
  final _instructionController = TextEditingController();
  final _externalResultController = TextEditingController();
  String? _zipName;
  bool _busy = false;
  bool _autoBuildBusy = false;

  @override
  void initState() {
    super.initState();
    if (widget.initialBytes != null) {
      // Đợi 1 frame để context/Provider sẵn sàng trước khi có thể show SnackBar.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _loadZipBytes(widget.initialBytes!, widget.initialName ?? 'downloaded.zip');
      });
    }
  }

  void _loadZipBytes(Uint8List bytes, String name) {
    final archive = ZipDecoder().decodeBytes(bytes);
    final files = <String, String>{};
    final skipped = <String>{};
    for (final entry in archive) {
      if (!entry.isFile) continue;
      final ext = entry.name.contains('.') ? entry.name.split('.').last.toLowerCase() : '';
      if (_textExtensions.contains(ext)) {
        try {
          files[entry.name] = utf8.decode(entry.content as List<int>, allowMalformed: true);
        } catch (_) {
          skipped.add(entry.name);
        }
      } else {
        skipped.add(entry.name);
      }
    }
    setState(() {
      _zipName = name;
      _allFiles = files;
      _skippedBinary
        ..clear()
        ..addAll(skipped);
      _selectedPaths
        ..clear()
        ..addAll(files.keys);
    });
  }

  Future<void> _pickZip() async {
    const typeGroup = XTypeGroup(label: 'zip', extensions: ['zip']);
    final f = await openFile(acceptedTypeGroups: [typeGroup]);
    if (f == null) return;
    final bytes = await f.readAsBytes();
    _loadZipBytes(bytes, f.name);
  }

  Future<void> _copySelectedForSharing() async {
    if (_selectedPaths.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chọn ít nhất 1 file để copy.')),
      );
      return;
    }
    final selected = {for (final p in _selectedPaths) p: _allFiles[p]!};
    final text = CodeZipExporter.formatForSharing(selected);
    await Clipboard.setData(ClipboardData(text: text));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(
          'Đã copy ${_selectedPaths.length} file (${text.length} ký tự) vào clipboard — '
          'dán vào đâu cũng được: AI khác, ô chat trong WebView (nút 📋 Dán nội dung), v.v.',
        )),
      );
    }
  }

  /// Ghép kết quả ĐÃ ĐƯỢC SỬA SẴN từ bên ngoài (1 AI khác, hoặc 1 người
  /// khác) thành zip hoàn chỉnh — KHÔNG gọi API của app (0 token), vì việc
  /// đọc/sửa đã do bên ngoài làm; app chỉ parse lại đúng cú pháp
  /// ```đường/dẫn/file``` và merge với file gốc không đổi.
  Future<void> _mergeExternalResult() async {
    final text = _externalResultController.text;
    if (text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Dán kết quả đã sửa vào ô bên trên trước.')),
      );
      return;
    }
    final changed = CodeZipExporter.extractFiles(text);
    if (changed.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
            'Không đọc được file nào — kết quả cần đúng cú pháp ```đường/dẫn/file.ext ... ```.',
          ),
          duration: const Duration(seconds: 8),
          action: SnackBarAction(
            label: 'Copy prompt định dạng',
            onPressed: () {
              Clipboard.setData(const ClipboardData(text: CodeZipExporter.formatInstructionPrompt));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text(
                  'Đã copy — dán gửi lại cho bên kia (AI khác/người khác), nhờ họ trả lời lại đúng định dạng này.',
                )),
              );
            },
          ),
        ),
      );
      return;
    }
    final merged = Map<String, String>.from(_allFiles)..addAll(changed);
    final zipBytes = CodeZipExporter.export(
      merged,
      readmeExtra: '# Đã chỉnh sửa từ bên ngoài (không qua AI trong app)\n\n'
          'Các file thay đổi/thêm mới: ${changed.keys.join(', ')}',
    );
    final outName = _zipName != null
        ? '${_zipName!.replaceAll('.zip', '')}_edited_${DateTime.now().millisecondsSinceEpoch}.zip'
        : 'source_edited_${DateTime.now().millisecondsSinceEpoch}.zip';
    await FileSaver.saveAndShare(zipBytes, outName);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Đã ghép ${changed.length} file, tải về "$outName".')),
      );
    }
  }

  /// Mở dialog nhập/sửa cấu hình GitHub (PAT, owner, repo, branch, tên file
  /// workflow) — lưu vào `chat.storage` (Hive box "settings", xem
  /// [StorageService.githubToken] v.v.), dùng lại cho các lần build sau.
  Future<void> _openGithubSettingsDialog(ChatProvider chat) async {
    final tokenCtrl = TextEditingController(text: chat.storage.githubToken ?? '');
    final ownerCtrl = TextEditingController(text: chat.storage.githubOwner ?? '');
    final repoCtrl = TextEditingController(text: chat.storage.githubRepo ?? '');
    final branchCtrl = TextEditingController(text: chat.storage.githubBranch);
    final workflowCtrl = TextEditingController(text: chat.storage.githubWorkflowFile);

    final saved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Cấu hình GitHub Actions'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Repo đích PHẢI đã tồn tại sẵn và đã có file '
                '.github/workflows/<tên_file_workflow> (ví dụ đúng project này '
                'đã có sẵn build_apk.yml). Token cần quyền "repo" + "workflow", '
                'lưu ở cùng mức bảo mật với API key AI (Hive local, không mã hoá riêng).',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: tokenCtrl,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'GitHub Personal Access Token', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: ownerCtrl,
                decoration: const InputDecoration(labelText: 'Owner (user/tổ chức)', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: repoCtrl,
                decoration: const InputDecoration(labelText: 'Tên repo', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: branchCtrl,
                decoration: const InputDecoration(labelText: 'Branch', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: workflowCtrl,
                decoration: const InputDecoration(labelText: 'Tên file workflow', border: OutlineInputBorder()),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Huỷ')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Lưu')),
        ],
      ),
    );

    if (saved == true) {
      chat.storage.githubToken = tokenCtrl.text.trim();
      chat.storage.githubOwner = ownerCtrl.text.trim();
      chat.storage.githubRepo = repoCtrl.text.trim();
      chat.storage.githubBranch = branchCtrl.text.trim();
      chat.storage.githubWorkflowFile = workflowCtrl.text.trim();
    }
  }

  /// CÁCH 3 — dispatcher: hỏi chọn chế độ trước khi chạy.
  Future<void> _runAutoBuild(ChatProvider chat) async {
    if (_selectedPaths.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chọn ít nhất 1 file để đẩy lên GitHub build.')),
      );
      return;
    }
    if (!chat.storage.githubConfigured) {
      await _openGithubSettingsDialog(chat);
      if (!mounted || !chat.storage.githubConfigured) return;
    }

    final provider = chat.storage.secretaryProvider ?? chat.storage.defaultProvider;
    final mode = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Chọn cách tự sửa khi build lỗi'),
        content: Text(
          provider != null
              ? 'Có Provider "${provider.name}" — có thể để app tự gọi API sửa, '
                'hoặc tự làm thủ công qua 1 AI khác (dán qua lại, 0 token của app).'
              : 'Chưa có Provider API nào trong app — chỉ có thể làm thủ công '
                'qua 1 AI khác (dán log/prompt qua lại tay).',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Huỷ')),
          if (provider != null)
            FilledButton(onPressed: () => Navigator.pop(dialogContext, 'auto'), child: const Text('App tự sửa (API)')),
          OutlinedButton(onPressed: () => Navigator.pop(dialogContext, 'manual'), child: const Text('Thủ công qua AI khác')),
        ],
      ),
    );
    if (mode == null || !mounted) return;

    if (mode == 'auto') {
      await _runAutoBuildViaApi(chat, provider!);
    } else {
      await _runAutoBuildManualRelay(chat);
    }
  }

  /// Chế độ A — app tự gọi API AI để sửa khi build lỗi.
  Future<void> _runAutoBuildViaApi(ChatProvider chat, ProviderConfig provider) async {
    final owner = chat.storage.githubOwner!;
    final repo = chat.storage.githubRepo!;
    final branch = chat.storage.githubBranch;
    final workflowFile = chat.storage.githubWorkflowFile;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Xác nhận tự động build'),
        content: Text(
          'Sẽ đẩy ${_selectedPaths.length} file lên "$owner/$repo" (nhánh "$branch"), '
          'kích hoạt workflow "$workflowFile", chờ kết quả build. Nếu lỗi, tự nhờ '
          'provider "${provider.name}" đọc log sửa rồi build lại (tối đa 3 lần). '
          'Việc này SẼ TẠO COMMIT THẬT trên repo của bạn. Tiếp tục?',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Huỷ')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Đồng ý, bắt đầu')),
        ],
      ),
    );
    if (confirmed != true) return;

    final service = GithubBuildService(token: chat.storage.githubToken!, owner: owner, repo: repo, branch: branch);
    final statusNotifier = ValueNotifier<String>('Chuẩn bị...');
    setState(() => _autoBuildBusy = true);
    if (mounted) _showProgressDialog(statusNotifier);

    try {
      final selected = {for (final p in _selectedPaths) p: _allFiles[p]!};
      final result = await service.applyAndBuildUntilSuccess(
        initialFiles: selected,
        workflowFile: workflowFile,
        aiApiService: chat.apiService,
        aiProvider: provider,
        onStatus: (s) => statusNotifier.value = s,
      );
      if (!mounted) return;
      Navigator.of(context, rootNavigator: true).pop();
      await _handleBuildResult(service, result);
    } catch (e) {
      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi tự động build: $e')));
      }
    } finally {
      service.dispose();
      if (mounted) setState(() => _autoBuildBusy = false);
    }
  }

  /// Chế độ B — THỦ CÔNG qua 1 AI khác (không tốn token API của app): mỗi
  /// vòng lỗi, app tự COPY sẵn (log lỗi + prompt định dạng chuẩn +
  /// [CodeZipExporter.formatForSharing]) vào clipboard — người dùng tự dán
  /// cho AI khác (ChatGPT/Claude.ai/...), rồi dán NGƯỢC kết quả trả lời vào
  /// app; app tự [CodeZipExporter.extractFiles] + merge + đẩy lại + build
  /// lại, lặp tới khi thành công hoặc người dùng dừng. Đây chính là cách
  /// trả lời câu hỏi "bên kia chỉ xuất text thì cần prompt gì để gộp lại
  /// đúng cấu trúc" — dùng lại ĐÚNG prompt đã có ở "Cách 2"
  /// ([CodeZipExporter.formatInstructionPrompt]), không cần viết prompt mới.
  Future<void> _runAutoBuildManualRelay(ChatProvider chat) async {
    final owner = chat.storage.githubOwner!;
    final repo = chat.storage.githubRepo!;
    final branch = chat.storage.githubBranch;
    final workflowFile = chat.storage.githubWorkflowFile;
    final service = GithubBuildService(token: chat.storage.githubToken!, owner: owner, repo: repo, branch: branch);

    var files = {for (final p in _selectedPaths) p: _allFiles[p]!};
    var round = 1;
    const maxRounds = 10; // chặn lặp vô hạn nếu người dùng cứ dán kết quả không sửa được gì

    setState(() => _autoBuildBusy = true);
    try {
      while (round <= maxRounds) {
        if (!mounted) return;

        // Soi lỗi cú pháp THÔ trước khi đẩy — bắt lỗi ngớ ngẩn (thiếu ngoặc/
        // nháy) mà không cần tốn cả 1 vòng build GitHub (vài phút) mới biết.
        final syntaxWarnings = QuickSyntaxCheck.check(files);

        final confirmed = await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: Text(round == 1 ? 'Xác nhận build (vòng 1)' : 'Đẩy bản đã sửa & build lại (vòng $round)'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Sẽ đẩy ${files.length} file lên "$owner/$repo" (nhánh "$branch"), '
                    'kích hoạt workflow "$workflowFile". SẼ TẠO COMMIT THẬT. Tiếp tục?',
                  ),
                  if (syntaxWarnings.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Text(
                      'Soi thô phát hiện khả năng lỗi cú pháp (có thể báo nhầm, '
                      'không chắc chắn 100% — vẫn có thể bỏ qua nếu tin code đúng):',
                      style: TextStyle(color: Theme.of(dialogContext).colorScheme.error, fontWeight: FontWeight.bold),
                    ),
                    ...syntaxWarnings.map((w) => Text('• $w', style: const TextStyle(fontSize: 12))),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Dừng lại')),
              FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Đồng ý, vẫn đẩy lên')),
            ],
          ),
        );
        if (confirmed != true) break;

        final statusNotifier = ValueNotifier<String>('Vòng $round: đang đẩy code...');
        if (mounted) _showProgressDialog(statusNotifier);

        int? runId;
        String? conclusion;
        try {
          await service.pushFiles(files, message: 'Manual-relay build round $round');
          statusNotifier.value = 'Đang kích hoạt build...';
          await service.triggerWorkflow(workflowFile);
          statusNotifier.value = 'Đang chờ kết quả build...';
          final run = await service.waitForRunCompletion(workflowFile);
          runId = run['id'] as int;
          conclusion = run['conclusion'] as String? ?? 'unknown';
        } catch (e) {
          if (mounted) Navigator.of(context, rootNavigator: true).pop();
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi ở vòng $round: $e')));
          }
          break;
        }
        if (mounted) Navigator.of(context, rootNavigator: true).pop();
        if (runId == null || conclusion == null) break; // không nên xảy ra, chỉ để an toàn kiểu dữ liệu

        if (conclusion == 'success') {
          final artifacts = await service.fetchArtifacts(runId);
          final artifactId = artifacts.isNotEmpty ? artifacts.first['id'] as int : null;
          await _handleBuildResult(service, AutoBuildResult(success: true, attempts: round, artifactId: artifactId));
          return;
        }

        // Lỗi — chuẩn bị nội dung để dán cho AI khác. Từ vòng 2 trở đi, CHỈ
        // gửi đầy đủ những file có tên xuất hiện trong log lỗi (thường là
        // đúng file gây lỗi), file khác chỉ liệt kê tên — giảm hẳn kích
        // thước prompt cho dự án nhiều file, thay vì gửi lại TOÀN BỘ mỗi
        // vòng. Nếu không khớp được file nào (log không có tên file rõ
        // ràng), rơi về gửi đầy đủ như cũ (an toàn, không thoái lui).
        final log = await service.fetchRunLog(runId);
        final trimmedLog = log.length > 6000 ? log.substring(log.length - 6000) : log;

        String filesSection;
        if (round == 1) {
          filesSection = CodeZipExporter.formatForSharing(files);
        } else {
          final relevant = files.keys.where((p) => trimmedLog.contains(p)).toList();
          if (relevant.isEmpty) {
            filesSection = CodeZipExporter.formatForSharing(files);
          } else {
            final others = files.keys.where((p) => !relevant.contains(p)).toList();
            filesSection = CodeZipExporter.formatForSharing({for (final p in relevant) p: files[p]!}) +
                (others.isEmpty
                    ? ''
                    : '\n\nCác file khác giữ NGUYÊN (không đổi, không gửi lại nội dung để đỡ dài): ${others.join(", ")}.\n'
                        'Nếu bạn thật sự cần xem nội dung 1 trong các file đó trước khi sửa, '
                        'trả lời ĐÚNG DUY NHẤT 1 dòng (không kèm gì khác): '
                        'SHOW_FILE: đường/dẫn/file — tôi sẽ gửi lại nội dung file đó ngay, chưa cần build.');
          }
        }
        final combined = 'Build Flutter/Android bị lỗi (vòng $round). Log lỗi (đã cắt bớt):\n'
            '$trimmedLog\n\n'
            'Hãy sửa lỗi trên. ${CodeZipExporter.formatInstructionPrompt}\n\n'
            '$filesSection';

        if (!mounted) return;
        var pasted = await _showRelayPasteDialog(round, combined);
        if (pasted == null) break; // người dùng chọn dừng

        // Xử lý yêu cầu "cho xem thêm 1 file" — KHÔNG tính là 1 vòng build,
        // chỉ gửi lại nội dung file đó rồi hỏi lại, không đẩy/không build.
        var showFileMatch = RegExp(r'^\s*SHOW_FILE:\s*(.+?)\s*$').firstMatch(pasted.trim());
        while (showFileMatch != null) {
          final requestedPath = showFileMatch.group(1)!;
          final requestedContent = files[requestedPath];
          final followUp = requestedContent != null
              ? 'Nội dung file "$requestedPath":\n${CodeZipExporter.formatForSharing({requestedPath: requestedContent})}\n\n'
                  'Giờ hãy sửa lỗi và trả lời theo đúng khuôn đã dặn ở trên.'
              : 'Không tìm thấy file "$requestedPath" trong danh sách đang chọn — kiểm tra lại tên, hoặc sửa dựa trên các file đã có.';
          if (!mounted) return;
          final next = await _showRelayPasteDialog(round, followUp);
          if (next == null) return;
          pasted = next;
          showFileMatch = RegExp(r'^\s*SHOW_FILE:\s*(.+?)\s*$').firstMatch(pasted.trim());
        }

        final changed = CodeZipExporter.extractFiles(pasted);
        if (changed.isEmpty) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Không đọc được file nào từ kết quả dán — thử lại, nhớ nhờ AI trả lời đúng định dạng đã copy.')),
            );
          }
          continue; // thử lại đúng vòng này, không tăng round
        }
        files = Map<String, String>.from(files)..addAll(changed);
        round++;
      }
      if (round > maxRounds && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Đã dừng sau 10 vòng chưa build thành công — kiểm tra lại thủ công.')),
        );
      }
    } finally {
      service.dispose();
      if (mounted) setState(() => _autoBuildBusy = false);
    }
  }

  /// Hiện dialog: đã copy sẵn log+prompt vào clipboard, chờ người dùng dán
  /// kết quả từ AI khác vào. Trả về null nếu người dùng bấm "Dừng lại".
  Future<String?> _showRelayPasteDialog(int round, String promptToCopy) async {
    await Clipboard.setData(ClipboardData(text: promptToCopy));
    final pasteCtrl = TextEditingController();
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: Text('Build lỗi ở vòng $round'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Đã COPY sẵn (log lỗi + prompt định dạng + toàn bộ code hiện tại) '
                'vào clipboard. Dán sang 1 AI khác (ChatGPT/Claude.ai/Gemini...), '
                'đợi trả lời, rồi dán kết quả vào ô dưới.',
                style: TextStyle(fontSize: 13),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: pasteCtrl,
                maxLines: 6,
                decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Dán kết quả AI khác trả lời vào đây'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, null), child: const Text('Dừng lại')),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, pasteCtrl.text),
            child: const Text('Tiếp tục build lại'),
          ),
        ],
      ),
    );
  }

  void _showProgressDialog(ValueNotifier<String> statusNotifier) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('Đang xử lý...'),
        content: ValueListenableBuilder<String>(
          valueListenable: statusNotifier,
          builder: (_, status, __) => Row(
            children: [
              const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
              const SizedBox(width: 16),
              Expanded(child: Text(status)),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _handleBuildResult(GithubBuildService service, AutoBuildResult result) async {
    if (result.success) {
      if (result.artifactId != null) {
        final zipBytes = await service.downloadArtifact(result.artifactId!);
        final apkBytes = GithubBuildService.extractApkFromArtifactZip(zipBytes);
        if (apkBytes != null) {
          await FileSaver.saveAndShare(apkBytes, 'build_${DateTime.now().millisecondsSinceEpoch}.apk');
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Build thành công sau ${result.attempts} vòng — đã tải APK.')),
            );
          }
        } else if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Build thành công nhưng artifact không chứa file .apk — vào tab Actions trên GitHub để tải thủ công.')),
          );
        }
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Build thành công nhưng không thấy artifact nào — kiểm tra workflow có bước "upload-artifact" cho file .apk chưa.')),
        );
      }
    } else {
      _showBuildFailureDialog(result);
    }
  }

  void _showBuildFailureDialog(AutoBuildResult result) {
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Build thất bại sau ${result.attempts} lần thử'),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Text(
              result.lastLog ?? '(Không có log.)',
              style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
            ),
          ),
        ),
        actions: [
          if (result.lastLog != null)
            TextButton(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: result.lastLog!));
                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  const SnackBar(content: Text('Đã copy log lỗi.')),
                );
              },
              child: const Text('Copy log'),
            ),
          FilledButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Đóng')),
        ],
      ),
    );
  }

  Future<void> _runEdit(ChatProvider chat) async {
    if (chat.current == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Hãy mở hoặc tạo 1 đoạn chat trước.')),
      );
      return;
    }
    final provider = chat.storage.secretaryProvider ?? chat.storage.providerFor(chat.current!);
    if (provider == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chưa cấu hình Provider API. Vào Cài đặt để thêm.')),
      );
      return;
    }
    if (_selectedPaths.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Chọn ít nhất 1 file để AI xem/sửa.')),
      );
      return;
    }

    setState(() => _busy = true);
    try {
      final buffer = StringBuffer();
      buffer.writeln('Đây là các file trong 1 dự án source code (.zip) người dùng đã upload. '
          'Đọc kỹ rồi thực hiện đúng yêu cầu bên dưới.');
      buffer.writeln();
      for (final path in _selectedPaths) {
        buffer.writeln('```$path');
        buffer.writeln(_allFiles[path]);
        buffer.writeln('```');
      }
      buffer.writeln();
      buffer.writeln('--- YÊU CẦU ---');
      buffer.writeln(_instructionController.text.trim());
      buffer.writeln();
      buffer.writeln('--- ĐỊNH DẠNG TRẢ LỜI BẮT BUỘC ---');
      buffer.writeln('CHỈ trả lời bằng các code block cho những file BẠN THÊM MỚI hoặc '
          'THAY ĐỔI (không cần lặp lại file không đổi). Mỗi file 1 block, đường dẫn '
          'đặt ngay sau dấu ``` (ví dụ ```lib/main.dart), nội dung đầy đủ của file đó '
          'bên trong block. KHÔNG thêm lời dẫn/giải thích ngoài các code block.');

      final result = await chat.apiService.sendMessageOnce(
        config: provider,
        messages: [ApiMessage('user', buffer.toString())],
        onUsage: (usage) => chat.usageService.record(provider.id, usage),
      );

      final changed = CodeZipExporter.extractFiles(result);
      if (changed.isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('AI không trả về file nào theo đúng định dạng mong đợi — thử lại với yêu cầu rõ ràng hơn.')),
          );
        }
        return;
      }

      final merged = Map<String, String>.from(_allFiles)..addAll(changed);
      final zipBytes = CodeZipExporter.export(
        merged,
        readmeExtra: '# Đã chỉnh sửa bởi thư ký AI\n\n'
            'Các file thay đổi/thêm mới: ${changed.keys.join(', ')}',
      );
      final outName = _zipName != null
          ? '${_zipName!.replaceAll('.zip', '')}_edited_${DateTime.now().millisecondsSinceEpoch}.zip'
          : 'source_edited_${DateTime.now().millisecondsSinceEpoch}.zip';
      await FileSaver.saveAndShare(zipBytes, outName);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Đã sửa ${changed.length} file, tải về "$outName".')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Sửa source code (.zip)')),
      body: _allFiles.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Upload 1 file .zip source code để bắt đầu.', textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: _pickZip,
                      icon: const Icon(Icons.upload_file),
                      label: const Text('Upload .zip'),
                    ),
                  ],
                ),
              ),
            )
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Expanded(child: Text('$_zipName — ${_allFiles.length} file text'
                          '${_skippedBinary.isNotEmpty ? ', bỏ qua ${_skippedBinary.length} file nhị phân' : ''}')),
                      TextButton(onPressed: _pickZip, child: const Text('Đổi file khác')),
                    ],
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        SizedBox(
                          height: 220,
                          child: ListView(
                            children: _allFiles.keys.map((path) {
                              return CheckboxListTile(
                                dense: true,
                                value: _selectedPaths.contains(path),
                                onChanged: (v) => setState(() {
                                  if (v == true) {
                                    _selectedPaths.add(path);
                                  } else {
                                    _selectedPaths.remove(path);
                                  }
                                }),
                                title: Text(path, style: const TextStyle(fontFamily: 'monospace', fontSize: 13)),
                              );
                            }).toList(),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          child: OutlinedButton.icon(
                            onPressed: _copySelectedForSharing,
                            icon: const Icon(Icons.copy_all_outlined),
                            label: Text('Copy ${_selectedPaths.length} file đã chọn (gửi cho AI khác/người khác)'),
                          ),
                        ),
                        const Divider(height: 1),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                          child: Text('Cách 1 — AI trong app tự sửa', style: Theme.of(context).textTheme.labelLarge),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: TextField(
                            controller: _instructionController,
                            maxLines: 2,
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              labelText: 'Yêu cầu sửa gì?',
                              hintText: 'VD: sửa lỗi build, thêm màn hình đăng nhập, đổi màu theme...',
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: FilledButton.icon(
                            onPressed: _busy ? null : () => _runEdit(chat),
                            icon: _busy
                                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                                : const Icon(Icons.auto_fix_high),
                            label: Text(_busy ? 'Đang xử lý...' : 'Sửa bằng AI (1 lần gọi API) & tải zip'),
                          ),
                        ),
                        const Divider(height: 24),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
                          child: Text('Cách 2 — đã có bản sửa từ nơi khác (0 token)', style: Theme.of(context).textTheme.labelLarge),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                          child: Text(
                            'Mẹo: dán prompt "mồi" này cho bên kia (AI khác/người khác) TRƯỚC KHI '
                            'họ trả lời, để kết quả trả về parse được ngay — khỏi cần app gọi thêm AI.',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                          child: OutlinedButton.icon(
                            onPressed: () {
                              Clipboard.setData(const ClipboardData(text: CodeZipExporter.formatInstructionPrompt));
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Đã copy prompt định dạng — dán gửi cho bên kia trước khi họ trả lời.')),
                              );
                            },
                            icon: const Icon(Icons.content_copy),
                            label: const Text('Copy prompt định dạng chuẩn'),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: TextField(
                            controller: _externalResultController,
                            maxLines: 3,
                            decoration: const InputDecoration(
                              border: OutlineInputBorder(),
                              labelText: 'Dán kết quả đã sửa (cú pháp ```đường/dẫn/file.ext ... ```)',
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: OutlinedButton.icon(
                            onPressed: _mergeExternalResult,
                            icon: const Icon(Icons.merge_type),
                            label: const Text('Ghép & tải zip (không gọi AI)'),
                          ),
                        ),
                        const Divider(height: 24),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 0, 12, 0),
                          child: Text('Cách 3 — Tự động build APK qua GitHub Actions', style: Theme.of(context).textTheme.labelLarge),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
                          child: Text(
                            'Đẩy các file đã tick chọn ở trên lên 1 repo GitHub (đã có sẵn '
                            'workflow build), tự chờ kết quả, build xong tự tải APK về. '
                            'KHÔNG cần AI nếu code đã build được ngay (vd code do nơi khác '
                            'xuất sẵn) — AI chỉ được gọi tới khi build LỖI để tự đọc log sửa.',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                          child: Row(
                            children: [
                              Expanded(
                                child: FilledButton.icon(
                                  onPressed: _autoBuildBusy ? null : () => _runAutoBuild(chat),
                                  icon: _autoBuildBusy
                                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                                      : const Icon(Icons.rocket_launch_outlined),
                                  label: Text(_autoBuildBusy ? 'Đang build...' : 'Tự động build & tải APK'),
                                ),
                              ),
                              const SizedBox(width: 8),
                              IconButton(
                                tooltip: 'Cấu hình GitHub (token/owner/repo/branch/workflow)',
                                onPressed: _autoBuildBusy ? null : () => _openGithubSettingsDialog(chat),
                                icon: const Icon(Icons.settings_outlined),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
