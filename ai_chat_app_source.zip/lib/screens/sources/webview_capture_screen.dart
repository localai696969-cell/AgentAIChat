import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:archive/archive.dart';
import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:uuid/uuid.dart';
import '../../models/source_document.dart';
import '../../providers/chat_provider.dart';
import '../../services/export/code_zip_export.dart';
import '../../services/storage_service.dart';
import '../../widgets/run_python_from_text_dialog.dart';
import '../code/zip_edit_screen.dart';
import 'source_documents_screen.dart';

/// Trình duyệt nhúng ngay trong app để người dùng tự đăng nhập vào BẤT KỲ
/// hệ thống web nào họ có quyền truy cập (web nội bộ công ty, hộp thư, hệ
/// thống quản lý công việc, mạng xã hội, ...) bằng chính phiên đăng nhập của
/// họ — app KHÔNG lưu, KHÔNG can thiệp mật khẩu/đăng nhập.
///
/// Khi đang xem 1 trang bất kỳ, bấm nút "Trích xuất nội dung trang" sẽ chạy
/// JS `document.body.innerText` lấy toàn bộ text đang HIỂN THỊ trên trang
/// (đúng những gì mắt người dùng đang thấy, họ tự quyết định trang nào cần
/// lấy) và lưu thành 1 SourceDocument — bước này KHÔNG gọi API model nào cả,
/// nên KHÔNG tốn token. Token chỉ bị tốn 1 LẦN DUY NHẤT sau đó, khi người
/// dùng chủ động bấm "Tổng hợp" ở màn hình Tài liệu nguồn.
///
/// LƯU Ý KỸ THUẬT: một số trang (đặc biệt hệ thống doanh nghiệp có SSO/2FA
/// nghiêm ngặt, hoặc chặn User-Agent lạ) có thể từ chối hiển thị trong
/// WebView — nếu gặp trang trắng/lỗi đăng nhập, đó là do chính hệ thống đó
/// chặn, không phải lỗi của app.
///
/// Nút "Dán nội dung" trên AppBar: dán 1 Tài liệu nguồn (hoặc văn bản gõ
/// tay) vào ĐÚNG ô người dùng đang bấm/focus trên trang — bình luận blog,
/// ô chat, form bất kỳ, không hardcode cấu trúc trang nào. CỐ Ý không tự
/// động bấm Gửi/Đăng — người dùng luôn tự xem lại và gửi bằng tay.
/// Nút "Đọc chữ canvas" (icon Aa) trên AppBar: chặn `ctx.fillText`/
/// `strokeText` (tiêm script từ lúc trang bắt đầu load) để lấy CHÍNH XÁC
/// chuỗi text gốc trang định vẽ lên canvas — không qua bước "đoán chữ trong
/// ảnh" như OCR, nên không có lỗi nhận nhầm ký tự. Kèm đọc `aria-label`
/// (text trang tự cung cấp cho accessibility). CHỈ hoạt động nếu trang dùng
/// đúng Canvas Text API chuẩn hoặc có accessibility layer — nếu trang vẽ
/// chữ kiểu sprite ảnh (hay gặp ở game) hoặc WebGL, dùng nút OCR thay thế.
///
/// Nút OCR (icon máy quét) trên AppBar: dùng khi trang vẽ chữ bằng
/// `<canvas>`/WebGL và cách "Đọc chữ canvas" ở trên không bắt được gì — DOM
/// extraction (`innerText`) không đọc được text trong trường hợp này vì
/// canvas chỉ là pixel, không có text node. OCR chụp ảnh đúng những gì
/// đang hiển thị rồi nhận diện chữ HOÀN TOÀN TRÊN MÁY (không upload ảnh
/// lên đâu cả) — vẫn là "nhìn đúng cái hiển thị", không phải network
/// interception, nhưng có thể nhận nhầm 1 vài ký tự (giới hạn cố hữu của
/// mọi OCR).
///
/// Nút ▶ "Chạy Python" và 📦 "Đóng gói .zip" trên AppBar: chạy trực tiếp
/// với nội dung TRÍCH TỪ TRANG ĐANG XEM, không cần vòng qua "Tài liệu
/// nguồn" → "Tổng hợp" trước (xem HANDOFF.md mục 41).
///
/// Nút back (mũi tên ở AppBar, hoặc nút/vuốt back của điện thoại): LÙI LẠI
/// LỊCH SỬ DUYỆT của chính trang đang xem trước (giống trình duyệt thật),
/// CHỈ thoát hẳn màn hình này khi không còn trang nào để lùi — xem
/// [_handleBack].
class WebviewCaptureScreen extends StatefulWidget {
  final String initialUrl;
  const WebviewCaptureScreen({super.key, this.initialUrl = 'https://www.google.com'});

  @override
  State<WebviewCaptureScreen> createState() => _WebviewCaptureScreenState();
}

class _WebviewCaptureScreenState extends State<WebviewCaptureScreen> {
  static const _downloadableExtensions = {
    'zip', 'rar', '7z', 'docx', 'doc', 'pdf', 'xlsx', 'xls', 'pptx', 'ppt', 'csv',
  };

  late final WebViewController _controller;
  final _webviewKey = GlobalKey();
  static const _cookieChannel = MethodChannel('agent_ai_chat/cookies');
  final _urlController = TextEditingController();
  bool _loading = true;
  bool _downloading = false;
  bool _extracting = false;
  bool _ocrRunning = false;
  TextRecognitionScript _ocrScript = TextRecognitionScript.latin;
  String _currentUrl = '';
  String _currentTitle = '';
  Completer<String>? _pendingBlobCompleter;
  late final StorageService _storage;

  @override
  void initState() {
    super.initState();
    // Nếu người gọi KHÔNG chỉ định URL cụ thể (hiện tại chỉ có đúng 1 nơi
    // gọi màn hình này — `source_documents_screen.dart` — và luôn để mặc
    // định), mở lại ĐÚNG trang đang xem dở lần trước thay vì luôn quay về
    // Google. Vá lỗi người dùng phản ánh: "quay lại tài liệu nguồn, sau đó
    // nhấn lại vào trình duyệt web thì web đang lướt mất tiêu và quay lại
    // gg" — nguyên nhân là mỗi lần mở là 1 `WebviewCaptureScreen` HOÀN TOÀN
    // MỚI (route mới, controller mới), không tự nhớ gì cả.
    _storage = context.read<ChatProvider>().storage;
    final savedUrl = _storage.lastBrowsedUrl;
    final effectiveUrl = (widget.initialUrl == 'https://www.google.com' && savedUrl != null && savedUrl.isNotEmpty)
        ? savedUrl
        : widget.initialUrl;
    _urlController.text = effectiveUrl;
    _currentUrl = effectiveUrl;
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      // Đặt User-Agent giống trình duyệt Chrome di động thường — CHỈ giúp
      // với các hệ thống nội bộ/doanh nghiệp đơn giản kiểm tra "có phải
      // trình duyệt hiện đại không" và bị nhầm bởi chuỗi UA mặc định của
      // WebView. KHÔNG nhắm tới việc lách qua việc Google/Meta CHỦ Ý chặn
      // đăng nhập OAuth trong WebView — đó là biện pháp chống lừa đảo
      // (chống app giả mạo/keylogger đội lốt màn hình đăng nhập), có lách
      // qua được hay không nằm ngoài phạm vi hỗ trợ ở đây, vì nó tồn tại
      // để bảo vệ chính người dùng, và cách lách qua tin cậy nhất luôn là:
      // đăng nhập bằng trình duyệt thật (Chrome/Safari ngoài app) trước, rồi
      // quay lại WebView này (một số nền tảng giữ session qua cookie hệ
      // thống, một số thì không).
      ..setUserAgent(
        'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 '
        '(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36',
      )
      ..addJavaScriptChannel(
        'BlobChannel',
        onMessageReceived: (message) {
          _pendingBlobCompleter?.complete(message.message);
          _pendingBlobCompleter = null;
        },
      )
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (url) {
          setState(() {
            _loading = true;
            _currentUrl = url;
            _urlController.text = url;
          });
          // Tiêm SỚM NHẤT có thể (ngay khi trang bắt đầu load, trước khi
          // script của trang kịp vẽ) để chặn ctx.fillText/strokeText — bắt
          // được CHÍNH XÁC chuỗi text mà trang định vẽ lên canvas, TRƯỚC KHI
          // nó biến thành pixel. Chính xác hơn OCR (không có lỗi nhận nhầm
          // ký tự) nhưng chỉ hoạt động nếu trang dùng đúng API Canvas Text
          // chuẩn — nếu trang vẽ chữ kiểu "sprite ảnh" (thường gặp ở game)
          // hoặc dùng WebGL thì không bắt được gì, phải quay lại dùng OCR.
          _controller.runJavaScript('''
            (function() {
              if (window.__canvasTextLog) return;
              window.__canvasTextLog = [];
              if (window.CanvasRenderingContext2D) {
                var origFill = CanvasRenderingContext2D.prototype.fillText;
                var origStroke = CanvasRenderingContext2D.prototype.strokeText;
                CanvasRenderingContext2D.prototype.fillText = function(text) {
                  window.__canvasTextLog.push(String(text));
                  return origFill.apply(this, arguments);
                };
                CanvasRenderingContext2D.prototype.strokeText = function(text) {
                  window.__canvasTextLog.push(String(text));
                  return origStroke.apply(this, arguments);
                };
              }
            })();
          ''').catchError((_) {});
        },
        onPageFinished: (url) async {
          String title = url;
          try {
            title = await _controller.getTitle() ?? url;
          } catch (_) {}
          // Ghi đè URL.createObjectURL để "nhớ" lại Blob gốc ứng với mỗi
          // blob:// URL mà trang tự sinh ra (ví dụ khi người dùng bấm nút
          // "Tải xuống" mà web tạo file ngay trên trình duyệt, không phải
          // link trỏ tới server) — PHẢI chạy lại sau MỖI lần load trang vì
          // mỗi trang có 1 JS context riêng, không kế thừa từ trang trước.
          try {
            await _controller.runJavaScript('''
              (function() {
                if (window.__blobRegistry) return;
                window.__blobRegistry = {};
                var orig = URL.createObjectURL.bind(URL);
                URL.createObjectURL = function(blob) {
                  var u = orig(blob);
                  window.__blobRegistry[u] = blob;
                  return u;
                };
              })();
            ''');
          } catch (_) {}
          if (!mounted) return;
          setState(() {
            _loading = false;
            _currentUrl = url;
            _currentTitle = title;
          });
          try {
            _storage.lastBrowsedUrl = url;
          } catch (_) {
            // Lưu tiến độ URL là tiện ích phụ — lỗi ở đây (hiếm, ví dụ box
            // Hive đang đóng) không được làm gián đoạn việc xem trang.
          }
        },
        // WebView (giống Chrome/Safari) KHÔNG tự tải file đính kèm xuống —
        // nếu để mặc định, link .zip/.docx/.pdf sẽ chỉ hiện trang trắng hoặc
        // lỗi. Chặn lại các link có đuôi file rồi tự tải bằng http + cookie
        // phiên thật của WebView (xem _downloadFile), HOẶC nếu là link
        // `blob:` (file web tự tạo ngay trên trình duyệt, không có URL thật
        // trên server) thì đọc lại từ __blobRegistry (xem _downloadBlobFile).
        onNavigationRequest: (request) {
          if (request.url.startsWith('blob:')) {
            _downloadBlobFile(request.url);
            return NavigationDecision.prevent;
          }
          final path = Uri.tryParse(request.url)?.path.toLowerCase() ?? '';
          final isDownloadLink = _downloadableExtensions.any((ext) => path.endsWith('.$ext'));
          if (isDownloadLink) {
            _downloadFile(request.url);
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ));

    // Bắt sự kiện `<input type="file">` của CHÍNH trang web đang xem (nút
    // "Tải lên"/"Upload"/"Choose file" trên trang đó — KHÁC nút "Upload
    // tài liệu" của app) — mặc định webview_flutter KHÔNG mở được hộp
    // thoại chọn file hệ thống khi trang gọi input file, bấm vào không có
    // phản ứng gì. Chỉ có API này ở Android (qua `webview_flutter_android`)
    // — package:file_selector đã dùng sẵn ở nhiều chỗ khác trong file này.
    final platformController = _controller.platform;
    if (platformController is AndroidWebViewController) {
      platformController.setOnShowFileSelector(_onShowFileSelector);
    }

    _controller.loadRequest(Uri.parse(effectiveUrl));

    // Giữ CPU/màn hình không tự tắt trong SUỐT thời gian màn hình trình
    // duyệt này đang mở — vá phần "tắt màn hình" trong phản ánh của người
    // dùng, cho các thao tác hay bị gián đoạn giữa chừng nếu máy tự khoá
    // (trích xuất trang dài, cuộn & gom, OCR, tải file đính kèm). Tắt lại ở
    // [dispose] khi rời màn hình — KHÔNG giữ wakelock cho CẢ app, chỉ đúng
    // lúc đang ở màn hình cần nó. Đây KHÔNG phải "chạy nền khi chuyển hẳn
    // sang app khác" (cái đó cần foreground service riêng, xem HANDOFF.md)
    // — wakelock chỉ ngăn máy tự khoá do hết giờ chờ, không có tác dụng gì
    // nếu người dùng CHỦ ĐỘNG bấm nút khoá màn hình hoặc rời hẳn sang app
    // khác trong thời gian dài.
    WakelockPlus.enable().catchError((_) {});
  }

  @override
  void dispose() {
    WakelockPlus.disable().catchError((_) {});
    super.dispose();
  }

  /// Xem comment ở chỗ gọi ([initState]) — mở hộp thoại chọn file hệ thống
  /// khi trang web đang xem có `<input type="file">` được bấm vào, trả lại
  /// đường dẫn file đã chọn cho WebView để nó tự đọc & gửi lên form của
  /// trang (giống hệt hành vi trình duyệt thật, app không đọc nội dung file
  /// đó — chỉ làm cầu nối mở hộp thoại chọn file).
  ///
  /// QUAN TRỌNG: trả về dạng URI `file://...` (`File(path).uri.toString()`),
  /// KHÔNG phải đường dẫn hệ thống trần (`/storage/...`) — tra cứu qua ví
  /// dụ thật (nhiều nguồn độc lập đều dùng `.uri.toString()`) mới phát
  /// hiện ra khác biệt này; nếu trả đường dẫn trần, WebView có thể không
  /// nhận diện được file để đính kèm dù hộp thoại vẫn mở đúng.
  Future<List<String>> _onShowFileSelector(FileSelectorParams params) async {
    try {
      if (params.mode == FileSelectorMode.openMultiple) {
        final files = await openFiles();
        return files.map((f) => File(f.path).uri.toString()).toList();
      }
      final file = await openFile();
      return file == null ? <String>[] : [File(file.path).uri.toString()];
    } catch (_) {
      return <String>[];
    }
  }

  Future<void> _goTo(String input) async {
    var url = input.trim();
    if (url.isEmpty) return;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://$url';
    }
    await _controller.loadRequest(Uri.parse(url));
  }

  /// Đọc text đang hiển thị trên trang (không đụng tới network, không đọc
  /// gì ngoài DOM đã render).
  Future<String> _readVisibleText() async {
    final raw = await _controller.runJavaScriptReturningResult(
      'document.body ? document.body.innerText : ""',
    );
    var text = raw.toString();
    if (text.startsWith('"') && text.endsWith('"')) {
      text = text.substring(1, text.length - 1);
    }
    return text.replaceAll(r'\n', '\n').replaceAll(r'\"', '"');
  }

  /// Đọc lại text đã bắt được từ `ctx.fillText`/`strokeText` (script tiêm ở
  /// [initState], xem comment ở đó) — CHÍNH XÁC 100% vì là chuỗi text gốc
  /// trang đưa cho trình duyệt vẽ, không qua bước "đoán chữ trong ảnh" như
  /// OCR. Kèm bonus: đọc luôn mọi `aria-label`/`aria-describedby` trên trang
  /// — đây là text trang TỰ CUNG CẤP cho công nghệ hỗ trợ người khuyết tật
  /// (screen reader), nên nếu trang có làm accessibility tốt, đây cũng là
  /// nguồn text chính xác 100% cho nội dung canvas/hình ảnh mà DOM thường
  /// không có text tương đương.
  ///
  /// CHỈ hoạt động nếu trang dùng đúng Canvas Text API chuẩn hoặc có
  /// accessibility layer — nếu trang vẽ chữ kiểu sprite ảnh hoặc WebGL và
  /// không có aria-label, sẽ không bắt được gì, phải dùng OCR (icon máy
  /// quét) thay thế.
  Future<void> _extractCanvasText(StorageService storage) async {
    if (_extracting) return;
    setState(() => _extracting = true);
    try {
      String canvasText = '';
      try {
        final raw = await _controller.runJavaScriptReturningResult(
          'window.__canvasTextLog ? window.__canvasTextLog.join("\\n") : ""',
        );
        canvasText = raw.toString();
        if (canvasText.startsWith('"') && canvasText.endsWith('"')) {
          canvasText = canvasText.substring(1, canvasText.length - 1);
        }
        canvasText = canvasText.replaceAll(r'\n', '\n').replaceAll(r'\"', '"');
      } catch (_) {}

      String ariaText = '';
      try {
        final raw = await _controller.runJavaScriptReturningResult('''
          (function() {
            var els = document.querySelectorAll('[aria-label], [aria-describedby]');
            var out = [];
            for (var i = 0; i < els.length; i++) {
              var t = els[i].getAttribute('aria-label');
              if (t) out.push(t);
            }
            return JSON.stringify(out.join("\\n"));
          })();
        ''');
        ariaText = jsonDecode(raw.toString()) as String;
      } catch (_) {}

      final combined = [canvasText.trim(), ariaText.trim()].where((s) => s.isNotEmpty).join('\n\n---\n\n');

      if (combined.isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text(
              'Không bắt được text canvas nào — trang có thể vẽ chữ kiểu sprite ảnh hoặc '
              'dùng WebGL. Thử dùng OCR (icon máy quét) thay thế.',
            )),
          );
        }
        return;
      }

      final doc = SourceDocument(
        id: const Uuid().v4(),
        title: '${_currentTitle.isNotEmpty ? _currentTitle : _currentUrl} (canvas text)',
        content: combined,
        origin: 'webview',
        sourceLabel: '$_currentUrl (canvas fillText/aria-label — chính xác, không qua OCR)',
        createdAt: DateTime.now(),
      );
      await storage.sourceDocuments.put(doc.id, doc);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Đã lưu "${doc.title}" (${combined.length} ký tự, chính xác — không qua OCR).')),
        );
      }
    } finally {
      if (mounted) setState(() => _extracting = false);
    }
  }

  /// Chụp ảnh đúng những gì đang HIỂN THỊ trên màn hình WebView (kể cả nội
  /// dung vẽ bằng `<canvas>`/WebGL mà DOM không đọc được), rồi chạy OCR
  /// (nhận diện chữ trong ảnh) HOÀN TOÀN TRÊN MÁY — không upload ảnh lên bất
  /// kỳ server nào (`google_mlkit_text_recognition` chạy on-device). Đây
  /// KHÔNG phải network interception — vẫn chỉ "nhìn" đúng cái đang hiển thị
  /// trên màn hình, chỉ là nhìn bằng ảnh chụp thay vì đọc cây DOM.
  ///
  /// Dùng khi `document.body.innerText` trả về rỗng dù mắt thường vẫn thấy
  /// chữ trên trang — dấu hiệu trang đang vẽ chữ bằng canvas/WebGL.
  Future<void> _extractViaOcr(StorageService storage) async {
    if (_ocrRunning) return;
    setState(() => _ocrRunning = true);
    try {
      final boundary = _webviewKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) {
        throw Exception('Chưa render xong WebView, thử lại sau khi trang đã hiện đầy đủ.');
      }
      final image = await boundary.toImage(pixelRatio: 2.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) throw Exception('Không chụp được ảnh màn hình.');
      final pngBytes = byteData.buffer.asUint8List();

      final tempDir = await getTemporaryDirectory();
      final tempFile = File('${tempDir.path}/webview_ocr_${DateTime.now().millisecondsSinceEpoch}.png');
      await tempFile.writeAsBytes(pngBytes);

      final recognizer = TextRecognizer(script: _ocrScript);
      String text;
      try {
        final inputImage = InputImage.fromFilePath(tempFile.path);
        final result = await recognizer.processImage(inputImage);
        text = result.text;
      } finally {
        await recognizer.close();
        try { await tempFile.delete(); } catch (_) {}
      }

      if (text.trim().isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('OCR không nhận diện được chữ nào trên màn hình hiện tại.')),
          );
        }
        return;
      }

      final doc = SourceDocument(
        id: const Uuid().v4(),
        title: '${_currentTitle.isNotEmpty ? _currentTitle : _currentUrl} (OCR)',
        content: text,
        origin: 'webview',
        sourceLabel: '$_currentUrl (chụp màn hình + OCR)',
        createdAt: DateTime.now(),
      );
      await storage.sourceDocuments.put(doc.id, doc);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(
            'Đã lưu "${doc.title}" bằng OCR (${text.length} ký tự). '
            'Lưu ý: OCR có thể nhận nhầm 1 vài ký tự, hãy xem lại trước khi dùng.',
          )),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('OCR lỗi: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _ocrRunning = false);
    }
  }

  /// Tự cuộn trang xuống nhiều lần (mô phỏng đúng việc người dùng tự cuộn
  /// tay), đọc lại DOM hiển thị sau mỗi lần cuộn, rồi GỘP các dòng nội dung
  /// MỚI xuất hiện — giải quyết trang cuộn vô hạn (infinite scroll) mà
  /// trích xuất 1 lần chỉ lấy được đúng phần đang hiển thị ban đầu.
  ///
  /// Dừng khi: đã cuộn tới đáy trang VÀ chiều cao trang không tăng thêm
  /// (nghĩa là không còn nội dung mới để tải), hoặc tối đa 30 lần cuộn
  /// (để tránh chạy vô hạn nếu trang cố tình cuộn bất tận, ví dụ feed mạng
  /// xã hội không có điểm kết).
  ///
  /// Vẫn chỉ đọc DOM hiển thị tại mỗi bước — không phải network interception.
  Future<void> _extractInfiniteScroll(StorageService storage) async {
    if (_extracting) return;
    setState(() => _extracting = true);
    try {
      await _controller.runJavaScript('window.scrollTo(0, 0);');
      await Future.delayed(const Duration(milliseconds: 300));

      final seenLines = LinkedHashSet<String>();
      int lastHeight = -1;
      int stableRounds = 0;

      for (var i = 0; i < 30; i++) {
        final current = await _readVisibleText();
        for (final line in current.split('\n')) {
          final trimmed = line.trim();
          if (trimmed.isNotEmpty) seenLines.add(trimmed);
        }

        await _controller.runJavaScript('window.scrollBy(0, window.innerHeight * 0.9);');
        await Future.delayed(const Duration(milliseconds: 700));

        int height = 0;
        try {
          final raw = await _controller.runJavaScriptReturningResult('document.body.scrollHeight');
          height = int.tryParse(raw.toString()) ?? 0;
        } catch (_) {}

        if (height == lastHeight) {
          stableRounds++;
          if (stableRounds >= 2) break; // 2 lần liên tiếp không tăng chiều cao → hết nội dung mới
        } else {
          stableRounds = 0;
        }
        lastHeight = height;
      }

      final text = seenLines.join('\n');
      if (text.trim().isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Không gom được nội dung nào.')),
          );
        }
        return;
      }

      final doc = SourceDocument(
        id: const Uuid().v4(),
        title: '${_currentTitle.isNotEmpty ? _currentTitle : _currentUrl} (cuộn toàn trang)',
        content: text,
        origin: 'webview',
        sourceLabel: '$_currentUrl (tự cuộn & gộp)',
        createdAt: DateTime.now(),
      );
      await storage.sourceDocuments.put(doc.id, doc);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Đã gom & lưu "${doc.title}" (${text.length} ký tự, ${seenLines.length} dòng).')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi khi cuộn & gom: $e')));
      }
    } finally {
      if (mounted) setState(() => _extracting = false);
    }
  }

  Future<void> _extractAndSave(StorageService storage) async {
    if (_extracting) return;
    setState(() => _extracting = true);
    try {
      String text;
      try {
        text = await _readVisibleText();
        // Nhiều trang (đặc biệt chat AI) HIỂN THỊ câu trả lời dần dần
        // (streaming) — nếu bấm trích xuất đúng lúc đang gõ dở, sẽ lấy thiếu.
        // Đọc lại vài lần, nếu nội dung NGỪNG THAY ĐỔI giữa 2 lần đọc liên
        // tiếp thì dừng sớm; tối đa 5 lần (~2.5s) rồi dùng bản cuối dù đã ổn
        // định hay chưa. Vẫn chỉ đọc DOM hiển thị — không phải network
        // interception, không đọc gì bạn không thấy trên màn hình.
        for (var i = 0; i < 5; i++) {
          await Future.delayed(const Duration(milliseconds: 500));
          final next = await _readVisibleText();
          if (next == text) break;
          text = next;
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Không trích xuất được nội dung trang này: $e')),
          );
        }
        return;
      }

      if (text.trim().isEmpty) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Trang này không có nội dung text để trích xuất.')),
          );
        }
        return;
      }

      final doc = SourceDocument(
        id: const Uuid().v4(),
        title: _currentTitle.isNotEmpty ? _currentTitle : _currentUrl,
        content: text,
        origin: 'webview',
        sourceLabel: _currentUrl,
        createdAt: DateTime.now(),
      );
      await storage.sourceDocuments.put(doc.id, doc);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Đã lưu "${doc.title}" vào Tài liệu nguồn (${text.length} ký tự).')),
        );
      }
    } finally {
      if (mounted) setState(() => _extracting = false);
    }
  }

  /// Tải file được web tạo ra bằng `URL.createObjectURL(blob)` (không có URL
  /// thật trên server — thường gặp khi trang tự đóng gói file ngay trên
  /// trình duyệt rồi cho bấm "Tải xuống", ví dụ nút "Export" tự build zip
  /// bằng JS). `http.get` bình thường không tải được vì blob: URL chỉ có ý
  /// nghĩa trong đúng JS context của trang đó.
  ///
  /// Cách lấy: script tiêm vào từ [initState] đã "nhớ" lại đối tượng Blob
  /// gốc mỗi khi trang gọi `URL.createObjectURL`; giờ đọc lại đúng Blob đó
  /// bằng `FileReader.readAsDataURL`, gửi base64 qua [JavaScriptChannel] về
  /// Dart. Đây vẫn là dữ liệu DO CHÍNH HÀNH ĐỘNG của người dùng (bấm nút tải
  /// trên trang) sinh ra — không phải bắt traffic ngầm của trang.
  Future<void> _downloadBlobFile(String blobUrl) async {
    if (_downloading) return;
    setState(() => _downloading = true);
    try {
      final completer = Completer<String>();
      _pendingBlobCompleter = completer;

      await _controller.runJavaScript('''
        (function() {
          var blob = window.__blobRegistry && window.__blobRegistry[${jsonEncode(blobUrl)}];
          if (!blob) { BlobChannel.postMessage("ERROR:NOT_FOUND"); return; }
          var reader = new FileReader();
          reader.onload = function() { BlobChannel.postMessage(reader.result); };
          reader.onerror = function() { BlobChannel.postMessage("ERROR:READ_FAILED"); };
          reader.readAsDataURL(blob);
        })();
      ''');

      final dataUrl = await completer.future.timeout(
        const Duration(seconds: 15),
        onTimeout: () => 'ERROR:TIMEOUT',
      );

      if (dataUrl.startsWith('ERROR:')) {
        throw Exception(
          dataUrl == 'ERROR:NOT_FOUND'
              ? 'Không tìm thấy dữ liệu blob (có thể trang đã tạo file trước khi bạn mở tính năng này, hoặc trang dùng cách khác để tạo blob).'
              : dataUrl == 'ERROR:TIMEOUT'
                  ? 'Đọc blob quá lâu, có thể file quá lớn.'
                  : 'Không đọc được nội dung blob.',
        );
      }

      // dataUrl dạng: data:<mime>;base64,<dữ liệu>
      final commaIndex = dataUrl.indexOf(',');
      if (commaIndex == -1) throw Exception('Định dạng dữ liệu blob không hợp lệ.');
      final bytes = base64Decode(dataUrl.substring(commaIndex + 1));

      // Đoán tên file từ URL trang hiện tại + thời gian, vì blob: URL không
      // mang theo tên file gốc.
      final ext = dataUrl.contains('zip') ? 'zip' : 'bin';
      final name = 'blob_download_${DateTime.now().millisecondsSinceEpoch}.$ext';

      if (!mounted) return;
      if (ext == 'zip' || bytes.length > 4 && bytes[0] == 0x50 && bytes[1] == 0x4B) {
        // Chữ ký PK\x03\x04 ở đầu file = định dạng zip thật, bất kể đuôi mime.
        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ZipEditScreen(initialBytes: bytes, initialName: name.endsWith('.zip') ? name : '$name.zip'),
          ),
        );
        return;
      }

      // Không nhận diện được là zip — lưu tạm ra thư mục documents rồi báo
      // người dùng, vì không rõ nên coi là gì để xử lý tiếp.
      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/$name');
      await file.writeAsBytes(bytes);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Đã tải blob (${bytes.length} bytes) vào ${file.path} — không nhận diện được định dạng cụ thể.')),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Không tải được blob: $e')));
      }
    } finally {
      if (mounted) setState(() => _downloading = false);
    }
  }

  /// Tải 1 file đính kèm (zip/docx/pdf/...) từ [url] bằng chính phiên đăng
  /// nhập hiện tại của WebView. Dùng MethodChannel gọi thẳng
  /// `android.webkit.CookieManager` gốc của Android (đọc cookie qua
  /// CookieManager GỐC của hệ điều hành) thay vì `document.cookie` trong JS,
  /// vì `document.cookie` KHÔNG đọc được cookie đánh dấu HttpOnly — mà cookie
  /// phiên đăng nhập (session/auth token) thường được đánh dấu HttpOnly vì lý
  /// do bảo mật, nên cách này mới thực sự tải được file cần đăng nhập.
  Future<void> _downloadFile(String url) async {
    if (_downloading) return;
    setState(() => _downloading = true);
    try {
      String cookieHeader = '';
      try {
        final result = await _cookieChannel.invokeMethod<String>('getCookies', {'url': url});
        cookieHeader = result ?? '';
      } catch (_) {
        // Fallback nếu MethodChannel lỗi (ví dụ chạy trên nền tảng chưa cài
        // handler này) — document.cookie KHÔNG đọc được cookie HttpOnly nên
        // kém tin cậy hơn, nhưng vẫn còn hơn không có gì.
        try {
          final raw = await _controller.runJavaScriptReturningResult('document.cookie');
          cookieHeader = raw.toString().replaceAll('"', '');
        } catch (_) {}
      }
      String userAgent = '';
      try {
        final ua = await _controller.runJavaScriptReturningResult('navigator.userAgent');
        userAgent = ua.toString().replaceAll('"', '');
      } catch (_) {}

      final resp = await http.get(
        Uri.parse(url),
        headers: {
          if (cookieHeader.isNotEmpty) 'Cookie': cookieHeader,
          if (userAgent.isNotEmpty) 'User-Agent': userAgent,
        },
      );

      if (resp.statusCode < 200 || resp.statusCode >= 300) {
        throw Exception('Server trả về mã lỗi ${resp.statusCode} — có thể trang '
            'yêu cầu đăng nhập lại hoặc cookie phiên không hợp lệ cho link này.');
      }

      final name = Uri.parse(url).pathSegments.isNotEmpty ? Uri.parse(url).pathSegments.last : 'downloaded_file';
      final ext = name.contains('.') ? name.split('.').last.toLowerCase() : '';

      if (!mounted) return;

      if (ext == 'zip') {
        // Đưa thẳng sang màn "Sửa source code (.zip)" — không cần chọn lại
        // file lần 2.
        await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ZipEditScreen(initialBytes: resp.bodyBytes, initialName: name),
          ),
        );
        return;
      }

      // File không phải zip: cố đọc thành text để lưu làm Tài liệu nguồn.
      // Lưu ý: .docx/.pdf/.xlsx/.pptx là định dạng nhị phân (bản chất cũng là
      // zip có cấu trúc XML bên trong) — đọc thẳng bằng utf8 sẽ ra ký tự rác,
      // KHÔNG phải nội dung thật. App hiện chưa có bước tự parse các định
      // dạng này (cần thư viện riêng cho từng loại) — nếu gặp, khuyên người
      // dùng tải file đó về máy qua trình duyệt thường rồi convert sang .txt/
      // .md trước, hoặc yêu cầu tôi bổ sung parser riêng cho từng định dạng.
      if (!{'txt', 'md', 'csv', 'json', 'html', 'xml', 'log'}.contains(ext)) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(
            'Đã tải "$name" ($ext) nhưng đây là định dạng nhị phân — app chưa đọc được '
            'nội dung text từ .$ext. Tải về máy rồi mở bằng ứng dụng phù hợp, hoặc báo '
            'tôi bổ sung parser riêng cho .$ext.',
          )),
        );
        return;
      }

      final storage = context.read<ChatProvider>().storage;
      final text = utf8.decode(resp.bodyBytes, allowMalformed: true);
      final doc = SourceDocument(
        id: const Uuid().v4(),
        title: name,
        content: text,
        origin: 'webview',
        sourceLabel: url,
        createdAt: DateTime.now(),
      );
      await storage.sourceDocuments.put(doc.id, doc);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Đã tải "$name" và lưu vào Tài liệu nguồn (${text.length} ký tự).')),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Không tải được file: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _downloading = false);
    }
  }

  /// Dán [text] vào ĐÚNG phần tử người dùng đang bấm/focus trên trang
  /// (`document.activeElement`) — không cần biết trước cấu trúc DOM của
  /// từng trang, nên dùng được cho bất kỳ ô nào: bình luận blog, ô chat, ô
  /// reply diễn đàn, form bất kỳ... Người dùng TỰ CHỌN ô bằng cách bấm/chạm
  /// vào ô đó trước khi gọi hàm này.
  ///
  /// CỐ Ý KHÔNG tự động bấm nút Gửi/Đăng sau khi dán — với ô chat có người
  /// thật hoặc form đăng công khai, việc tool tự bấm gửi nghĩa là nội dung
  /// đi luôn mà không ai (kể cả người dùng) kịp xem lại lần cuối, và một số
  /// nền tảng coi hành vi tự-điền-tự-gửi là dấu hiệu bot. Người dùng luôn
  /// phải tự bấm Gửi/Đăng bằng tay sau khi xem lại.
  ///
  /// Dùng setter GỐC của trình duyệt (qua `Object.getOwnPropertyDescriptor`)
  /// thay vì gán `el.value = ...` trực tiếp — nhiều trang hiện đại (React/
  /// Vue) ghi đè setter mặc định để tự quản lý state nội bộ, gán trực tiếp
  /// sẽ không được framework đó nhận ra là có thay đổi; gọi setter GỐC rồi
  /// bắn sự kiện `input` mới khiến framework cập nhật đúng.
  Future<void> _pasteIntoFocusedElement(String text) async {
    final script = '''
      (function() {
        var el = document.activeElement;
        if (!el || el === document.body) return "NO_FOCUS";
        var text = ${jsonEncode(text)};
        var tag = el.tagName;
        if (tag === "TEXTAREA" || tag === "INPUT") {
          var proto = tag === "TEXTAREA" ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
          var desc = Object.getOwnPropertyDescriptor(proto, "value");
          if (desc && desc.set) { desc.set.call(el, text); } else { el.value = text; }
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
          return "OK";
        } else if (el.isContentEditable) {
          el.innerText = text;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          return "OK";
        }
        return "NOT_EDITABLE";
      })();
    ''';

    String status = 'ERROR';
    try {
      final raw = await _controller.runJavaScriptReturningResult(script);
      status = raw.toString().replaceAll('"', '');
    } catch (_) {}

    if (!mounted) return;
    switch (status) {
      case 'OK':
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(
            'Đã dán vào ô đang chọn. Hãy tự xem lại và bấm Gửi/Đăng trên trang — '
            'app không tự động gửi thay bạn.',
          )),
        );
        break;
      case 'NO_FOCUS':
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(
            'Chưa chọn ô nào — hãy bấm/chạm vào ô bạn muốn dán (bình luận, chat, form...) '
            'trên trang rồi thử lại.',
          )),
        );
        break;
      case 'NOT_EDITABLE':
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Ô đang chọn không phải ô nhập liệu — bấm vào đúng ô cần dán rồi thử lại.')),
        );
        break;
      default:
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Không dán được vào trang này.')),
        );
    }
  }

  static const _zipTextExtensions = {
    'dart', 'yaml', 'yml', 'json', 'md', 'kts', 'gradle', 'xml', 'html', 'js',
    'css', 'txt', 'properties', 'gitignore', 'toml', 'lock', 'sh',
  };

  Future<void> _pickZipAndPaste(BuildContext sheetContext) async {
    const typeGroup = XTypeGroup(label: 'zip', extensions: ['zip']);
    final f = await openFile(acceptedTypeGroups: [typeGroup]);
    if (f == null) return;
    final bytes = await f.readAsBytes();
    final archive = ZipDecoder().decodeBytes(bytes);
    final files = <String, String>{};
    for (final entry in archive) {
      if (!entry.isFile) continue;
      final ext = entry.name.contains('.') ? entry.name.split('.').last.toLowerCase() : '';
      if (!_zipTextExtensions.contains(ext)) continue;
      try {
        files[entry.name] = utf8.decode(entry.content as List<int>, allowMalformed: true);
      } catch (_) {}
    }
    if (files.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(sheetContext).showSnackBar(
          const SnackBar(content: Text('Không đọc được file text nào trong zip này.')),
        );
      }
      return;
    }
    final formatted = '${CodeZipExporter.formatInstructionPrompt}\n\n'
        '--- NỘI DUNG CÁC FILE ---\n\n'
        '${CodeZipExporter.formatForSharing(files)}';
    if (sheetContext.mounted) Navigator.pop(sheetContext, formatted);
  }

  Future<void> _openPastePicker(StorageService storage) async {
    final docs = storage.sourceDocumentsSorted;
    final textController = TextEditingController();
    final result = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 16, right: 16, top: 16,
          bottom: 16 + MediaQuery.of(ctx).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Dán vào ô đang chọn trên trang', style: Theme.of(ctx).textTheme.titleMedium),
            const SizedBox(height: 4),
            const Text('Hãy bấm/chạm vào ô cần dán (bình luận, chat, form...) TRƯỚC khi chọn nội dung.',
                style: TextStyle(fontSize: 12)),
            const SizedBox(height: 12),
            TextField(
              controller: textController,
              maxLines: 4,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'Hoặc gõ/dán văn bản tuỳ ý',
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: textController.text.trim().isEmpty
                    ? null
                    : () => Navigator.pop(ctx, textController.text),
                child: const Text('Dán văn bản trên'),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () => _pickZipAndPaste(ctx),
                icon: const Icon(Icons.folder_zip_outlined),
                label: const Text('Chọn file .zip (source code) — ghép toàn bộ file thành 1 văn bản'),
              ),
            ),
            if (docs.isNotEmpty) ...[
              const Divider(height: 24),
              Text('Hoặc chọn từ Tài liệu nguồn:', style: Theme.of(ctx).textTheme.labelLarge),
              ConstrainedBox(
                constraints: const BoxConstraints(maxHeight: 240),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: docs.length,
                  itemBuilder: (_, i) => ListTile(
                    dense: true,
                    title: Text(docs[i].title, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text('${docs[i].content.length} ký tự', style: const TextStyle(fontSize: 11)),
                    onTap: () => Navigator.pop(ctx, docs[i].content),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
    if (result != null && result.trim().isNotEmpty) {
      await _pasteIntoFocusedElement(result);
    }
  }

  /// Bấm nút back (AppBar hoặc nút/vuốt back của điện thoại) trước tiên hỏi
  /// CHÍNH WebView "còn trang trước trong lịch sử duyệt của mày không" — có
  /// thì lùi lại đúng trang đó (y hệt trình duyệt thật); chỉ khi KHÔNG còn
  /// gì để lùi mới thật sự thoát màn hình này. Vá lỗi người dùng phản ánh:
  /// nút back trước đây LUÔN thoát thẳng ra "Tài liệu nguồn" ngay cả khi
  /// đang xem trang thứ 5-6 trong 1 phiên duyệt, "chẳng khác nào nút đó là
  /// thoát trình duyệt" — vì trước đây không có bước hỏi lịch sử này, back
  /// luôn đồng nghĩa với pop cả Route.
  Future<void> _handleBack() async {
    final canGoBack = await _controller.canGoBack();
    if (canGoBack) {
      await _controller.goBack();
      return;
    }
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final storage = context.read<ChatProvider>().storage;
    return PopScope(
      canPop: false,
      // FIX-v30 (xem HANDOFF.md mục 44): tra cứu THẬT qua tài liệu chính
      // thức api.flutter.dev/docs.flutter.dev (trước đó là ĐOÁN, không
      // tra) — xác nhận tên tham số ĐÚNG của PopScope ở Flutter 3.44 là
      // `onPopInvokedWithResult` (chữ ký `(bool didPop, T? result)`).
      // `onPopInvokedWithPop` (bản trước) và `onPopInvoked` (bản trước đó
      // nữa, dù tồn tại nhưng đã deprecated từ Flutter 3.22) đều SAI/không
      // phải bản hiện hành — xem nguồn:
      // https://docs.flutter.dev/release/breaking-changes/popscope-with-result
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        await _handleBack();
      },
      child: Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          tooltip: 'Lùi lại trang trước (trong trình duyệt)',
          onPressed: _handleBack,
        ),
        title: TextField(
          controller: _urlController,
          decoration: const InputDecoration(
            border: InputBorder.none,
            hintText: 'Nhập địa chỉ web...',
          ),
          keyboardType: TextInputType.url,
          textInputAction: TextInputAction.go,
          onSubmitted: _goTo,
        ),
        actions: [
          // Đúng phản ánh: mở trình duyệt từ lối tắt mới ở chat (mục 45)
          // khiến màn hình này không còn LUÔN được mở từ "Tài liệu nguồn"
          // nữa — nút back giờ có thể quay thẳng về màn hình chat, không
          // còn đường nào tới "Tài liệu nguồn" (nơi xem lại tài liệu đã
          // trích xuất, chọn nhiều tài liệu để "Tổng hợp"...) TỪ TRONG
          // trình duyệt nữa. Thêm lối tắt ngay đây, dùng `pushReplacement`
          // (không `push` chồng thêm 1 route) để bấm back tiếp theo không
          // bị kẹt qua lại giữa 2 màn hình.
          IconButton(
            tooltip: 'Tài liệu nguồn — Thư ký AI',
            icon: const Icon(Icons.auto_awesome_outlined),
            onPressed: () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const SourceDocumentsScreen()),
            ),
          ),
          IconButton(
            tooltip: 'Trích xuất nội dung trang',
            icon: _extracting
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.content_paste_go),
            onPressed: _extracting ? null : () => _extractAndSave(storage),
          ),
          IconButton(
            tooltip: 'Chạy Python (từ nội dung trang)',
            icon: const Icon(Icons.play_circle_outline),
            onPressed: _runPythonFromPage,
          ),
          IconButton(
            tooltip: 'Đóng gói thành .zip (từ nội dung trang)',
            icon: const Icon(Icons.folder_zip_outlined),
            onPressed: _packageZipFromPage,
          ),
          PopupMenuButton<int>(
            tooltip: 'Cách trích xuất khác',
            icon: const Icon(Icons.more_vert),
            onSelected: (v) {
              switch (v) {
                case 0:
                  if (!_extracting) _extractCanvasText(storage);
                  break;
                case 1:
                  if (!_ocrRunning) _extractViaOcr(storage);
                  break;
                case 2:
                  if (!_extracting) _extractInfiniteScroll(storage);
                  break;
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 0, child: Text('Đọc chữ canvas (chính xác, thử trước)')),
              PopupMenuItem(value: 1, child: Text('OCR (chụp màn hình)')),
              PopupMenuItem(value: 2, child: Text('Cuộn & gom toàn bộ trang')),
            ],
          ),
          IconButton(
            tooltip: 'Dán nội dung vào ô đang chọn',
            icon: const Icon(Icons.paste),
            onPressed: () => _openPastePicker(storage),
          ),
          IconButton(
            tooltip: 'Tải lại',
            icon: const Icon(Icons.refresh),
            onPressed: () => _controller.reload(),
          ),
        ],
      ),
      body: Column(
        children: [
          SecretaryProviderBar(storage: storage),
          if (_loading) const LinearProgressIndicator(minHeight: 2),
          if (_downloading)
            Container(
              width: double.infinity,
              color: Theme.of(context).colorScheme.primaryContainer,
              padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
              child: const Row(
                children: [
                  SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
                  SizedBox(width: 8),
                  Text('Đang tải file đính kèm...'),
                ],
              ),
            ),
          Expanded(child: RepaintBoundary(key: _webviewKey, child: WebViewWidget(controller: _controller))),
        ],
      ),
      ),
    );
  }

  /// Nút "Chạy Python" mới ở AppBar — xem `RunPythonFromTextDialog` để biết
  /// lý do KHÔNG tự động chạy thẳng mà mở hộp thoại cho xem/sửa code trước
  /// (đa số web chat AI không để dấu ``` thật trong DOM nên không thể chắc
  /// chắn tự cắt đúng phần code).
  Future<void> _runPythonFromPage() async {
    String text;
    try {
      text = await _readVisibleText();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Không đọc được nội dung trang: $e')));
      }
      return;
    }
    if (text.trim().isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Trang này không có nội dung text để lấy code.')),
        );
      }
      return;
    }
    final match = RegExp(r'```(?:python|py)?\s*\n([\s\S]*?)```').firstMatch(text);
    final detected = match?.group(1)?.trim();
    if (!mounted) return;
    await showDialog(
      context: context,
      builder: (_) => RunPythonFromTextDialog(initialCode: detected ?? text),
    );
  }

  /// Nút "Đóng gói .zip" mới ở AppBar — tái dùng NGUYÊN `CodeZipExporter`
  /// đã có sẵn cho luồng dán vào chat (Tier 3), áp dụng lại với nội dung
  /// TRÍCH TRỰC TIẾP từ trang đang xem — đỡ phải trích xuất xong rồi vòng
  /// qua "Tài liệu nguồn" → "Tổng hợp" chỉ để ghép lại thành zip.
  Future<void> _packageZipFromPage() async {
    String text;
    try {
      text = await _readVisibleText();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Không đọc được nội dung trang: $e')));
      }
      return;
    }
    if (text.trim().isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Trang này không có nội dung text để đóng gói.')),
        );
      }
      return;
    }
    final bytes = CodeZipExporter.exportFromResponse(text);
    if (bytes == null) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text(
            'Không tìm thấy khối code có đường dẫn file (dạng ```đường/dẫn/file.ext) trong '
            'nội dung trang — trang cần hiển thị đúng khuôn ĐÃ báo cho AI theo hướng dẫn '
            'định dạng (Tier 3) thì mới nhận diện được.',
          )),
        );
      }
      return;
    }
    if (!mounted) return;
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ZipEditScreen(
          initialBytes: Uint8List.fromList(bytes),
          initialName: 'from_web_${DateTime.now().millisecondsSinceEpoch}.zip',
        ),
      ),
    );
  }
}

/// Thanh nhỏ cho chọn provider/API RIÊNG cho tác vụ "Thư ký AI" (tổng hợp
/// tài liệu nguồn, sửa source code zip) — ĐỘC LẬP với provider của đoạn
/// chat đang mở. Hữu ích khi muốn dùng 1 model rẻ/nhanh riêng cho việc
/// trích xuất/tổng hợp, khác với model đang dùng để trò chuyện chính.
/// Để trống ("Mặc định — theo đoạn chat") thì mọi nơi tự rơi về provider
/// của đoạn chat đang mở như trước (không đổi hành vi cũ).
class SecretaryProviderBar extends StatefulWidget {
  final StorageService storage;
  const SecretaryProviderBar({required this.storage});

  @override
  State<SecretaryProviderBar> createState() => SecretaryProviderBarState();
}

class SecretaryProviderBarState extends State<SecretaryProviderBar> {
  @override
  Widget build(BuildContext context) {
    final providers = widget.storage.providers.values.toList();
    final currentId = widget.storage.secretaryProviderId;
    // Nếu id đã lưu không còn tồn tại (provider bị xoá) thì coi như chưa chọn.
    final validCurrentId = providers.any((p) => p.id == currentId) ? currentId : null;

    return Container(
      width: double.infinity,
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Row(
        children: [
          const Icon(Icons.smart_toy_outlined, size: 16),
          const SizedBox(width: 6),
          const Text('Thư ký AI dùng:', style: TextStyle(fontSize: 12)),
          const SizedBox(width: 8),
          Expanded(
            child: DropdownButton<String?>(
              isExpanded: true,
              isDense: true,
              underline: const SizedBox.shrink(),
              value: validCurrentId,
              hint: const Text('Mặc định — theo đoạn chat đang mở', style: TextStyle(fontSize: 12)),
              items: [
                const DropdownMenuItem<String?>(
                  value: null,
                  child: Text('Mặc định — theo đoạn chat đang mở', style: TextStyle(fontSize: 12)),
                ),
                ...providers.map((p) => DropdownMenuItem<String?>(
                      value: p.id,
                      child: Text(p.name, style: const TextStyle(fontSize: 12), overflow: TextOverflow.ellipsis),
                    )),
              ],
              onChanged: (id) {
                setState(() => widget.storage.secretaryProviderId = id);
              },
            ),
          ),
        ],
      ),
    );
  }
}
