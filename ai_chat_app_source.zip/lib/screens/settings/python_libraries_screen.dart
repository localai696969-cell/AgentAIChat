import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../services/python_sandbox_service.dart';
import '../../services/python_wheel_manager.dart';

/// Cho phép người dùng thêm file `.whl` (gói Python đã đóng gói sẵn) để
/// sandbox Python (Tier 2 — xem HANDOFF.md mục 35) cài bằng
/// `micropip.install("emfs:...")`, KHÔNG cần mạng LÚC CHẠY code (khác với
/// việc TẢI file .whl về máy, cái đó vẫn cần mạng và do tiến trình chính
/// của app làm, không phải sandbox — xem [_installFromUrl]).
///
/// 2 cách thêm: (1) "Cài từ URL" — app tự tải file .whl từ 1 link do người
/// dùng dán vào (ví dụ mục "Download files" của gói trên pypi.org); (2)
/// "Upload .whl" — tự tải bằng trình duyệt máy tính rồi chuyển file vào
/// điện thoại, dùng khi thiết bị không truy cập được link trực tiếp. Gói
/// THUẦN Python (không có phần biên dịch C/Rust) luôn cài được; gói có
/// phần biên dịch (numpy, lxml...) chỉ cài được nếu đó là bản `.whl` build
/// RIÊNG cho `wasm32-emscripten` (khác bản Windows/Linux/macOS bình
/// thường) — nếu sai bản, `micropip` sẽ báo lỗi rõ ràng ngay khi cài, không
/// phải app chặn.
class PythonLibrariesScreen extends StatefulWidget {
  const PythonLibrariesScreen({super.key});

  @override
  State<PythonLibrariesScreen> createState() => _PythonLibrariesScreenState();
}

class _PythonLibrariesScreenState extends State<PythonLibrariesScreen> {
  List<String> _wheels = [];
  bool _busy = false;
  String? _lastError;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final names = await PythonWheelManager.instance.list();
    if (mounted) setState(() => _wheels = names);
  }

  Future<void> _pickAndInstall() async {
    const typeGroup = XTypeGroup(label: 'whl', extensions: ['whl']);
    final f = await openFile(acceptedTypeGroups: [typeGroup]);
    if (f == null) return;
    setState(() {
      _busy = true;
      _lastError = null;
    });
    try {
      final bytes = await f.readAsBytes();
      await _saveAndInstall(f.name, bytes);
    } catch (e) {
      _lastError = 'Lỗi đọc/cài file: $e';
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// Tải file `.whl` TRỰC TIẾP từ 1 URL (ví dụ trang "Download files" của
  /// gói trên PyPI, hoặc kho package của chính Pyodide) — quan trọng: đây
  /// KHÔNG phải sandbox tự tải, mà là tiến trình chính của app (vốn đã có
  /// quyền mạng để gọi API model) tải hộ rồi mới đưa bytes vào sandbox y
  /// hệt đường đi khi upload file cục bộ — không đụng gì tới ranh giới
  /// "sandbox không mạng lúc CHẠY code" đã mô tả trong python_sandbox_service.dart.
  /// Thêm cách này để đỡ phải tự tải bằng trình duyệt máy tính rồi chuyển
  /// file qua điện thoại thủ công — vẫn KHÔNG đảm bảo gói đó cài được (bản
  /// phải build đúng cho `wasm32-emscripten`), chỉ đỡ tốn công đưa file vào.
  Future<void> _installFromUrl() async {
    final urlController = TextEditingController();
    final url = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Cài thư viện từ URL'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Dán link tải trực tiếp 1 file .whl (ví dụ mục "Download files" '
              'của gói trên pypi.org, hoặc kho package của Pyodide). App tự '
              'tải rồi cài vào sandbox — KHÔNG đảm bảo chạy được nếu gói có '
              'phần biên dịch C/Rust không đúng bản wasm32-emscripten.',
              style: TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: urlController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'URL file .whl',
                hintText: 'https://files.pythonhosted.org/.../ten_goi-1.0.0-py3-none-any.whl',
              ),
              keyboardType: TextInputType.url,
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Huỷ')),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, urlController.text.trim()),
            child: const Text('Tải & cài'),
          ),
        ],
      ),
    );
    if (url == null || url.isEmpty) return;
    final uri = Uri.tryParse(url);
    if (uri == null || !(uri.isScheme('HTTPS') || uri.isScheme('HTTP'))) {
      setState(() => _lastError = 'URL không hợp lệ: "$url"');
      return;
    }
    setState(() {
      _busy = true;
      _lastError = null;
    });
    try {
      final resp = await http.get(uri).timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) {
        _lastError = 'Tải thất bại (HTTP ${resp.statusCode}): $url';
        return;
      }
      var name = uri.pathSegments.isNotEmpty ? uri.pathSegments.last : 'downloaded.whl';
      if (!name.toLowerCase().endsWith('.whl')) name = '$name.whl';
      await _saveAndInstall(name, resp.bodyBytes);
    } catch (e) {
      _lastError = 'Lỗi tải/cài từ URL: $e';
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _saveAndInstall(String fileName, List<int> bytes) async {
    await PythonWheelManager.instance.add(fileName, bytes);
    if (!mounted) return;
    final result = await PythonSandboxService.instance.installWheel(context, fileName, bytes);
    if (!result.ok) {
      _lastError = '"$fileName": ${result.error ?? "lỗi không rõ"}';
      // Vẫn giữ file đã lưu (biết đâu sửa được ở sandbox lần sau/bản
      // Pyodide mới hơn) — chỉ báo lỗi, không tự xoá.
    }
    await _reload();
  }

  Future<void> _remove(String name) async {
    await PythonWheelManager.instance.remove(name);
    await _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Thư viện Python cho sandbox')),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton.extended(
            heroTag: 'installUrl',
            onPressed: _busy ? null : _installFromUrl,
            icon: const Icon(Icons.link),
            label: const Text('Cài từ URL'),
          ),
          const SizedBox(height: 10),
          FloatingActionButton.extended(
            heroTag: 'uploadLocal',
            onPressed: _busy ? null : _pickAndInstall,
            icon: _busy
                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.add),
            label: Text(_busy ? 'Đang cài...' : 'Upload .whl'),
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            child: const Text(
              'Sandbox Python mặc định chỉ có thư viện chuẩn (không mạng, '
              'không tự pip install lúc CHẠY code). Thêm thư viện bằng 1 '
              'trong 2 cách: "Cài từ URL" (app tự tải file .whl hộ — nhanh '
              'nhất) hoặc "Upload .whl" (tự tải bằng trình duyệt máy tính '
              'rồi chuyển file vào điện thoại, dùng khi máy không vào được '
              'link trực tiếp). Cài xong sẽ tự nhớ, không cần cài lại mỗi '
              'lần mở app. Gói thuần Python (không có phần biên dịch '
              'C/Rust) luôn cài được; gói có phần biên dịch (numpy, lxml...) '
              'chỉ cài được nếu đúng bản build cho wasm32-emscripten.',
              style: TextStyle(fontSize: 12),
            ),
          ),
          if (_lastError != null)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              color: Theme.of(context).colorScheme.errorContainer,
              child: Text(_lastError!, style: TextStyle(color: Theme.of(context).colorScheme.onErrorContainer)),
            ),
          Expanded(
            child: _wheels.isEmpty
                ? const Center(child: Text('Chưa có thư viện nào được cài.'))
                : ListView.builder(
                    itemCount: _wheels.length,
                    itemBuilder: (_, i) {
                      final name = _wheels[i];
                      return ListTile(
                        leading: const Icon(Icons.inventory_2_outlined),
                        title: Text(PythonWheelManager.packageNameFromFile(name)),
                        subtitle: Text(name, style: const TextStyle(fontSize: 11, fontFamily: 'monospace')),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => _remove(name),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
