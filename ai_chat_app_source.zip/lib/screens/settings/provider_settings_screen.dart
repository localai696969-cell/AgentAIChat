import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/provider_config.dart';
import '../../providers/chat_provider.dart';
import 'provider_edit_screen.dart';

class ProviderSettingsScreen extends StatelessWidget {
  const ProviderSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();
    final providers = chat.storage.providers.values.toList();
    final imageGenId = chat.storage.imageGenProviderId;

    return Scaffold(
      appBar: AppBar(title: const Text('Provider API')),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        label: const Text('Thêm Provider'),
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const ProviderEditScreen()),
        ),
      ),
      body: providers.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Chưa có Provider API nào.\nApp không hardcode model — hãy tự thêm endpoint '
                  '(OpenAI-compatible / Anthropic-compatible / Custom) mà bạn muốn dùng.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView.builder(
              itemCount: providers.length,
              itemBuilder: (_, i) {
                final p = providers[i];
                final isImageGen = p.id == imageGenId;
                return ListTile(
                  leading: Icon(p.isDefault ? Icons.star : Icons.star_border),
                  title: Text(p.name),
                  subtitle: Text(
                    '${p.model}  •  ${_formatLabel(p.format)}  •  ctx ${p.maxContextTokens}'
                    '${isImageGen ? '  •  🖼 Provider sinh ảnh' : ''}',
                  ),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => ProviderEditScreen(existing: p)),
                  ),
                  trailing: PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'default') {
                        for (final other in providers) {
                          other.isDefault = other.id == p.id;
                          await other.save();
                        }
                      } else if (v == 'delete') {
                        await p.delete();
                      } else if (v == 'imageGen') {
                        chat.storage.imageGenProviderId = p.id;
                      } else if (v == 'imageGenOff') {
                        chat.storage.imageGenProviderId = null;
                      }
                    },
                    itemBuilder: (_) => [
                      const PopupMenuItem(value: 'default', child: Text('Đặt làm mặc định')),
                      PopupMenuItem(
                        value: isImageGen ? 'imageGenOff' : 'imageGen',
                        child: Text(isImageGen ? 'Bỏ dùng làm Provider sinh ảnh' : 'Dùng làm Provider sinh ảnh (DALL-E/Stability...)'),
                      ),
                      const PopupMenuItem(value: 'delete', child: Text('Xóa')),
                    ],
                  ),
                );
              },
            ),
    );
  }

  String _formatLabel(ApiFormat f) {
    switch (f) {
      case ApiFormat.openaiCompatible:
        return 'OpenAI-compatible';
      case ApiFormat.anthropicCompatible:
        return 'Anthropic-compatible';
      case ApiFormat.custom:
        return 'Custom';
    }
  }
}
