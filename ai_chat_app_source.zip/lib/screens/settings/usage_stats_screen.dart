import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/provider_config.dart';
import '../../providers/chat_provider.dart';
import '../../services/usage_service.dart';

class UsageStatsScreen extends StatelessWidget {
  const UsageStatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final chat = context.watch<ChatProvider>();
    final providers = chat.storage.providers.values.toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Thống kê token')),
      body: providers.isEmpty
          ? const Center(child: Text('Chưa có Provider nào để thống kê.'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: providers.length,
              itemBuilder: (_, i) => _ProviderUsageCard(provider: providers[i], usageService: chat.usageService),
            ),
    );
  }
}

class _ProviderUsageCard extends StatelessWidget {
  final ProviderConfig provider;
  final UsageService usageService;
  const _ProviderUsageCard({required this.provider, required this.usageService});

  @override
  Widget build(BuildContext context) {
    final today = usageService.todayUsage(provider.id);
    final month = usageService.monthUsage(provider.id);
    final quota = provider.dailyTokenQuota;
    final ratio = quota != null && quota > 0 ? (today.totalTokens / quota).clamp(0.0, 1.0) : null;
    final theme = Theme.of(context);

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(provider.name, style: theme.textTheme.titleMedium),
            Text(provider.model, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline)),
            const SizedBox(height: 12),

            Text('Hôm nay: ${_fmt(today.totalTokens)} token  •  ${today.requests} lượt gọi'),
            if (quota != null) ...[
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: ratio,
                  minHeight: 8,
                  backgroundColor: theme.colorScheme.surfaceContainerHighest,
                  valueColor: AlwaysStoppedAnimation(
                    (ratio ?? 0) > 0.9 ? Colors.red : (ratio ?? 0) > 0.7 ? Colors.orange : theme.colorScheme.primary,
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '${_fmt(today.totalTokens)} / ${_fmt(quota)} token/ngày (${((ratio ?? 0) * 100).toStringAsFixed(0)}%)',
                style: theme.textTheme.bodySmall,
              ),
            ] else
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  'Chưa khai báo hạn mức/ngày — vào Sửa Provider để nhập nếu muốn theo dõi %.',
                  style: theme.textTheme.bodySmall?.copyWith(fontStyle: FontStyle.italic),
                ),
              ),

            const Divider(height: 20),
            Text('Tháng này: ${_fmt(month.totalTokens)} token  •  ${month.requests} lượt gọi'),
            Text(
              '(prompt: ${_fmt(month.promptTokens)} • completion: ${_fmt(month.completionTokens)})',
              style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline),
            ),
          ],
        ),
      ),
    );
  }

  String _fmt(int n) {
    final s = n.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }
}
