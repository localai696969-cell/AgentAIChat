import '../models/source_document.dart';

/// Dựng prompt cho tác vụ "thư ký AI": đọc N tài liệu nguồn (upload hoặc
/// trích xuất từ webview) + yêu cầu của người dùng, rồi sinh MỘT bản trả
/// lời cuối cùng theo ĐÚNG cú pháp mà các exporter sẵn có (DocxExporter/
/// PptxExporter/XlsxExporter/CodeZipExporter) hiểu được — để không cần viết
/// thêm exporter mới, và chỉ tốn 1 lần gọi API cho toàn bộ việc tổng hợp.
import 'image_pool_service.dart';

class SecretaryPromptBuilder {
  /// Câu nhắc NGẮN, dùng độc lập với mọi thứ khác trong file này — copy dán
  /// vào ĐẦU 1 câu hỏi bất kỳ trong chat bình thường (không cần qua luồng
  /// "thư ký AI") để nhắc AI LUÔN bọc code Python trong khối ```python khi
  /// trả lời. Xem `message_bubble.dart`/`RunnableCodeBlockBuilder`
  /// (mục 38) — nút ▶ "Chạy trong sandbox" CHỈ tự động gắn được cho code
  /// nằm trong khối ```python thật; nếu AI trả lời code trần (không bọc),
  /// app có gắng ĐOÁN cục bộ (mục 45, `looksLikeUnfencedPython`) nhưng
  /// không chắc chắn — dùng câu nhắc này để tăng khả năng AI trả lời đúng
  /// khuôn NGAY TỪ ĐẦU, khỏi phải đoán hay dán tay lại.
  static const pythonFormatReminder =
      'Khi đưa code Python trong câu trả lời, LUÔN bọc trong khối markdown '
      'dạng ```python ... ``` (ba dấu backtick + chữ python ở đầu, ba dấu '
      'backtick ở cuối) — không viết code trần ngoài khối này.';

  /// Chỉ phần "định dạng trả lời bắt buộc" — PUBLIC để dùng làm prompt
  /// "mồi" copy ra ngoài (dán cho 1 AI khác/người khác đọc TRƯỚC KHI họ trả
  /// lời), giống hệt cách CodeZipExporter.formatInstructionPrompt làm cho
  /// riêng zip — giờ áp dụng chung cho cả docx/pptx/xlsx, để nếu bên ngoài
  /// đã trả lời đúng định dạng sẵn, app xuất file THẲNG (0 token), khỏi cần
  /// tự gọi AI để "dịch lại" định dạng.
  /// TIER 3 — dùng khi CẢ JSON DSL tĩnh (Tier 1) LẪN sandbox Python cô lập
  /// trong app (Tier 2 — xem [_pythonBlockGuide]/HANDOFF.md) đều không đủ:
  /// ví dụ cần thư viện ngoài thật (python-docx/pptx/openpyxl) hoặc cần
  /// mạng mà sandbox Tier 2 (cố tình không có mạng) không cho phép. Nhờ 1
  /// AI CÓ SẴN khả năng chạy code (Claude.ai, ChatGPT Code Interpreter,
  /// Google Colab...) tự viết VÀ TỰ CHẠY Python trên hạ tầng CỦA HỌ, rồi
  /// đưa link tải file kết quả — app chỉ tải file đã hoàn thiện về (dùng
  /// lại đúng cơ chế tải file qua link ở WebviewCaptureScreen).
  static String tier3PythonPrompt(String outputFormat) {
    final lib = switch (outputFormat) {
      'docx' => 'python-docx',
      'pptx' => 'python-pptx',
      'xlsx' => 'openpyxl',
      'epub' => 'ebooklib',
      _ => 'thư viện phù hợp',
    };
    return 'Tôi cần 1 file .$outputFormat với nội dung/định dạng phức tạp mà '
        'JSON mô tả tĩnh không đủ biểu đạt. Bạn hãy TỰ VIẾT VÀ TỰ CHẠY code '
        'Python (dùng $lib) ngay trên môi trường thực thi code của bạn để tạo '
        'ra file đó, rồi đưa cho tôi LINK TẢI XUỐNG file đã hoàn thiện '
        '(không phải đưa code cho tôi tự chạy — tôi không có môi trường '
        'chạy Python). Yêu cầu cụ thể: ';
  }

  /// Hướng dẫn dùng khối "python" (Tier 2 — xem HANDOFF.md mục "Sandbox
  /// Python"): app tự chạy đoạn code này TRONG SANDBOX CÔ LẬP TRÊN MÁY
  /// (không mạng, không đọc được key/file khác của app), CHỈ để tính toán/
  /// xử lý dữ liệu trước khi vẽ ảnh/lập bảng — không phải mọi việc đều nên
  /// dùng "python", vì JSON tĩnh (chart/diagram/table) đã đủ cho phần lớn
  /// trường hợp và không có rủi ro/độ trễ chạy code.
  static String _pythonBlockGuide() {
    return 'Về khối "python" (chỉ dùng khi thật cần, KHÔNG phải mặc định): '
        'code chạy TRONG SANDBOX CÔ LẬP, KHÔNG có mạng lúc chạy. Mặc định '
        'CHỈ có thư viện chuẩn Python (math, statistics, json, itertools, '
        'collections...) — KHÔNG numpy/PIL/pandas... TRỪ KHI người dùng đã '
        'tự upload thêm file .whl (màn hình "Thư viện Python cho sandbox" — '
        'gói thuần Python như openpyxl thường cài được; gói có phần biên '
        'dịch C như lxml/numpy chỉ cài được nếu đúng bản build cho '
        'wasm32-emscripten). Nếu không chắc thư viện nào đã được cài, cứ '
        '`import` thử trong code — nếu `ImportError`, sandbox sẽ báo lỗi rõ '
        'ràng, khi đó chuyển sang cách khác (JSON tĩnh, hoặc báo người dùng '
        'cần upload đúng thư viện) thay vì đoán mò. Đầu vào đọc qua biến '
        'SANDBOX_INPUTS (dict). Đầu ra PHẢI ghi vào biến '
        'OUTPUT_FILES (dict) trước khi kết thúc: OUTPUT_FILES["image"] = '
        'bytes PNG cho ảnh, hoặc OUTPUT_FILES["headers"]/["rows"] = list '
        '(sẽ tự json.dumps) cho bảng, hoặc OUTPUT_FILES["text"] = chuỗi cho '
        'đoạn văn. Nếu việc cần làm quá phức tạp cho sandbox cô lập này '
        '(cần thư viện ngoài như python-docx/openpyxl thật, cần mạng...), '
        'đừng dùng "python" — báo lại để chuyển sang nhờ AI khác tự chạy '
        'trên hạ tầng của họ (Tier 3).';
  }

  /// CHỈ ghép thêm text (đọc kho ảnh trong bộ nhớ — KHÔNG gọi mạng, KHÔNG
  /// gọi API nào) — dùng được an toàn ở ĐÂY vì `formatInstruction` bản
  /// thân nó cũng chỉ là 1 hàm trả về CHUỖI, không tự gọi AI. Hàm này được
  /// dùng ở 2 nơi: (1) nút 💡 "Copy prompt định dạng" (`ExportMenu`,
  /// `_pickZipAndPaste`...) — copy để dán cho AI NGOÀI (Tier 3, KHÔNG tốn
  /// token của app); (2) bên trong `build()` cho Tier 1 (`compileSources`,
  /// CÓ gọi API, tốn phí — nhưng đây là lệnh gọi ĐÃ CÓ SẴN từ trước, không
  /// phải chi phí MỚI phát sinh do có kho ảnh).
  static String formatInstruction(String outputFormat) {
    final poolNote = ImagePoolService.instance.describeForPrompt();
    switch (outputFormat) {
      case 'docx':
        return 'Khi trả lời, CHỈ trả lời bằng 1 khối JSON duy nhất (không thêm '
            'chữ nào khác ngoài JSON) theo đúng schema sau:\n'
            '{"title": "...", "blocks": [\n'
            '  {"type":"heading","level":1,"text":"..."},\n'
            '  {"type":"paragraph","runs":[{"text":"...","bold":true,"italic":false,"color":"#RRGGBB"}]},\n'
            '  {"type":"bullet_list","items":["...","..."]},\n'
            '  {"type":"numbered_list","items":["...","..."]},\n'
            '  {"type":"table","headers":["...","..."],"rows":[["...","..."]]},\n'
            '  {"type":"image","ref":"(id ảnh có sẵn, xem danh sách bên dưới nếu có — ƯU TIÊN cách này nếu ảnh cần dùng nằm trong danh sách đó)","base64":"(dữ liệu ảnh PNG/JPEG mã hoá base64, dùng nếu bạn tự tạo/có sẵn ảnh KHÁC danh sách trên và KHÔNG có URL công khai)","url":"https://...(nếu có ảnh sẵn phù hợp, ƯU TIÊN cách này nếu có URL thật)","prompt":"mô tả ảnh cần tạo (chỉ điền nếu KHÔNG có ref/base64/URL)","caption":"..."},\n'
            '  {"type":"chart","chartType":"bar","title":"...","data":[{"label":"Q1","value":120}]},\n'
            '  {"type":"diagram","shapes":[{"id":1,"label":"Bắt đầu","x":0,"y":0}],"connectors":[{"from":1,"to":2}]},\n'
            '  {"type":"python","produces":"image|table|text","code":"...","inputs":{...},"caption":"..."},\n'
            '  {"type":"toc"},\n'
            '  {"type":"page_break"}\n'
            ']}\n'
            'Dùng "chart"/"diagram" cho biểu đồ/sơ đồ minh hoạ (tự vẽ ra ảnh, '
            'không cần bạn vẽ). "runs" dùng để in đậm/nghiêng/màu 1 phần câu.\n'
            '${_pythonBlockGuide()}'
            '${poolNote.isEmpty ? '' : '\n$poolNote'}';
      case 'pptx':
        return 'Khi trả lời, CHỈ trả lời bằng 1 khối JSON duy nhất theo schema:\n'
            '{"slides": [{"title":"...", "bullets":["...","..."], '
            '"images":[{"type":"chart","chartType":"bar","data":[{"label":"Q1","value":120}]}, '
            '{"type":"python","code":"...","inputs":{...}} (Python trả OUTPUT_FILES["image"] = bytes PNG), '
            '{"ref":"(id ảnh có sẵn, xem danh sách bên dưới nếu có)"}, '
            '{"base64":"(dữ liệu ảnh PNG/JPEG mã hoá base64, nếu bạn tự tạo/có sẵn ảnh KHÁC danh sách trên và KHÔNG có URL công khai)"}, '
            '{"url":"https://...(nếu có ảnh sẵn, ƯU TIÊN nếu có URL thật)"}, {"prompt":"mô tả ảnh cần tạo (chỉ khi không có ref/base64/url)"}]}]}\n'
            'Mỗi phần tử trong "slides" là 1 slide. "images" tuỳ chọn, dùng '
            '"chart"/"diagram" để tự vẽ biểu đồ/sơ đồ minh hoạ, "python" chỉ khi '
            'cần TÍNH TOÁN dữ liệu trước khi vẽ mà "chart" tĩnh không làm được, '
            'hoặc "ref"/"url"/"prompt" cho ảnh minh hoạ khác.\n'
            '${_pythonBlockGuide()}'
            '${poolNote.isEmpty ? '' : '\n$poolNote'}';
      case 'xlsx':
        return 'Khi trả lời, CHỈ trả lời bằng 1 khối JSON duy nhất theo schema:\n'
            '{"sheets": [{"name":"Sheet1", "rows":[{"cells":[{"value":"Tên","bold":true},{"value":10}]}], '
            '"merges":["A1:B1"]}, '
            '{"name":"Sheet2","type":"python","code":"...","inputs":{...}} (Python trả '
            'OUTPUT_FILES["rows"] = JSON list các hàng, mỗi hàng {"cells":[{"value":...}]}) ]}\n'
            'Có thể dùng {"formula":"=SUM(A1:A10)"} thay cho "value" để Excel '
            'tự tính (không tự tính hộ, chỉ ghi công thức vào ô). Sheet kiểu '
            '"python" chỉ dùng khi cần tính toán/biến đổi dữ liệu phức tạp mà '
            'liệt kê "rows" tĩnh không khả thi.';
      case 'zip':
        return 'Khi trả lời, với MỖI file dùng đúng cú pháp sau: đặt đường '
            'dẫn file NGAY SAU dấu ``` mở đầu (ví dụ ```lib/main.dart), nội '
            'dung file đầy đủ bên trong khối. KHÔNG thêm lời dẫn ngoài các '
            'code block.';
      case 'txt':
        return 'Trả lời BÌNH THƯỜNG bằng văn bản thuần (không JSON, không '
            'markdown đặc biệt) — toàn bộ câu trả lời sẽ được ghi thẳng '
            'thành file .txt.';
      case 'epub':
        return 'Khi trả lời, CHỈ trả lời bằng 1 khối JSON duy nhất theo schema:\n'
            '{"title":"...", "author":"...", "chapters":[{"title":"Chương 1", '
            '"paragraphs":["đoạn văn 1","đoạn văn 2"]}]}\n'
            'Mỗi phần tử "chapters" là 1 chương; "paragraphs" là danh sách '
            'đoạn văn thuần (không markdown/HTML, tự chia đoạn hợp lý).';
      default:
        return '';
    }
  }

  static String build({
    required List<SourceDocument> sources,
    required String instruction,
    required String outputFormat, // 'docx' | 'pptx' | 'xlsx' | 'zip' | 'txt' | 'epub'
  }) {
    final buffer = StringBuffer();

    buffer.writeln('Bạn là thư ký tổng hợp tài liệu. Dưới đây là các tài liệu nguồn '
        'do người dùng cung cấp (upload hoặc trích xuất từ trang web họ đang xem). '
        'Đọc kỹ toàn bộ rồi thực hiện đúng yêu cầu bên dưới.');
    buffer.writeln();

    for (var i = 0; i < sources.length; i++) {
      final s = sources[i];
      buffer.writeln('--- TÀI LIỆU NGUỒN ${i + 1}: "${s.title}" (nguồn: ${s.sourceLabel}) ---');
      buffer.writeln(s.content);
      buffer.writeln();
    }

    buffer.writeln('--- YÊU CẦU CỦA NGƯỜI DÙNG ---');
    buffer.writeln(instruction.trim().isEmpty
        ? 'Tổng hợp lại toàn bộ nội dung trên thành 1 tài liệu rõ ràng, đầy đủ.'
        : instruction.trim());
    buffer.writeln();

    buffer.writeln('--- ĐỊNH DẠNG TRẢ LỜI BẮT BUỘC ---');
    buffer.writeln(formatInstruction(outputFormat));

    return buffer.toString();
  }
}
