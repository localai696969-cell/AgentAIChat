/// Các "module driver" Python CỐ ĐỊNH (viết 1 lần, không phải do AI tự sinh
/// mỗi lần chat) để chạy trong [PythonSandboxService] nhằm tạo ra định dạng
/// file MỚI mà không cần viết thêm 1 class Dart riêng (xem HANDOFF.md mục
/// 36 — trả lời câu hỏi "sao không tận dụng luôn sandbox Python thay vì
/// hardcode Dart cho mỗi định dạng").
///
/// Nguyên tắc: những định dạng có cấu trúc "zip + XML/text" (epub, và về
/// sau có thể thêm markdown-to-* khác) thì viết 1 lần bằng Python (CHỈ dùng
/// thư viện chuẩn `zipfile`/`io`/`html` — không cần cài `.whl` gì), nhúng
/// thẳng làm hằng số Dart, rồi ghép với dữ liệu JSON DSL do AI sinh
/// (SANDBOX_INPUTS) — giữ đúng độ tin cậy như Dart hardcode (code build
/// định dạng KHÔNG do AI tự viết lại mỗi lần, tránh sai cấu trúc), nhưng
/// KHÔNG cần thêm class Dart/export mới, không cần rebuild UI — thêm định
/// dạng mới = thêm 1 hằng số Python + 1 hàm gọi nó trong
/// `DslDocumentBuilder`.
library;

/// EPUB2 tối giản, tương thích rộng (Kindle/Play Books/Apple Books đều đọc
/// được EPUB2). Input mong đợi (đưa qua SANDBOX_INPUTS["doc"]):
/// `{"title": str, "author": str?, "chapters": [{"title": str, "paragraphs": [str,...]}]}`
/// Trả về bytes qua hàm `build_from_dict(doc) -> bytes`.
///
/// CHƯA kiểm chứng bằng cách mở thử trên trình đọc epub thật (không có môi
/// trường để test) — cấu trúc dựa đúng chuẩn EPUB2 (mimetype không nén +
/// container.xml + content.opf + toc.ncx), nhưng nếu gặp lỗi "file epub hỏng"
/// khi mở thật, gửi lại để sửa đúng chỗ.
const String epubMinPySource = r'''
import zipfile, io, html

def _esc(s):
    return html.escape(str(s), quote=False)

def build_from_dict(doc):
    title = doc.get("title", "Tai lieu")
    author = doc.get("author", "")
    chapters = doc.get("chapters") or [{"title": title, "paragraphs": doc.get("paragraphs", [])}]

    buf = io.BytesIO()
    zf = zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED)
    zf.writestr(zipfile.ZipInfo("mimetype"), "application/epub+zip", zipfile.ZIP_STORED)
    zf.writestr("META-INF/container.xml", """<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>""")

    manifest_items, spine_items, nav_points = [], [], []
    for i, ch in enumerate(chapters, start=1):
        cid = "chap%d" % i
        fname = cid + ".xhtml"
        ch_title = _esc(ch.get("title", "Chuong %d" % i))
        paras = ch.get("paragraphs", [])
        body = "".join("<p>%s</p>" % _esc(p) for p in paras)
        xhtml = """<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>%s</title></head>
<body><h1>%s</h1>%s</body>
</html>""" % (ch_title, ch_title, body)
        zf.writestr("OEBPS/" + fname, xhtml)
        manifest_items.append('<item id="%s" href="%s" media-type="application/xhtml+xml"/>' % (cid, fname))
        spine_items.append('<itemref idref="%s"/>' % cid)
        nav_points.append('<navPoint id="navpoint-%d" playOrder="%d"><navLabel><text>%s</text></navLabel><content src="%s"/></navPoint>' % (i, i, ch_title, fname))

    opf = """<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" unique-identifier="BookId" version="2.0">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:title>%s</dc:title>
    <dc:language>vi</dc:language>
    <dc:creator>%s</dc:creator>
    <dc:identifier id="BookId">urn:uuid:agentaichat-epub</dc:identifier>
  </metadata>
  <manifest>
    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
    %s
  </manifest>
  <spine toc="ncx">
    %s
  </spine>
</package>""" % (_esc(title), _esc(author), "".join(manifest_items), "".join(spine_items))
    zf.writestr("OEBPS/content.opf", opf)

    ncx = """<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <head><meta name="dtb:uid" content="urn:uuid:agentaichat-epub"/></head>
  <docTitle><text>%s</text></docTitle>
  <navMap>%s</navMap>
</ncx>""" % (_esc(title), "".join(nav_points))
    zf.writestr("OEBPS/toc.ncx", ncx)

    zf.close()
    return buf.getvalue()
''';
