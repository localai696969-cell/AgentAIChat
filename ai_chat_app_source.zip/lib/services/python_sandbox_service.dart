import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'keep_alive_service.dart';
import 'python_wheel_manager.dart';

/// Kết quả 1 lần chạy code Python trong sandbox.
class PythonSandboxResult {
  final bool ok;
  final String stdout;
  final String stderr;
  final String? error;
  /// Tên -> nội dung. Nếu Python trả bytes (vd ảnh PNG) thì giá trị là
  /// base64; nếu trả chuỗi/JSON thuần thì giữ nguyên chuỗi đó.
  final Map<String, String> files;

  PythonSandboxResult({
    required this.ok,
    required this.stdout,
    required this.stderr,
    required this.files,
    this.error,
  });

  factory PythonSandboxResult.failure(String error) =>
      PythonSandboxResult(ok: false, stdout: '', stderr: '', files: {}, error: error);
}

/// Chạy Python TRONG 1 WebView ẩn (Pyodide/WASM) — Tier 2 của mô hình xuất
/// file 3 tầng (xem HANDOFF.md). CHỈ dùng để tính toán/vẽ dữ liệu phục vụ
/// xuất docx/pptx/xlsx khi JSON DSL (Tier 1) không đủ biểu đạt; không phải
/// một "trình thông dịch Python đa năng" cho mục đích khác.
///
/// ĐỌC KỸ TRƯỚC KHI SỬA — ranh giới an toàn cố ý:
/// - WebView Android chạy ở tiến trình sandbox riêng của hệ thống, tách
///   biệt khỏi tiến trình chính chứa Hive (API key, hội thoại...).
/// - Trang HTML nạp vào (assets/sandbox/sandbox.html) có CSP chặn mọi
///   network request ra ngoài — xem chi tiết trong chính file đó.
/// - [run] CHỈ nhận đúng 2 tham số: `code` (chuỗi Python) và `inputs`
///   (JSON thuần). KHÔNG BAO GIỜ truyền `ProviderConfig`, API key, nội dung
///   Hive box, hay đường dẫn file thật của thiết bị vào đây. Nơi gọi (vd
///   [DslDocumentBuilder]) chịu trách nhiệm đảm bảo điều này.
/// - Có timeout cứng phía Dart; nếu quá hạn, WebView bị coi là "có thể
///   đang treo" và bị bỏ, lần chạy sau sẽ tạo WebView mới hoàn toàn.
/// - Giới hạn kích thước code đầu vào và tổng dung lượng output, tránh
///   một tin nhắn độc/lỗi làm app hết bộ nhớ.
class PythonSandboxService {
  PythonSandboxService._();
  static final PythonSandboxService instance = PythonSandboxService._();

  static const int maxCodeChars = 20000;
  static const int maxOutputBytes = 8 * 1024 * 1024; // 8MB tổng output/lần chạy
  static const Duration runTimeout = Duration(seconds: 20);
  static const Duration loadTimeout = Duration(seconds: 45); // lần đầu nạp Pyodide có thể chậm

  WebViewController? _controller;
  OverlayEntry? _overlayEntry;
  bool _pageLoaded = false;
  Completer<void>? _loadCompleter;
  final Map<String, Completer<PythonSandboxResult>> _pending = {};
  int _reqCounter = 0;
  int _wakelockRefCount = 0;

  /// Sandbox đã sẵn sàng chạy code ngay (Pyodide đã nạp xong) hay chưa —
  /// nơi gọi (UI) dùng để hiện đúng thông báo: nếu CHƯA sẵn sàng, lần
  /// [run] sắp tới sẽ mất thêm thời gian NẠP Pyodide lần đầu (tới
  /// [loadTimeout], thường 20-45s tuỳ máy) TRƯỚC KHI code thật sự bắt đầu
  /// chạy — khác với các lần sau (đã sẵn sàng) chỉ mất thời gian đúng bằng
  /// code chạy bao lâu.
  bool get isReady => _controller != null && _pageLoaded;

  /// Giữ CPU/màn hình không tự tắt (`wakelock_plus`) VÀ giữ tiến trình app
  /// không bị hệ điều hành tạm dừng khi khoá màn hình/chuyển app
  /// (`KeepAliveService` — foreground service thật, xem HANDOFF.md mục
  /// 42) trong lúc có tác vụ sandbox đang chạy. Dùng đếm tham chiếu vì có
  /// thể có nhiều lệnh `run`/`installWheel` gọi gần nhau (ví dụ tự cài lại
  /// nhiều wheel lúc khởi động) — chỉ TẮT khi KHÔNG còn tác vụ nào đang
  /// chạy.
  Future<T> _withWakelock<T>(Future<T> Function() body) async {
    _wakelockRefCount++;
    if (_wakelockRefCount == 1) {
      try {
        await WakelockPlus.enable();
      } catch (_) {
        // Không có quyền/plugin lỗi trên 1 số máy — không để lỗi wakelock
        // chặn luôn cả việc chạy code, coi như tính năng phụ.
      }
    }
    try {
      return await KeepAliveService.instance.run(body);
    } finally {
      _wakelockRefCount--;
      if (_wakelockRefCount <= 0) {
        _wakelockRefCount = 0;
        try {
          await WakelockPlus.disable();
        } catch (_) {}
      }
    }
  }

  /// Chạy [code] với dữ liệu [inputs] (phải là JSON-thuần: num/String/bool/
  /// List/Map, KHÔNG chứa object nhạy cảm). Cần [context] đang có [Overlay]
  /// (1 màn hình thật đang mở) để có thể mount WebView off-screen — cùng kỹ
  /// thuật với [ChartRenderer]. Trả về [PythonSandboxResult] với `ok=false`
  /// và `error` mô tả rõ nếu sandbox lỗi/không sẵn sàng/hết giờ — KHÔNG BAO
  /// GIỜ trả null im lặng, để nơi gọi báo được lỗi rõ ràng cho người dùng.
  Future<PythonSandboxResult> run(
    BuildContext context,
    String code, {
    Map<String, dynamic> inputs = const {},
  }) async {
    if (code.trim().isEmpty) {
      return PythonSandboxResult.failure('Không có code Python để chạy.');
    }
    if (code.length > maxCodeChars) {
      return PythonSandboxResult.failure(
          'Code Python vượt giới hạn $maxCodeChars ký tự (an toàn cho sandbox trên máy).');
    }
    return _withWakelock(() => _runInternal(context, code, inputs));
  }

  Future<PythonSandboxResult> _runInternal(
    BuildContext context,
    String code,
    Map<String, dynamic> inputs,
  ) async {
    try {
      await _ensureReady(context);
    } catch (e) {
      return PythonSandboxResult.failure(
          'Không khởi động được sandbox Python: $e\n'
          '(Có thể thiếu assets Pyodide — xem HANDOFF.md mục "Sandbox Python".)');
    }

    final id = 'r${_reqCounter++}';
    final completer = Completer<PythonSandboxResult>();
    _pending[id] = completer;

    final codeJs = jsonEncode(code);
    final inputsJs = jsonEncode(jsonEncode(inputs));
    try {
      await _controller!.runJavaScript('window.__runPython(${jsonEncode(id)}, $codeJs, $inputsJs);');
    } catch (e) {
      _pending.remove(id);
      return PythonSandboxResult.failure('Không gửi được code vào sandbox: $e');
    }

    PythonSandboxResult result;
    try {
      result = await completer.future.timeout(runTimeout);
    } on TimeoutException {
      _pending.remove(id);
      await _teardown(); // nghi ngờ treo (vd vòng lặp vô hạn) -> bỏ WebView này
      return PythonSandboxResult.failure(
          'Hết thời gian chạy (quá ${runTimeout.inSeconds}s) — có thể code bị lặp vô hạn hoặc quá nặng.');
    }

    final totalChars = result.files.values.fold<int>(0, (sum, v) => sum + v.length);
    if (totalChars > maxOutputBytes) {
      return PythonSandboxResult.failure(
          'Kết quả trả về quá lớn (>${maxOutputBytes ~/ (1024 * 1024)}MB) — thu nhỏ dữ liệu/độ phân giải ảnh trong code.');
    }
    return result;
  }

  Future<void> _ensureReady(BuildContext context) async {
    if (_controller != null && _pageLoaded) return;
    if (_loadCompleter != null) {
      return _loadCompleter!.future.timeout(loadTimeout);
    }
    _loadCompleter = Completer<void>();

    final controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('PySandboxChannel', onMessageReceived: _onMessage)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) {
          _pageLoaded = true;
          if (!_loadCompleter!.isCompleted) _loadCompleter!.complete();
        },
        onWebResourceError: (error) {
          if (!_loadCompleter!.isCompleted) {
            _loadCompleter!.completeError('Lỗi tải sandbox: ${error.description}');
          }
        },
      ))
      ..loadFlutterAsset('assets/sandbox/sandbox.html');
    _controller = controller;

    // Mount off-screen (không hiển thị cho người dùng) — bắt buộc phải nằm
    // trong widget tree để WebView thực sự khởi tạo & chạy JS, giống cách
    // ChartRenderer dùng OverlayEntry để capture RepaintBoundary.
    final overlay = Overlay.of(context, rootOverlay: true);
    _overlayEntry = OverlayEntry(
      builder: (_) => Positioned(
        left: -400,
        top: -800,
        width: 300,
        height: 300,
        child: IgnorePointer(child: WebViewWidget(controller: controller)),
      ),
    );
    overlay.insert(_overlayEntry!);

    await _loadCompleter!.future.timeout(loadTimeout);
    await _autoInstallStoredWheels();
  }

  bool _wheelsAutoInstalled = false;

  /// Sau khi sandbox mới khởi tạo xong, tự cài lại các file `.whl` người
  /// dùng đã upload từ trước (lưu vĩnh viễn qua [PythonWheelManager]) — vì
  /// mỗi lần app mở lại, WebView là 1 phiên hoàn toàn mới, không tự nhớ gì.
  /// Lỗi cài 1 wheel nào đó KHÔNG làm hỏng cả sandbox — chỉ ghi nhận để
  /// người dùng biết qua [lastWheelInstallErrors] nếu cần xem lại.
  final Map<String, String> lastWheelInstallErrors = {};

  Future<void> _autoInstallStoredWheels() async {
    if (_wheelsAutoInstalled) return;
    _wheelsAutoInstalled = true;
    lastWheelInstallErrors.clear();
    final names = await PythonWheelManager.instance.list();
    for (final name in names) {
      final bytes = await PythonWheelManager.instance.readBytes(name);
      final result = await _installWheelBytes(name, bytes);
      if (!result.ok) lastWheelInstallErrors[name] = result.error ?? 'Lỗi không rõ.';
    }
  }

  /// Cài 1 file `.whl` (đã có sẵn trên máy, xem [PythonWheelManager]) vào
  /// sandbox bằng `micropip.install("emfs:...")` — KHÔNG qua mạng. Gọi khi
  /// người dùng vừa upload 1 wheel mới (để cài ngay, không cần đợi lần mở
  /// app sau) — [PythonWheelManager.add] nên được gọi TRƯỚC để lưu vĩnh
  /// viễn, hàm này chỉ lo phần cài vào phiên sandbox đang chạy.
  Future<PythonSandboxResult> installWheel(BuildContext context, String fileName, List<int> bytes) async {
    return _withWakelock(() => _installWheelInternal(context, fileName, bytes));
  }

  Future<PythonSandboxResult> _installWheelInternal(BuildContext context, String fileName, List<int> bytes) async {
    try {
      await _ensureReady(context);
    } catch (e) {
      return PythonSandboxResult.failure('Không khởi động được sandbox: $e');
    }
    return _installWheelBytes(fileName, bytes);
  }

  Future<PythonSandboxResult> _installWheelBytes(String fileName, List<int> bytes) async {
    if (_controller == null) return PythonSandboxResult.failure('Sandbox chưa sẵn sàng.');
    final id = 'w${_reqCounter++}';
    final completer = Completer<PythonSandboxResult>();
    _pending[id] = completer;
    final b64 = base64Encode(bytes);
    try {
      await _controller!.runJavaScript('window.__installWheel(${jsonEncode(id)}, ${jsonEncode(fileName)}, ${jsonEncode(b64)});');
    } catch (e) {
      _pending.remove(id);
      return PythonSandboxResult.failure('Không gửi được wheel vào sandbox: $e');
    }
    try {
      return await completer.future.timeout(const Duration(seconds: 30));
    } on TimeoutException {
      _pending.remove(id);
      return PythonSandboxResult.failure('Hết thời gian cài "$fileName".');
    }
  }

  void _onMessage(JavaScriptMessage message) {
    try {
      final data = jsonDecode(message.message) as Map<String, dynamic>;
      final id = data['id'] as String?;
      final completer = id != null ? _pending.remove(id) : null;
      if (completer == null || completer.isCompleted) return;
      final files = <String, String>{};
      (data['files'] as Map?)?.forEach((k, v) => files[k.toString()] = v.toString());
      completer.complete(PythonSandboxResult(
        ok: data['ok'] == true,
        stdout: (data['stdout'] ?? '').toString(),
        stderr: (data['stderr'] ?? '').toString(),
        error: data['error']?.toString(),
        files: files,
      ));
    } catch (_) {
      // Message không đúng định dạng JSON mong đợi -> bỏ qua, không để
      // crash kênh JS-Dart (request tương ứng sẽ tự timeout ở phía Dart).
    }
  }

  Future<void> _teardown() async {
    _overlayEntry?.remove();
    _overlayEntry = null;
    _controller = null;
    _pageLoaded = false;
    _loadCompleter = null;
    _wheelsAutoInstalled = false;
    for (final c in _pending.values) {
      if (!c.isCompleted) c.complete(PythonSandboxResult.failure('Sandbox đã bị huỷ.'));
    }
    _pending.clear();
  }

  /// Gọi khi muốn giải phóng RAM chủ động (không bắt buộc — WebView ẩn
  /// không hại nếu để đó, nhưng có thể gọi lúc rời màn hình xuất file).
  void dispose() => _teardown();
}
