import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import '../models/provider_config.dart';

/// Gọi API sinh ảnh AI (kiểu OpenAI-compatible `/images/generations` —
/// DALL-E, và nhiều dịch vụ tương thích khác dùng chung cú pháp này).
///
/// CHỈ nên gọi khi KHÔNG tìm được ảnh phù hợp qua URL có sẵn (xem
/// [DslDocumentBuilder]) — mỗi lần gọi tốn tiền/token thật của provider đã
/// cấu hình, khác hẳn tải ảnh qua URL (miễn phí). Đây là lý do thiết kế
/// fallback: thử URL trước, hết cách mới gọi tới đây.
class ImageGenService {
  static Future<Uint8List?> generate(ProviderConfig config, String prompt) async {
    try {
      final base = config.baseUrl.endsWith('/')
          ? config.baseUrl.substring(0, config.baseUrl.length - 1)
          : config.baseUrl;
      final uri = Uri.parse('$base/images/generations');

      final resp = await http.post(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${config.apiKey}',
        },
        body: jsonEncode({
          'model': config.model,
          'prompt': prompt,
          'n': 1,
          'size': '1024x1024',
          'response_format': 'b64_json',
        }),
      );

      if (resp.statusCode < 200 || resp.statusCode >= 300) {
        return null;
      }

      final json = jsonDecode(utf8.decode(resp.bodyBytes)) as Map<String, dynamic>;
      final data = json['data'] as List?;
      if (data == null || data.isEmpty) return null;
      final first = data.first as Map<String, dynamic>;

      // Một số dịch vụ trả về b64_json trực tiếp, một số trả về url ảnh đã
      // sinh (thay vì bytes) — xử lý cả 2 trường hợp.
      if (first['b64_json'] != null) {
        return base64Decode(first['b64_json'] as String);
      }
      if (first['url'] != null) {
        final imgResp = await http.get(Uri.parse(first['url'] as String));
        if (imgResp.statusCode >= 200 && imgResp.statusCode < 300) {
          return imgResp.bodyBytes;
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }
}
