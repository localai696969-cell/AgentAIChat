import 'dart:convert';
import 'package:archive/archive.dart';
import 'package:http/http.dart' as http;
import '../models/provider_config.dart';
import 'api_service.dart';

/// Tự động hoá vòng lặp "build → lỗi → tự sửa → build lại" bằng GitHub API,
/// KHÔNG cần biên dịch trên điện thoại (điều đó không khả thi). Toàn bộ việc
/// build thật diễn ra trên máy chủ GitHub Actions (miễn phí cho repo public,
/// có giới hạn phút chạy cho repo private) — app chỉ điều phối qua HTTP.
///
/// Yêu cầu người dùng cung cấp:
///  - GitHub Personal Access Token (PAT) có quyền "repo" + "workflow".
///  - owner/repo đích (repo cần đã tồn tại và có sẵn workflow build, ví dụ
///    file .github/workflows/build_apk.yml đã có trong project).
///  - Provider AI: TUỲ CHỌN — chỉ cần nếu muốn tự sửa khi build lỗi. Nếu
///    code đã build thành công ngay từ đầu (ví dụ do bên khác xuất sẵn),
///    KHÔNG tốn 1 lệnh gọi AI nào.
///
/// Quy trình applyAndBuildUntilSuccess():
///  1. Đẩy (tạo/update) toàn bộ file code lên nhánh chỉ định qua Contents API.
///  2. Kích hoạt workflow bằng "workflow_dispatch".
///  3. Poll trạng thái run cho tới khi hoàn thành.
///  4. Nếu SUCCESS: lấy artifactId (file APK) trả về cho UI — DỪNG Ở ĐÂY,
///     không đụng tới AI.
///  5. Nếu FAIL và CÓ cấu hình AI: tải log lỗi, gửi kèm code hiện tại cho
///     model AI để nó tự sinh bản vá (diff dạng "file: nội dung mới"), áp
///     dụng bản vá, quay lại bước 1. Lặp tối đa [maxAttempts] lần.
///  6. Nếu FAIL và KHÔNG có AI: dừng ngay ở lần lỗi đầu tiên, trả log cho
///     người dùng tự đọc.
class GithubBuildService {
  final String token;
  final String owner;
  final String repo;
  final String branch;
  final http.Client _client = http.Client();

  GithubBuildService({
    required this.token,
    required this.owner,
    required this.repo,
    this.branch = 'main',
  });

  Map<String, String> get _headers => {
        'Authorization': 'Bearer $token',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
      };

  /// Đẩy nhiều file cùng lúc (tạo mới hoặc update nếu đã tồn tại — tự lấy sha
  /// hiện có để tránh lỗi conflict).
  Future<void> pushFiles(Map<String, String> pathToContent, {String message = 'chore: auto update by AI'}) async {
    for (final entry in pathToContent.entries) {
      await _putFile(entry.key, entry.value, message);
    }
  }

  Future<void> _putFile(String path, String content, String message) async {
    final uri = Uri.https('api.github.com', '/repos/$owner/$repo/contents/$path');

    String? sha;
    final getResp = await _client.get(uri.replace(queryParameters: {'ref': branch}), headers: _headers);
    if (getResp.statusCode == 200) {
      sha = jsonDecode(getResp.body)['sha'] as String?;
    }

    final resp = await _client.put(
      uri,
      headers: _headers,
      body: jsonEncode({
        'message': message,
        'content': base64Encode(utf8.encode(content)),
        'branch': branch,
        if (sha != null) 'sha': sha,
      }),
    );

    if (resp.statusCode != 200 && resp.statusCode != 201) {
      throw Exception('Đẩy file $path thất bại (${resp.statusCode}): ${resp.body}');
    }
  }

  /// Kích hoạt workflow build. [workflowFile] là tên file trong
  /// .github/workflows/, ví dụ "build_apk.yml".
  Future<void> triggerWorkflow(String workflowFile) async {
    final uri = Uri.https(
      'api.github.com',
      '/repos/$owner/$repo/actions/workflows/$workflowFile/dispatches',
    );
    final resp = await _client.post(
      uri,
      headers: _headers,
      body: jsonEncode({'ref': branch}),
    );
    if (resp.statusCode != 204) {
      throw Exception('Không kích hoạt được workflow (${resp.statusCode}): ${resp.body}');
    }
  }

  /// Chờ và trả về run mới nhất của workflow (poll mỗi [interval]).
  Future<Map<String, dynamic>> waitForRunCompletion(
    String workflowFile, {
    Duration interval = const Duration(seconds: 10),
    Duration timeout = const Duration(minutes: 15),
  }) async {
    final started = DateTime.now();
    // Đợi vài giây để GitHub kịp tạo run mới sau khi dispatch.
    await Future.delayed(const Duration(seconds: 5));

    while (DateTime.now().difference(started) < timeout) {
      final uri = Uri.https(
        'api.github.com',
        '/repos/$owner/$repo/actions/workflows/$workflowFile/runs',
        {'branch': branch, 'per_page': '1'},
      );
      final resp = await _client.get(uri, headers: _headers);
      if (resp.statusCode == 200) {
        final runs = jsonDecode(resp.body)['workflow_runs'] as List;
        if (runs.isNotEmpty) {
          final run = runs.first as Map<String, dynamic>;
          if (run['status'] == 'completed') return run;
        }
      }
      await Future.delayed(interval);
    }
    throw Exception('Hết thời gian chờ build (timeout).');
  }

  /// Lấy nội dung log (dạng text) của 1 run bị lỗi, để đưa cho AI đọc và sửa.
  Future<String> fetchRunLog(int runId) async {
    final uri = Uri.https('api.github.com', '/repos/$owner/$repo/actions/runs/$runId/logs');
    final resp = await _client.get(uri, headers: _headers);
    if (resp.statusCode != 200) {
      throw Exception('Không tải được log (${resp.statusCode}).');
    }
    // GitHub LUÔN trả về log dưới dạng 1 file .zip chứa nhiều *.txt (mỗi
    // step/job 1 file) — PHẢI giải nén bằng `archive` rồi gộp lại, giải mã
    // thẳng bytes .zip thành text sẽ ra toàn ký tự vô nghĩa (không đọc
    // được), khiến bước tự sửa lỗi ở dưới không có gì để sửa.
    try {
      final archive = ZipDecoder().decodeBytes(resp.bodyBytes);
      final buffer = StringBuffer();
      final txtEntries = archive.where((e) => e.isFile && e.name.toLowerCase().endsWith('.txt')).toList()
        ..sort((a, b) => a.name.compareTo(b.name));
      for (final entry in txtEntries) {
        buffer.writeln('--- ${entry.name} ---');
        buffer.writeln(utf8.decode(entry.content as List<int>, allowMalformed: true));
      }
      return buffer.toString();
    } catch (e) {
      // Nếu vì lý do gì đó không phải .zip hợp lệ, vẫn cố trả về best-effort
      // thay vì ném lỗi làm dừng cả vòng lặp tự sửa.
      return utf8.decode(resp.bodyBytes, allowMalformed: true);
    }
  }

  /// Lấy danh sách artifact (file APK) của 1 run thành công.
  Future<List<Map<String, dynamic>>> fetchArtifacts(int runId) async {
    final uri = Uri.https('api.github.com', '/repos/$owner/$repo/actions/runs/$runId/artifacts');
    final resp = await _client.get(uri, headers: _headers);
    if (resp.statusCode != 200) return [];
    return List<Map<String, dynamic>>.from(jsonDecode(resp.body)['artifacts']);
  }

  /// Tải file .zip chứa artifact (APK) về dạng bytes.
  Future<List<int>> downloadArtifact(int artifactId) async {
    final uri = Uri.https('api.github.com', '/repos/$owner/$repo/actions/artifacts/$artifactId/zip');
    final resp = await _client.get(uri, headers: _headers);
    if (resp.statusCode != 200) {
      throw Exception('Tải artifact thất bại (${resp.statusCode}).');
    }
    return resp.bodyBytes;
  }

  /// GitHub Actions LUÔN đóng gói artifact thành 1 lớp .zip bọc ngoài (kể cả
  /// khi bên trong chỉ có đúng 1 file .apk) — hàm này mở lớp .zip đó ra, tìm
  /// đúng file .apk (ưu tiên nếu chỉ có 1 file .apk; nếu nhiều, lấy file lớn
  /// nhất vì file .apk thật thường lớn hơn hẳn file mapping/log đi kèm nếu
  /// có) và trả về bytes gốc của .apk. Trả về null nếu không tìm thấy .apk
  /// nào trong artifact (ví dụ workflow build ra định dạng khác).
  static List<int>? extractApkFromArtifactZip(List<int> zipBytes) {
    final archive = ZipDecoder().decodeBytes(zipBytes);
    ArchiveFile? best;
    for (final entry in archive) {
      if (!entry.isFile) continue;
      if (!entry.name.toLowerCase().endsWith('.apk')) continue;
      if (best == null || entry.size > best.size) best = entry;
    }
    if (best == null) return null;
    return best.content as List<int>;
  }

  /// VÒNG LẶP CHÍNH: đẩy code → build → chờ kết quả. AI CHỈ được gọi tới khi
  /// build THẤT BẠI (để đọc log và tự sinh bản vá) — nếu code đã build
  /// thành công ngay từ lần đầu (ví dụ code đã hoàn chỉnh, do bên khác xuất
  /// ra), TOÀN BỘ quy trình không tốn 1 lệnh gọi AI nào. Vì vậy [aiApiService]/
  /// [aiProvider] là TUỲ CHỌN (nullable): nếu không truyền vào (hoặc build
  /// thành công trước khi cần tới) thì không sao; nếu build lỗi mà không có
  /// AI để nhờ sửa, dừng lại ngay lần lỗi đầu tiên và trả về log cho người
  /// dùng tự đọc/sửa, thay vì lặp vô ích. Trả về (thành công?, log cuối
  /// cùng, artifactId nếu có).
  Future<AutoBuildResult> applyAndBuildUntilSuccess({
    required Map<String, String> initialFiles,
    required String workflowFile,
    ApiService? aiApiService,
    ProviderConfig? aiProvider,
    int maxAttempts = 3,
    void Function(String status)? onStatus,
  }) async {
    final canAutoFix = aiApiService != null && aiProvider != null;
    var files = Map<String, String>.from(initialFiles);

    for (int attempt = 1; attempt <= maxAttempts; attempt++) {
      onStatus?.call('Lần thử $attempt/$maxAttempts: đang đẩy code lên GitHub...');
      await pushFiles(files, message: 'Auto-build attempt $attempt');

      onStatus?.call('Đang kích hoạt build trên GitHub Actions...');
      await triggerWorkflow(workflowFile);

      onStatus?.call('Đang chờ kết quả build...');
      final run = await waitForRunCompletion(workflowFile);
      final conclusion = run['conclusion'];
      final runId = run['id'] as int;

      if (conclusion == 'success') {
        final artifacts = await fetchArtifacts(runId);
        onStatus?.call('Build thành công!');
        return AutoBuildResult(
          success: true,
          attempts: attempt,
          artifactId: artifacts.isNotEmpty ? artifacts.first['id'] as int : null,
        );
      }

      onStatus?.call('Build lỗi ở lần $attempt, đang đọc log...');
      final log = await fetchRunLog(runId);
      final trimmedLog = log.length > 6000 ? log.substring(log.length - 6000) : log;

      if (!canAutoFix) {
        onStatus?.call('Build lỗi và chưa cấu hình AI để tự sửa — dừng lại.');
        return AutoBuildResult(success: false, attempts: attempt, lastLog: trimmedLog);
      }
      if (attempt == maxAttempts) {
        return AutoBuildResult(success: false, attempts: attempt, lastLog: trimmedLog);
      }
      onStatus?.call('Đang nhờ AI đọc log để tự sửa...');
      final fixPrompt = '''
Build Flutter/Android bị lỗi. Đây là log lỗi (đã cắt bớt):
$trimmedLog

Dưới đây là các file hiện tại (đường dẫn : nội dung):
${files.entries.map((e) => '--- ${e.key} ---\n${e.value}').join('\n\n')}

Hãy sửa lỗi. CHỈ trả về các file cần thay đổi/thêm mới, theo đúng định dạng
mỗi file 1 code block có đường dẫn ngay dòng đầu, ví dụ:
```lib/main.dart
nội dung file đã sửa...
```
Không giải thích gì thêm ngoài các code block.
''';

      final fixResponse = await aiApiService!.sendMessageOnce(
        config: aiProvider!,
        messages: [ApiMessage('user', fixPrompt)],
      );

      final fixedFiles = _extractFiles(fixResponse);
      if (fixedFiles.isEmpty) {
        return AutoBuildResult(success: false, attempts: attempt, lastLog: trimmedLog);
      }
      files.addAll(fixedFiles);
    }

    return AutoBuildResult(success: false, attempts: maxAttempts);
  }

  Map<String, String> _extractFiles(String response) {
    final regex = RegExp(r'```([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+)\n([\s\S]*?)```');
    final files = <String, String>{};
    for (final m in regex.allMatches(response)) {
      files[m.group(1)!.trim()] = m.group(2)!;
    }
    return files;
  }

  void dispose() => _client.close();
}

class AutoBuildResult {
  final bool success;
  final int attempts;
  final int? artifactId;
  final String? lastLog;
  AutoBuildResult({required this.success, required this.attempts, this.artifactId, this.lastLog});
}
