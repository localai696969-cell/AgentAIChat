import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/message.dart';
import '../models/provider_config.dart';

/// Một "khung" tin nhắn tối giản dùng để build request, độc lập với Hive.
class ApiMessage {
  final String role; // "system" | "user" | "assistant"
  final String content;
  ApiMessage(this.role, this.content);
}

/// Số token THẬT được API trả về (không phải ước lượng) — dùng để thống kê
/// chính xác "đã dùng bao nhiêu / được cấp bao nhiêu".
class ApiUsage {
  final int promptTokens;
  final int completionTokens;
  int get totalTokens => promptTokens + completionTokens;
  ApiUsage({required this.promptTokens, required this.completionTokens});
}

/// Service gọi API model bên ngoài. KHÔNG hardcode bất kỳ hãng/model nào —
/// mọi thứ (baseUrl, apiKey, model, format) đến từ [ProviderConfig] do người
/// dùng tự cấu hình trong Settings.
class ApiService {
  final http.Client _client = http.Client();

  /// Gửi request và trả về stream các đoạn text (để hiển thị dạng gõ chữ).
  /// [onUsage] được gọi (nếu API trả về) với số token THẬT của lượt gọi này
  /// — dùng để cập nhật thống kê chính xác thay vì chỉ ước lượng.
  Stream<String> sendMessageStream({
    required ProviderConfig config,
    required List<ApiMessage> messages,
    void Function(ApiUsage usage)? onUsage,
  }) async* {
    final uri = _buildUri(config);
    final headers = _buildHeaders(config);
    final body = _buildBody(config, messages, stream: true);

    final request = http.Request('POST', uri);
    request.headers.addAll(headers);
    request.body = jsonEncode(body);

    http.StreamedResponse response;
    try {
      response = await _client.send(request);
    } catch (e) {
      throw ApiException('Không thể kết nối tới API: $e');
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final errBody = await response.stream.bytesToString();
      throw ApiException('API trả về lỗi ${response.statusCode}: $errBody');
    }

    int? pendingInputTokens; // dùng cho Anthropic: input đến ở message_start, output đến ở message_delta
    final buffer = StringBuffer();
    await for (final chunk in response.stream.transform(utf8.decoder)) {
      buffer.write(chunk);
      // SSE: mỗi sự kiện cách nhau bởi \n\n, mỗi dòng có thể bắt đầu "data: "
      final lines = buffer.toString().split('\n');
      // giữ lại phần dòng cuối chưa hoàn chỉnh trong buffer
      buffer.clear();
      buffer.write(lines.isNotEmpty ? lines.last : '');

      for (int i = 0; i < lines.length - 1; i++) {
        final line = lines[i].trim();
        if (!line.startsWith('data:')) continue;
        final data = line.substring(5).trim();
        if (data.isEmpty) continue;
        if (data == '[DONE]') return;

        try {
          final json = jsonDecode(data);
          final text = _extractDeltaText(config, json);
          if (text != null && text.isNotEmpty) yield text;

          // --- Bóc số token thật từ response (nếu có) ---
          if (config.format == ApiFormat.openaiCompatible || config.format == ApiFormat.custom) {
            final usage = json['usage'];
            if (usage != null) {
              onUsage?.call(ApiUsage(
                promptTokens: (usage['prompt_tokens'] ?? 0) as int,
                completionTokens: (usage['completion_tokens'] ?? 0) as int,
              ));
            }
          } else if (config.format == ApiFormat.anthropicCompatible) {
            if (json['type'] == 'message_start') {
              final u = json['message']?['usage'];
              if (u != null) pendingInputTokens = (u['input_tokens'] ?? 0) as int;
            } else if (json['type'] == 'message_delta') {
              final u = json['usage'];
              if (u != null) {
                onUsage?.call(ApiUsage(
                  promptTokens: pendingInputTokens ?? 0,
                  completionTokens: (u['output_tokens'] ?? 0) as int,
                ));
              }
            }
          }
        } catch (_) {
          // dòng không phải JSON hợp lệ (ví dụ "event: ping") -> bỏ qua
        }
      }
    }
  }

  /// Gọi không streaming — dùng cho các tác vụ nội bộ như tóm tắt ngữ cảnh,
  /// nơi ta chỉ cần kết quả cuối cùng chứ không cần hiệu ứng gõ chữ.
  Future<String> sendMessageOnce({
    required ProviderConfig config,
    required List<ApiMessage> messages,
    void Function(ApiUsage usage)? onUsage,
  }) async {
    final uri = _buildUri(config);
    final headers = _buildHeaders(config);
    final body = _buildBody(config, messages, stream: false);

    final resp = await _client.post(uri, headers: headers, body: jsonEncode(body));
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw ApiException('API trả về lỗi ${resp.statusCode}: ${resp.body}');
    }
    final json = jsonDecode(utf8.decode(resp.bodyBytes));

    final usage = _extractUsage(config, json);
    if (usage != null) onUsage?.call(usage);

    return _extractFullText(config, json);
  }

  ApiUsage? _extractUsage(ProviderConfig config, dynamic json) {
    switch (config.format) {
      case ApiFormat.openaiCompatible:
      case ApiFormat.custom:
        final usage = json['usage'];
        if (usage == null) return null;
        return ApiUsage(
          promptTokens: (usage['prompt_tokens'] ?? 0) as int,
          completionTokens: (usage['completion_tokens'] ?? 0) as int,
        );
      case ApiFormat.anthropicCompatible:
        final usage = json['usage'];
        if (usage == null) return null;
        return ApiUsage(
          promptTokens: (usage['input_tokens'] ?? 0) as int,
          completionTokens: (usage['output_tokens'] ?? 0) as int,
        );
    }
  }

  Uri _buildUri(ProviderConfig config) {
    final base = config.baseUrl.endsWith('/')
        ? config.baseUrl.substring(0, config.baseUrl.length - 1)
        : config.baseUrl;
    switch (config.format) {
      case ApiFormat.openaiCompatible:
        return Uri.parse('$base/chat/completions');
      case ApiFormat.anthropicCompatible:
        return Uri.parse('$base/messages');
      case ApiFormat.custom:
        return Uri.parse(base);
    }
  }

  Map<String, String> _buildHeaders(ProviderConfig config) {
    switch (config.format) {
      case ApiFormat.openaiCompatible:
        return {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${config.apiKey}',
        };
      case ApiFormat.anthropicCompatible:
        return {
          'Content-Type': 'application/json',
          'x-api-key': config.apiKey,
          'anthropic-version': '2023-06-01',
        };
      case ApiFormat.custom:
        return {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${config.apiKey}',
        };
    }
  }

  Map<String, dynamic> _buildBody(
    ProviderConfig config,
    List<ApiMessage> messages, {
    required bool stream,
  }) {
    switch (config.format) {
      case ApiFormat.openaiCompatible:
        return {
          'model': config.model,
          'temperature': config.temperature,
          'stream': stream,
          // Yêu cầu server gửi kèm số token thật ở chunk cuối cùng khi
          // streaming — nhiều provider OpenAI-compatible (bao gồm chính
          // OpenAI, và hầu hết proxy tương thích) hỗ trợ cờ này.
          if (stream) 'stream_options': {'include_usage': true},
          // Bật "Thinking": Gemini nhận thẳng field này qua endpoint
          // OpenAI-compatible (map nội bộ sang thinking_level/thinking_budget);
          // các model OpenAI dòng suy luận (o-series/gpt-5-reasoning) cũng
          // nhận đúng field này.
          if (config.reasoningEffort != null && config.reasoningEffort != 'none')
            'reasoning_effort': config.reasoningEffort,
          // Tìm kiếm web: field chuẩn OpenAI, chỉ có tác dụng thật với các
          // model dòng search (gpt-4o-search-preview, gpt-5-search-api...).
          // Với model thường hoặc qua Gemini, field lạ này bị bỏ qua an
          // toàn theo cơ chế tương thích của họ (không gây lỗi request).
          if (config.webSearchEnabled) 'web_search_options': {},
          'messages': messages
              .map((m) => {'role': m.role, 'content': m.content})
              .toList(),
        };
      case ApiFormat.anthropicCompatible:
        final systemMsgs = messages.where((m) => m.role == 'system');
        final chatMsgs = messages.where((m) => m.role != 'system');
        return {
          'model': config.model,
          'max_tokens': 4096,
          'temperature': config.temperature,
          'stream': stream,
          if (systemMsgs.isNotEmpty) 'system': systemMsgs.map((m) => m.content).join('\n\n'),
          // Anthropic không dùng chuỗi low/medium/high mà dùng số token
          // ("thinking budget") — quy đổi tương ứng từ mức đã chọn.
          if (config.reasoningEffort != null && config.reasoningEffort != 'none')
            'thinking': {
              'type': 'enabled',
              'budget_tokens': _thinkingBudgetFor(config.reasoningEffort!),
            },
          // Tool tìm kiếm web chính thức của Anthropic — server tự chạy,
          // không cần app tự implement search.
          if (config.webSearchEnabled)
            'tools': [
              {'type': 'web_search_20250305', 'name': 'web_search'}
            ],
          'messages': chatMsgs
              .map((m) => {'role': m.role, 'content': m.content})
              .toList(),
        };
      case ApiFormat.custom:
        // Người dùng cung cấp template JSON, với placeholder {{MODEL}} và
        // {{MESSAGES}} sẽ được thay thế.
        final template = config.customRequestTemplate ?? '{}';
        final replaced = template
            .replaceAll('{{MODEL}}', config.model)
            .replaceAll('{{STREAM}}', stream.toString());
        final map = jsonDecode(replaced) as Map<String, dynamic>;
        map['messages'] = messages.map((m) => {'role': m.role, 'content': m.content}).toList();
        if (config.reasoningEffort != null && config.reasoningEffort != 'none') {
          map['reasoning_effort'] = config.reasoningEffort;
        }
        if (config.webSearchEnabled) {
          map['web_search_options'] = {};
        }
        return map;
    }
  }

  int _thinkingBudgetFor(String level) {
    switch (level) {
      case 'low':
        return 2000;
      case 'medium':
        return 8000;
      case 'high':
      default:
        return 16000;
    }
  }

  String? _extractDeltaText(ProviderConfig config, dynamic json) {
    switch (config.format) {
      case ApiFormat.openaiCompatible:
      case ApiFormat.custom:
        final choices = json['choices'];
        if (choices is List && choices.isNotEmpty) {
          final delta = choices[0]['delta'];
          if (delta != null && delta['content'] != null) {
            return delta['content'] as String;
          }
        }
        return null;
      case ApiFormat.anthropicCompatible:
        if (json['type'] == 'content_block_delta') {
          final delta = json['delta'];
          if (delta != null && delta['text'] != null) {
            return delta['text'] as String;
          }
        }
        return null;
    }
  }

  String _extractFullText(ProviderConfig config, dynamic json) {
    switch (config.format) {
      case ApiFormat.openaiCompatible:
      case ApiFormat.custom:
        final choices = json['choices'];
        if (choices is List && choices.isNotEmpty) {
          return choices[0]['message']?['content'] ?? '';
        }
        return '';
      case ApiFormat.anthropicCompatible:
        final content = json['content'];
        if (content is List && content.isNotEmpty) {
          return content.map((c) => c['text'] ?? '').join();
        }
        return '';
    }
  }

  void dispose() => _client.close();
}

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}
