import 'package:flutter/services.dart';

/// Bật/tắt 1 foreground service Android THẬT (`KeepAliveService.kt`, được
/// GitHub Actions tự tạo lúc build — xem `.github/workflows/build_apk.yml`
/// và HANDOFF.md mục 42) — KHÁC HẲN `wakelock_plus`:
///
/// - `wakelock_plus` (xem [PythonSandboxService]) chỉ ngăn máy tự khoá màn
///   hình do HẾT GIỜ CHỜ — không có tác dụng nếu người dùng CHỦ ĐỘNG bấm
///   nút khoá máy hoặc chuyển hẳn sang app khác.
/// - [KeepAliveService] (service này) là "giấy phép" hệ điều hành cấp cho
///   foreground service — khiến Android KHÔNG tạm dừng/thu hồi tiến trình
///   app dù màn hình đã khoá hoặc đang ở app khác, miễn là service này còn
///   chạy (hiện 1 thông báo cố định báo cho người dùng biết). Tác vụ THẬT
///   (gọi AI/chạy Python) vẫn chạy trong tiến trình Dart/Flutter chính như
///   bình thường — service này không tự làm gì khác ngoài "giữ chỗ".
///
/// CHỈ có tác dụng trên Android (kênh MethodChannel chỉ được đăng ký ở
/// `MainActivity.kt` cho Android) — gọi trên nền tảng khác sẽ lỗi
/// `MissingPluginException`, bị nuốt lặng lẽ (try/catch), coi như tính
/// năng phụ không có thì thôi, không được chặn tác vụ chính.
class KeepAliveService {
  KeepAliveService._();
  static final KeepAliveService instance = KeepAliveService._();

  static const _channel = MethodChannel('agent_ai_chat/keepalive');
  int _refCount = 0;

  /// Bọc [body] bằng bật/tắt service — dùng đếm tham chiếu vì có thể có
  /// nhiều tác vụ "đáng giữ nền" chạy gối nhau (ví dụ đang gọi AI thì
  /// người dùng bấm chạy thử Python trong chat) — chỉ TẮT service khi
  /// KHÔNG còn tác vụ nào đang cần nó.
  Future<T> run<T>(Future<T> Function() body) async {
    await _acquire();
    try {
      return await body();
    } finally {
      await _release();
    }
  }

  Future<void> _acquire() async {
    _refCount++;
    if (_refCount == 1) {
      try {
        await _channel.invokeMethod('start');
      } catch (_) {
        // Bỏ qua — xem doc ở đầu file. Không phải Android, hoặc lỗi vặt.
      }
    }
  }

  Future<void> _release() async {
    _refCount = _refCount > 0 ? _refCount - 1 : 0;
    if (_refCount == 0) {
      try {
        await _channel.invokeMethod('stop');
      } catch (_) {}
    }
  }
}
