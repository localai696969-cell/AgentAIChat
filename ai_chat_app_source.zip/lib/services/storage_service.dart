import 'package:hive_flutter/hive_flutter.dart';
import '../models/conversation.dart';
import '../models/message.dart';
import '../models/provider_config.dart';
import '../models/generated_file.dart';
import '../models/source_document.dart';

/// Lớp truy cập dữ liệu local. Toàn bộ dữ liệu (hội thoại, cấu hình API key)
/// được lưu HOÀN TOÀN trên máy người dùng qua Hive — không có backend nào
/// của app, vì app chỉ là client gọi thẳng tới API do người dùng tự cấu hình.
class StorageService {
  static const _convBox = 'conversations';
  static const _folderBox = 'folders';
  static const _providerBox = 'providers';
  static const _settingsBox = 'settings';
  static const _sourceDocBox = 'source_documents';

  late Box<Conversation> conversations;
  late Box<ChatFolder> folders;
  late Box<ProviderConfig> providers;
  late Box settings;
  late Box<SourceDocument> sourceDocuments;

  Future<void> init() async {
    await Hive.initFlutter();

    Hive.registerAdapter(MessageRoleAdapter());
    Hive.registerAdapter(ChatMessageAdapter());
    Hive.registerAdapter(ApiFormatAdapter());
    Hive.registerAdapter(ProviderConfigAdapter());
    Hive.registerAdapter(ConversationAdapter());
    Hive.registerAdapter(ChatFolderAdapter());
    Hive.registerAdapter(GeneratedFileAdapter());
    Hive.registerAdapter(SourceDocumentAdapter());

    conversations = await Hive.openBox<Conversation>(_convBox);
    folders = await Hive.openBox<ChatFolder>(_folderBox);
    providers = await Hive.openBox<ProviderConfig>(_providerBox);
    settings = await Hive.openBox(_settingsBox);
    sourceDocuments = await Hive.openBox<SourceDocument>(_sourceDocBox);
  }

  List<SourceDocument> get sourceDocumentsSorted {
    final list = sourceDocuments.values.toList();
    list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return list;
  }

  ProviderConfig? get defaultProvider {
    try {
      return providers.values.firstWhere((p) => p.isDefault);
    } catch (_) {
      return providers.values.isNotEmpty ? providers.values.first : null;
    }
  }

  ProviderConfig? providerFor(Conversation c) {
    if (c.providerConfigId == null) return defaultProvider;
    try {
      return providers.values.firstWhere((p) => p.id == c.providerConfigId);
    } catch (_) {
      return defaultProvider;
    }
  }

  ProviderConfig? providerById(String? id) {
    if (id == null) return null;
    try {
      return providers.values.firstWhere((p) => p.id == id);
    } catch (_) {
      return null;
    }
  }

  /// Provider RIÊNG cho các tác vụ "Thư ký AI" (tổng hợp tài liệu nguồn,
  /// sửa source code zip) — ĐỘC LẬP với provider của đoạn chat đang mở, để
  /// người dùng có thể dùng 1 model rẻ/nhanh riêng cho việc trích xuất/tổng
  /// hợp, khác với model đang dùng để trò chuyện chính. Nếu chưa chọn, các
  /// nơi gọi tới sẽ tự rơi về provider của đoạn chat đang mở (hành vi cũ).
  String? get secretaryProviderId => settings.get('secretary_provider_id') as String?;

  set secretaryProviderId(String? id) {
    if (id == null) {
      settings.delete('secretary_provider_id');
    } else {
      settings.put('secretary_provider_id', id);
    }
  }

  ProviderConfig? get secretaryProvider => providerById(secretaryProviderId);

  /// Provider RIÊNG cho việc SINH ẢNH bằng AI (DALL-E/Stability/Imagen...
  /// qua endpoint kiểu OpenAI-compatible `/images/generations`) — CHỈ dùng
  /// làm phương án cuối khi ảnh không tìm được qua URL có sẵn (xem
  /// `DslDocumentBuilder`/`ImageGenService`), để tiết kiệm token/chi phí.
  String? get imageGenProviderId => settings.get('image_gen_provider_id') as String?;

  set imageGenProviderId(String? id) {
    if (id == null) {
      settings.delete('image_gen_provider_id');
    } else {
      settings.put('image_gen_provider_id', id);
    }
  }

  ProviderConfig? get imageGenProvider => providerById(imageGenProviderId);

  /// Cấu hình cho [GithubBuildService] (Tier "tự động build APK qua GitHub
  /// Actions" — xem HANDOFF.md mục 6/8/34.7). Lưu dạng key-value thô trong
  /// box "settings", CÙNG MỨC BẢO MẬT với `ProviderConfig.apiKey` hiện tại
  /// (Hive không mã hoá riêng — nhất quán với cách app đã lưu API key AI từ
  /// trước, không phải hạn chế riêng của tính năng này).
  String? get githubToken => settings.get('github_token') as String?;
  set githubToken(String? v) => v == null || v.isEmpty ? settings.delete('github_token') : settings.put('github_token', v);

  String? get githubOwner => settings.get('github_owner') as String?;
  set githubOwner(String? v) => v == null || v.isEmpty ? settings.delete('github_owner') : settings.put('github_owner', v);

  String? get githubRepo => settings.get('github_repo') as String?;
  set githubRepo(String? v) => v == null || v.isEmpty ? settings.delete('github_repo') : settings.put('github_repo', v);

  String get githubBranch => (settings.get('github_branch') as String?) ?? 'main';
  set githubBranch(String v) => settings.put('github_branch', v.isEmpty ? 'main' : v);

  String get githubWorkflowFile => (settings.get('github_workflow_file') as String?) ?? 'build_apk.yml';
  set githubWorkflowFile(String v) => settings.put('github_workflow_file', v.isEmpty ? 'build_apk.yml' : v);

  bool get githubConfigured =>
      (githubToken?.isNotEmpty ?? false) && (githubOwner?.isNotEmpty ?? false) && (githubRepo?.isNotEmpty ?? false);

  List<Conversation> conversationsInFolder(String? folderId) {
    final list = conversations.values.where((c) => c.folderId == folderId).toList();
    list.sort((a, b) {
      if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
      return b.updatedAt.compareTo(a.updatedAt);
    });
    return list;
  }
}
