import 'dart:convert';
import 'package:archive/archive.dart';

/// Trích xuất nhiều file code từ nội dung trả lời của model rồi đóng gói
/// thành .zip để người dùng tải về và push lên GitHub build.
///
/// Quy ước nhận diện file trong câu trả lời của AI (khuyến nghị đặt trong
/// system prompt của app khi người dùng yêu cầu "tạo dự án/source code"):
///
///   ```path/to/file.ext
///   nội dung file...
///   ```
///
/// hoặc dùng comment ngay dòng đầu code block:
///
///   ```
///   // file: lib/main.dart
///   nội dung file...
///   ```
class CodeZipExporter {
  /// Prompt "mồi" — dán cho 1 AI khác hoặc nhờ 1 người khác đọc TRƯỚC KHI họ
  /// xuất nội dung, để kết quả trả về đúng cú pháp mà [extractFiles] (thuần
  /// code, KHÔNG gọi AI) parse được ngay thành file — tránh phải tốn thêm
  /// 1 lần gọi API của chính app chỉ để "dịch lại" định dạng.
  static const formatInstructionPrompt =
      'Khi trả lời, với MỖI file hãy dùng đúng cú pháp sau (không thêm giải '
      'thích/lời dẫn nào khác ngoài các khối này):\n\n'
      '```đường/dẫn/tên_file.đuôi\n'
      'nội dung đầy đủ của file\n'
      '```\n\n'
      'Ví dụ:\n'
      '```lib/main.dart\n'
      'void main() { ... }\n'
      '```\n\n'
      'Đường dẫn file phải nằm NGAY SAU dấu ``` mở đầu (không phải trên dòng '
      'riêng), và mỗi file là 1 khối riêng biệt.';

  static final _fencedWithPath = RegExp(
    r'```([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+)\n([\s\S]*?)```',
  );
  static final _fencedWithFileComment = RegExp(
    r'```[a-zA-Z0-9]*\n(?:#|//|<!--)\s*file:\s*([a-zA-Z0-9_\-./]+)\s*(?:-->)?\n([\s\S]*?)```',
  );

  /// Trả về map { đường_dẫn_file: nội_dung }.
  static Map<String, String> extractFiles(String modelResponse) {
    final files = <String, String>{};

    for (final m in _fencedWithFileComment.allMatches(modelResponse)) {
      files[m.group(1)!.trim()] = m.group(2)!;
    }
    for (final m in _fencedWithPath.allMatches(modelResponse)) {
      final path = m.group(1)!.trim();
      if (!files.containsKey(path)) {
        files[path] = m.group(2)!;
      }
    }
    return files;
  }

  /// Ghép nhiều file thành 1 chuỗi text DUY NHẤT theo ĐÚNG cú pháp
  /// ```đường/dẫn/file.ext ... ``` mà [extractFiles] đọc lại được — dùng để
  /// dán nội dung source code ra bên ngoài (1 AI khác, hoặc 1 người khác)
  /// nhờ họ đọc/sửa, rồi dán ngược kết quả trả về vào lại [extractFiles] để
  /// ghép thành zip mà KHÔNG cần gọi API model của chính app này.
  static String formatForSharing(Map<String, String> files) {
    final buffer = StringBuffer();
    files.forEach((path, content) {
      buffer.writeln('```$path');
      buffer.writeln(content);
      buffer.writeln('```');
      buffer.writeln();
    });
    return buffer.toString();
  }

  static List<int>? exportFromResponse(String modelResponse, {String? readmeExtra}) {
    final files = extractFiles(modelResponse);
    if (files.isEmpty) return null;
    return export(files, readmeExtra: readmeExtra);
  }

  static List<int> export(Map<String, String> files, {String? readmeExtra}) {
    final archive = Archive();
    files.forEach((path, content) {
      final bytes = utf8.encode(content);
      archive.addFile(ArchiveFile(path, bytes.length, bytes));
    });

    if (readmeExtra != null) {
      final bytes = utf8.encode(readmeExtra);
      archive.addFile(ArchiveFile('README.md', bytes.length, bytes));
    }

    return ZipEncoder().encode(archive)!;
  }
}
