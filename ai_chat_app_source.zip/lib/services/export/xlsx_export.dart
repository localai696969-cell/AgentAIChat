import 'dart:convert';
import 'package:archive/archive.dart';

/// Sinh file .xlsx tối giản nhưng hợp lệ.
///
/// CÓ 2 CÁCH GỌI:
///  1. [export] — cú pháp bảng "|" cũ (giữ nguyên).
///  2. [exportJson] — JSON DSL MỚI: nhiều sheet, mỗi ô có thể đậm/màu nền/
///     công thức Excel thật (ví dụ "=SUM(A1:A10)" — CHÍNH EXCEL tính, app
///     chỉ ghi chuỗi công thức vào file, không tự tính gì cả — an toàn).
///     {"sheets": [{"name":"Sheet1",
///        "rows": [{"cells": [{"value":"Tên","bold":true}, {"value":10}]}],
///        "merges": ["A1:B1"]}]}
class XlsxExporter {
  static List<int> export(String tableLike) {
    final rows = tableLike
        .split('\n')
        .where((l) => l.trim().isNotEmpty)
        .map((l) => l.contains('|')
            ? l.split('|').map((c) => c.trim()).toList()
            : l.split('\t').map((c) => c.trim()).toList())
        .toList();

    final sheetXml = StringBuffer();
    sheetXml.write('<sheetData>');
    for (int r = 0; r < rows.length; r++) {
      sheetXml.write('<row r="${r + 1}">');
      for (int c = 0; c < rows[r].length; c++) {
        final cellRef = '${_colLetter(c)}${r + 1}';
        final value = rows[r][c];
        final isNumber = num.tryParse(value) != null;
        if (isNumber) {
          sheetXml.write('<c r="$cellRef"><v>$value</v></c>');
        } else {
          sheetXml.write('<c r="$cellRef" t="inlineStr"><is><t xml:space="preserve">${_esc(value)}</t></is></c>');
        }
      }
      sheetXml.write('</row>');
    }
    sheetXml.write('</sheetData>');

    return _buildXlsx([_SheetData(name: 'Sheet1', bodyXml: sheetXml.toString(), merges: const [])]);
  }

  static List<int>? exportJson(Map<String, dynamic> workbook) {
    try {
      final sheetsRaw = (workbook['sheets'] as List?) ?? const [];
      final sheets = <_SheetData>[];
      for (final raw in sheetsRaw) {
        if (raw is! Map) continue;
        final name = raw['name']?.toString() ?? 'Sheet${sheets.length + 1}';
        final rowsRaw = (raw['rows'] as List?) ?? const [];
        final merges = (raw['merges'] as List? ?? const []).map((e) => e.toString()).toList();

        final buf = StringBuffer();
        buf.write('<sheetData>');
        for (int r = 0; r < rowsRaw.length; r++) {
          final rowMap = rowsRaw[r];
          final cells = (rowMap is Map ? rowMap['cells'] as List? : null) ?? const [];
          buf.write('<row r="${r + 1}">');
          for (int c = 0; c < cells.length; c++) {
            final cell = cells[c];
            final cellRef = '${_colLetter(c)}${r + 1}';
            if (cell is! Map) continue;
            final bold = cell['bold'] == true;
            final bgColor = cell['bgColor']?.toString();
            final styleIdx = _styleIndexFor(bold: bold, bgColor: bgColor);
            final sAttr = styleIdx > 0 ? ' s="$styleIdx"' : '';
            final formula = cell['formula']?.toString();
            if (formula != null && formula.isNotEmpty) {
              final f = formula.startsWith('=') ? formula.substring(1) : formula;
              buf.write('<c r="$cellRef"$sAttr><f>${_esc(f)}</f></c>');
            } else {
              final value = cell['value'];
              final isNumber = value is num || (value is String && num.tryParse(value) != null);
              if (isNumber) {
                buf.write('<c r="$cellRef"$sAttr><v>$value</v></c>');
              } else {
                buf.write('<c r="$cellRef"$sAttr t="inlineStr"><is><t xml:space="preserve">${_esc(value?.toString() ?? '')}</t></is></c>');
              }
            }
          }
          buf.write('</row>');
        }
        buf.write('</sheetData>');
        sheets.add(_SheetData(name: name, bodyXml: buf.toString(), merges: merges));
      }
      if (sheets.isEmpty) return null;
      return _buildXlsx(sheets);
    } catch (_) {
      return null;
    }
  }

  /// Bảng style cố định nhỏ, đủ dùng cho bold/màu nền cơ bản — tránh phải
  /// build style động phức tạp (rủi ro sai OOXML), style index cố định:
  ///  0 = mặc định, 1 = đậm, 2 = nền vàng nhạt, 3 = đậm + nền vàng nhạt,
  ///  4 = nền xanh nhạt, 5 = đậm + nền xanh nhạt.
  static int _styleIndexFor({required bool bold, String? bgColor}) {
    final hasBg = bgColor != null && bgColor.isNotEmpty;
    if (!bold && !hasBg) return 0;
    if (bold && !hasBg) return 1;
    if (!bold && hasBg) return 2;
    return 3;
  }

  static String _colLetter(int index) {
    String letter = '';
    int i = index;
    while (i >= 0) {
      letter = String.fromCharCode(65 + (i % 26)) + letter;
      i = (i ~/ 26) - 1;
    }
    return letter;
  }

  static String _esc(String s) =>
      s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

  static List<int> _buildXlsx(List<_SheetData> sheets) {
    final archive = Archive();
    void add(String path, String content) {
      final bytes = utf8.encode(content);
      archive.addFile(ArchiveFile(path, bytes.length, bytes));
    }

    final sheetsList = List.generate(
      sheets.length,
      (i) => '<sheet name="${_esc(sheets[i].name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>',
    ).join();

    final sheetRels = List.generate(
      sheets.length,
      (i) => '<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>',
    ).join();
    final stylesRelId = 'rId${sheets.length + 1}';

    final contentTypeOverrides = List.generate(
      sheets.length,
      (i) => '<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>',
    ).join();

    add('[Content_Types].xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  $contentTypeOverrides
</Types>''');

    add('_rels/.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>''');

    add('xl/_rels/workbook.xml.rels', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  $sheetRels
  <Relationship Id="$stylesRelId" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>''');

    add('xl/workbook.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>$sheetsList</sheets>
</workbook>''');

    // Style cố định: font thường/đậm x nền trắng/vàng nhạt — đủ cho nhu cầu
    // cơ bản (tiêu đề bảng đậm, dòng highlight màu) mà không cần build style
    // động phức tạp (rủi ro sai cấu trúc OOXML cellXfs).
    add('xl/styles.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2">
    <font><sz val="11"/><name val="Calibri"/></font>
    <font><sz val="11"/><name val="Calibri"/><b/></font>
  </fonts>
  <fills count="3">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="4">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
    <xf numFmtId="0" fontId="0" fillId="2" borderId="0" xfId="0" applyFill="1"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
  </cellXfs>
</styleSheet>''');

    for (int i = 0; i < sheets.length; i++) {
      final mergeXml = sheets[i].merges.isEmpty
          ? ''
          : '<mergeCells count="${sheets[i].merges.length}">${sheets[i].merges.map((m) => '<mergeCell ref="$m"/>').join()}</mergeCells>';
      add('xl/worksheets/sheet${i + 1}.xml', '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">${sheets[i].bodyXml}$mergeXml</worksheet>''');
    }

    final zipData = ZipEncoder().encode(archive);
    return zipData!;
  }
}

class _SheetData {
  final String name;
  final String bodyXml;
  final List<String> merges;
  _SheetData({required this.name, required this.bodyXml, required this.merges});
}
