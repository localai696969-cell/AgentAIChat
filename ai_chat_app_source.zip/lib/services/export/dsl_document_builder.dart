import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../models/provider_config.dart';
import '../image_gen_service.dart';
import '../image_pool_service.dart';
import '../python_builtin_modules.dart';
import '../python_sandbox_service.dart';
import 'chart_renderer.dart';
import 'docx_export.dart';
import 'pptx_export.dart';
import 'xlsx_export.dart';

/// Tiền xử lý JSON DSL trước khi đưa cho exporter: với mỗi block
/// {"type":"chart"/"diagram"} → vẽ bằng [ChartRenderer] thành PNG; với
/// block {"type":"python", ...} → chạy trong [PythonSandboxService] (Tier 2
/// — xem HANDOFF.md mục "Sandbox Python"), CHỈ khi JSON tĩnh (Tier 1) không
/// đủ biểu đạt (vd cần tính toán/xử lý dữ liệu phức tạp trước khi vẽ/lập
/// bảng); với block {"type":"image", ...} → lấy ảnh theo ĐÚNG THỨ TỰ ƯU
/// TIÊN (để tiết kiệm token/chi phí):
///   1. "ref" trỏ tới ảnh có sẵn trong [ImagePoolService] (đã trích xuất
///      từ trình duyệt trước đó) → đọc thẳng từ bộ nhớ (miễn phí, tức thời,
///      KHÔNG mạng).
///   2. "base64" có sẵn → giải mã trực tiếp (miễn phí, tức thời).
///   3. "url" có sẵn → TẢI ảnh qua HTTP GET bình thường (miễn phí, chỉ tải
///      bytes ảnh, không thực thi gì).
///   4. CHỈ KHI 3 CÁCH TRÊN không có/thất bại VÀ có "prompt" mô tả ảnh cần
///      tạo VÀ đã cấu hình [ProviderConfig] sinh ảnh → gọi [ImageGenService]
///      (tốn tiền/token thật của provider đó) làm phương án CUỐI CÙNG.
///
/// Đây là lớp DUY NHẤT cần [BuildContext] (để [ChartRenderer] render off-
/// screen, và để [PythonSandboxService] mount WebView off-screen) —
/// [DocxExporter]/[PptxExporter]/[XlsxExporter] bản thân chúng không cần
/// context, chỉ nhận sẵn bytes ảnh/dữ liệu đã xử lý xong.
class DslDocumentBuilder {
  /// Gom lại MỌI lỗi khối "python" gặp phải trong lần build GẦN NHẤT — trả
  /// lời đúng yêu cầu "xuất log lỗi ra màn hình cho bên kia biết nếu bên kia
  /// đưa code Python bị lỗi". TRƯỚC ĐÂY lỗi chỉ bị nhét vào chính tài liệu
  /// dưới dạng 1 đoạn văn NGHIÊNG mô tả lỗi (`_errorParagraph`/`_errorSheet`)
  /// — người dùng phải MỞ file ra, tự tìm đúng đoạn nghiêng đó, tự chép tay
  /// lại rồi mới dán được cho AI — rất bất tiện, không có cách nào "biết
  /// ngay" tài liệu vừa build có lỗi Python hay không nếu không mở file.
  ///
  /// Giờ MỌI lỗi (Python hỏng, ảnh không giải mã được, bảng sai định dạng
  /// OUTPUT_FILES...) ĐỀU được gom vào đây CÙNG LÚC với việc nhét vào tài
  /// liệu như cũ (không đổi hành vi cũ, chỉ THÊM kênh báo lỗi thứ 2) — nơi
  /// gọi (`export_runner.dart`/`source_documents_screen.dart`) đọc biến này
  /// NGAY SAU khi `await` xong 1 lệnh `buildDocx`/`buildPptx`/`buildXlsx`,
  /// hiện hộp thoại tổng hợp lỗi kèm nút copy sẵn để dán thẳng cho AI sửa.
  ///
  /// CỐ Ý dùng biến `static` đơn giản (không phải trả về kèm trong kết quả
  /// hàm build) để KHÔNG phải đổi chữ ký `Future<List<int>?>` đang dùng ở 4
  /// nơi gọi khác nhau — đánh đổi: chỉ đáng tin cậy khi ĐỌC NGAY sau khi
  /// `await` xong 1 lệnh build (đúng cách mọi nơi gọi hiện tại đang dùng,
  /// tuần tự — không có 2 lệnh build chạy đồng thời trong app này).
  static final List<String> lastBuildErrors = [];
  static Future<List<int>?> buildDocx(
    BuildContext context,
    String jsonText, {
    ProviderConfig? imageGenProvider,
  }) async {
    lastBuildErrors.clear();
    Map<String, dynamic> doc;
    try {
      doc = jsonDecode(jsonText) as Map<String, dynamic>;
    } catch (e) {
      lastBuildErrors.add('Không đọc được JSON tổng thể (không phải lỗi Python — cấu trúc JSON AI trả về bị sai): $e');
      return null;
    }
    final blocks = (doc['blocks'] as List?)?.toList() ?? [];
    final images = <String, List<int>>{};
    var chartCounter = 0;

    for (var i = 0; i < blocks.length; i++) {
      final block = blocks[i];
      if (block is! Map) continue;
      final type = block['type'] as String?;
      if (type == 'chart' || type == 'diagram') {
        chartCounter++;
        final id = 'chart$chartCounter';
        final png = await ChartRenderer.renderToPng(context, Map<String, dynamic>.from(block));
        if (png != null) {
          images[id] = png;
          blocks[i] = {'type': 'image', 'imageId': id, 'caption': block['title'], 'widthCm': 15};
        } else {
          blocks[i] = {
            'type': 'paragraph',
            'runs': [
              {'text': '[Không vẽ được biểu đồ/sơ đồ "${block['title'] ?? type}"]', 'italic': true}
            ]
          };
        }
      } else if (type == 'python') {
        if (context.mounted) {
          final blockMap = Map<String, dynamic>.from(block);
          final result = await _runPython(context, blockMap);
          blocks[i] = _pythonResultToBlock(result, blockMap, images);
        } else {
          blocks[i] = _errorParagraph('Không chạy được Python (màn hình đã đóng).');
        }
      } else if (type == 'image') {
        final bytes = await _resolveImageBytes(Map<String, dynamic>.from(block), imageGenProvider);
        if (bytes != null) {
          final id = 'img${images.length + 1}';
          images[id] = bytes;
          final result = Map<String, dynamic>.from(block);
          result['imageId'] = id;
          blocks[i] = result;
        }
      }
    }

    doc['blocks'] = blocks;
    return DocxExporter.exportJson(doc, images: images);
  }

  static Future<List<int>?> buildPptx(
    BuildContext context,
    String jsonText, {
    ProviderConfig? imageGenProvider,
  }) async {
    lastBuildErrors.clear();
    Map<String, dynamic> pres;
    try {
      pres = jsonDecode(jsonText) as Map<String, dynamic>;
    } catch (e) {
      lastBuildErrors.add('Không đọc được JSON tổng thể (không phải lỗi Python — cấu trúc JSON AI trả về bị sai): $e');
      return null;
    }
    final images = <String, List<int>>{};
    var chartCounter = 0;
    final slides = (pres['slides'] as List?)?.toList() ?? [];

    for (var i = 0; i < slides.length; i++) {
      final slide = slides[i];
      if (slide is! Map) continue;
      final imgList = (slide['images'] as List?)?.toList() ?? [];
      for (var j = 0; j < imgList.length; j++) {
        final img = imgList[j];
        if (img is! Map) continue;
        if (img['type'] == 'chart' || img['type'] == 'diagram') {
          chartCounter++;
          final id = 'chart$chartCounter';
          final png = await ChartRenderer.renderToPng(context, Map<String, dynamic>.from(img));
          if (png != null) {
            images[id] = png;
            imgList[j] = {'imageId': id};
          }
        } else if (img['type'] == 'python') {
          if (context.mounted) {
            final result = await _runPython(context, Map<String, dynamic>.from(img));
            final b64 = result.ok ? result.files['image'] : null;
            if (b64 != null) {
              try {
                final bytes = base64Decode(b64);
                final id = 'pyimg${images.length + 1}';
                images[id] = bytes;
                imgList[j] = {'imageId': id};
              } catch (_) {
                imgList[j] = null;
              }
            } else {
              imgList[j] = null; // ảnh lỗi -> bỏ qua, không phá layout slide
            }
          } else {
            imgList[j] = null;
          }
        } else {
          final bytes = await _resolveImageBytes(Map<String, dynamic>.from(img), imageGenProvider);
          if (bytes != null) {
            final id = 'img${images.length + 1}';
            images[id] = bytes;
            imgList[j] = {'imageId': id};
          }
        }
      }
      slide['images'] = imgList.where((e) => e != null).toList();
      slides[i] = slide;
    }

    pres['slides'] = slides;
    return PptxExporter.exportJson(pres, images: images);
  }

  static Future<List<int>?> buildXlsx(BuildContext context, String jsonText) async {
    lastBuildErrors.clear();
    Map<String, dynamic> workbook;
    try {
      workbook = jsonDecode(jsonText) as Map<String, dynamic>;
    } catch (e) {
      lastBuildErrors.add('Không đọc được JSON tổng thể (không phải lỗi Python — cấu trúc JSON AI trả về bị sai): $e');
      return null;
    }
    final sheets = (workbook['sheets'] as List?)?.toList() ?? [];
    for (var i = 0; i < sheets.length; i++) {
      final sheet = sheets[i];
      if (sheet is! Map || sheet['type'] != 'python') continue;
      final name = sheet['name']?.toString() ?? 'Sheet${i + 1}';
      if (!context.mounted) {
        sheets[i] = _errorSheet(name, 'Không chạy được Python (màn hình đã đóng).');
        continue;
      }
      final result = await _runPython(context, Map<String, dynamic>.from(sheet));
      final rowsRaw = result.ok ? result.files['rows'] : null;
      if (rowsRaw == null) {
        sheets[i] = _errorSheet(name, 'Lỗi chạy Python: ${result.error ?? result.stderr}');
        continue;
      }
      try {
        final rows = jsonDecode(rowsRaw);
        sheets[i] = {
          'name': name,
          'rows': rows,
          if (sheet['merges'] != null) 'merges': sheet['merges'],
        };
      } catch (_) {
        sheets[i] = _errorSheet(name, 'Python không trả OUTPUT_FILES["rows"] là JSON hợp lệ.');
      }
    }
    workbook['sheets'] = sheets;
    return XlsxExporter.exportJson(workbook);
  }

  static Map<String, dynamic> _errorSheet(String name, String message) {
    lastBuildErrors.add('Sheet "$name": $message');
    return {
      'name': name,
      'rows': [
        {
          'cells': [
            {'value': message}
          ]
        }
      ],
    };
  }

  /// Chạy 1 block {"type":"python","code":"...","inputs":{...}} trong
  /// [PythonSandboxService]. `inputs` PHẢI là JSON thuần do chính block
  /// DSL khai báo — không bao giờ nhét thêm dữ liệu app (key, hội thoại...)
  /// vào đây khi gọi hàm này.
  static Future<PythonSandboxResult> _runPython(BuildContext context, Map<String, dynamic> block) {
    final code = block['code']?.toString() ?? '';
    final rawInputs = block['inputs'];
    final inputs = rawInputs is Map ? Map<String, dynamic>.from(rawInputs) : <String, dynamic>{};
    return PythonSandboxService.instance.run(context, code, inputs: inputs);
  }

  /// Chuyển kết quả sandbox thành 1 block docx hợp lệ theo `block['produces']`
  /// ('image' mặc định | 'table' | 'text'). Luôn trả về 1 block hiển thị
  /// được — nếu lỗi thì trả về đoạn văn nghiêng mô tả lỗi, KHÔNG âm thầm bỏ
  /// qua, để người dùng biết phần đó bị thiếu và vì sao.
  static Map<String, dynamic> _pythonResultToBlock(
    PythonSandboxResult result,
    Map<String, dynamic> block,
    Map<String, List<int>> images,
  ) {
    if (!result.ok) {
      return _errorParagraph('Lỗi chạy Python: ${result.error ?? (result.stderr.isNotEmpty ? result.stderr : "không rõ nguyên nhân")}');
    }
    final produces = block['produces']?.toString() ?? 'image';
    switch (produces) {
      case 'table':
        try {
          final headersRaw = result.files['headers'];
          final rowsRaw = result.files['rows'];
          final headers = headersRaw != null ? List<String>.from(jsonDecode(headersRaw) as List) : <String>[];
          final rows = rowsRaw != null
              ? (jsonDecode(rowsRaw) as List)
                  .map((r) => (r as List).map((e) => e.toString()).toList())
                  .toList()
              : <List<String>>[];
          return {'type': 'table', 'headers': headers, 'rows': rows};
        } catch (_) {
          return _errorParagraph('Python không trả OUTPUT_FILES["headers"]/["rows"] hợp lệ cho bảng.');
        }
      case 'text':
        final text = result.files['text'] ?? result.stdout.trim();
        return {
          'type': 'paragraph',
          'runs': [
            {'text': text.isEmpty ? '[Python chạy xong nhưng không có output]' : text}
          ],
        };
      case 'image':
      default:
        final b64 = result.files['image'];
        if (b64 == null) return _errorParagraph('Code Python không tạo OUTPUT_FILES["image"] (bytes PNG).');
        try {
          final bytes = base64Decode(b64);
          final id = 'pyimg${images.length + 1}';
          images[id] = bytes;
          return {'type': 'image', 'imageId': id, 'caption': block['caption'], 'widthCm': block['widthCm'] ?? 15};
        } catch (_) {
          return _errorParagraph('Không giải mã được ảnh do Python tạo ra.');
        }
    }
  }

  static Map<String, dynamic> _errorParagraph(String message) {
    lastBuildErrors.add(message);
    return {
      'type': 'paragraph',
      'runs': [
        {'text': '[$message]', 'italic': true}
      ],
    };
  }

  /// Xuất `.epub` — KHÔNG có class Dart riêng như docx/pptx/xlsx. Thay vào
  /// đó, ghép JSON DSL (do AI sinh, chỉ chứa DỮ LIỆU: title/chapters) với
  /// [epubMinPySource] (code Python CỐ ĐỊNH, viết sẵn 1 lần — xem
  /// HANDOFF.md mục 36) rồi chạy trong [PythonSandboxService]. Đây là cách
  /// thêm 1 định dạng file MỚI mà không cần viết thêm class exporter Dart:
  /// chỉ cần 1 module Python cố định (đáng tin cậy như code Dart, vì KHÔNG
  /// phải do AI tự viết lại logic đóng gói mỗi lần) + hàm gọi nó ở đây.
  static Future<List<int>?> buildEpub(BuildContext context, String jsonText) async {
    lastBuildErrors.clear();
    Map<String, dynamic> doc;
    try {
      doc = jsonDecode(jsonText) as Map<String, dynamic>;
    } catch (e) {
      lastBuildErrors.add('Không đọc được JSON tổng thể (không phải lỗi Python — cấu trúc JSON AI trả về bị sai): $e');
      return null;
    }
    if (!context.mounted) return null;
    const driverCode = '$epubMinPySource\nOUTPUT_FILES["file"] = build_from_dict(SANDBOX_INPUTS["doc"])\n';
    final result = await PythonSandboxService.instance.run(context, driverCode, inputs: {'doc': doc});
    if (!result.ok) {
      // Driver Python ở đây là code CỐ ĐỊNH của app (epubMinPySource,
      // KHÔNG phải do AI viết) — lỗi ở đây nhiều khả năng là bug thật của
      // app hoặc dữ liệu "doc" (title/chapters) sai kiểu, không phải do
      // AI viết code Python sai (khác hẳn docx/pptx/xlsx). Vẫn ghi log để
      // không mất dấu vết khi có lỗi.
      lastBuildErrors.add('Lỗi dựng epub: ${result.error ?? (result.stderr.isNotEmpty ? result.stderr : "không rõ nguyên nhân")}');
      return null;
    }
    final b64 = result.files['file'];
    if (b64 == null) {
      lastBuildErrors.add('Driver epub chạy xong nhưng không trả OUTPUT_FILES["file"].');
      return null;
    }
    try {
      return base64Decode(b64);
    } catch (e) {
      lastBuildErrors.add('Không giải mã được file epub trả về: $e');
      return null;
    }
  }

  /// Lấy bytes ảnh theo ĐÚNG thứ tự ưu tiên: base64 → url (tải, miễn phí) →
  /// prompt + imageGenProvider (gọi API sinh ảnh, tốn phí — chỉ khi 2 cách
  /// trên không có/thất bại).
  static Future<Uint8List?> _resolveImageBytes(
    Map<String, dynamic> block,
    ProviderConfig? imageGenProvider,
  ) async {
    // Ưu tiên CAO NHẤT: "ref" trỏ tới 1 ảnh đã có sẵn trong
    // [ImagePoolService] (ảnh trích xuất từ trình duyệt — mục "kho ảnh",
    // HANDOFF.md) — đọc thẳng từ bộ nhớ, KHÔNG mạng, KHÔNG API, nhanh nhất
    // và rẻ nhất trong 4 cách. Nếu id không tồn tại (ví dụ AI bịa ra 1 id
    // không có thật, hoặc kho ảnh đã bị xoá giữa chừng) → rơi xuống các
    // cách còn lại như bình thường, không coi là lỗi.
    final ref = block['ref']?.toString();
    if (ref != null && ref.isNotEmpty) {
      final pooled = ImagePoolService.instance.byId(ref);
      if (pooled != null) return pooled.bytes;
    }
    if (block['base64'] != null) {
      try {
        return base64Decode(block['base64'] as String);
      } catch (_) {}
    }
    if (block['url'] != null) {
      final bytes = await _downloadImage(block['url'] as String);
      if (bytes != null) return bytes;
    }
    final prompt = block['prompt']?.toString();
    if (prompt != null && prompt.isNotEmpty && imageGenProvider != null) {
      return ImageGenService.generate(imageGenProvider, prompt);
    }
    return null;
  }

  static Future<Uint8List?> _downloadImage(String url) async {
    try {
      final resp = await http.get(Uri.parse(url));
      if (resp.statusCode >= 200 && resp.statusCode < 300) return resp.bodyBytes;
    } catch (_) {}
    return null;
  }
}
