/// Ước lượng token mà KHÔNG cần tokenizer thật của từng hãng
/// (vì app không hardcode model nào, không thể tải đúng bảng BPE của mọi model).
///
/// Heuristic dùng phổ biến trong thực tế khi không có tokenizer chính xác:
/// - Văn bản Latin thường: ~4 ký tự / token.
/// - Văn bản có nhiều dấu tiếng Việt / CJK: tỷ lệ ký tự/token thấp hơn (~2-2.5),
///   vì mỗi ký tự có dấu hoặc chữ Hán thường được tách thành nhiều token hơn.
/// - Code: token dày hơn văn bản thường do nhiều ký tự đặc biệt/khoảng trắng.
///
/// Đây là ước lượng "đủ dùng" để quyết định khi nào cần tóm tắt/cắt bớt ngữ
/// cảnh, KHÔNG phải con số chính xác tuyệt đối. Việc cắt luôn có biên an toàn
/// (safety margin) để tránh vượt giới hạn context của model thật.
class TokenEstimator {
  static int estimate(String text) {
    if (text.isEmpty) return 0;

    final int totalChars = text.length;
    final int nonAsciiChars =
        text.runes.where((r) => r > 127).length;
    final double nonAsciiRatio = nonAsciiChars / totalChars;

    // Nội suy tỷ lệ ký tự/token giữa 4.0 (thuần Latin) và 2.2 (nhiều dấu/CJK).
    final double charsPerToken = 4.0 - (1.8 * nonAsciiRatio);

    final bool looksLikeCode = _looksLikeCode(text);
    final double adjusted = looksLikeCode ? charsPerToken * 0.85 : charsPerToken;

    final int estimate = (totalChars / adjusted).ceil();
    return estimate < 1 ? 1 : estimate;
  }

  static bool _looksLikeCode(String text) {
    final codeHints = RegExp(r'[{};]|=>|function |class |def |import |const |let |var ');
    final matches = codeHints.allMatches(text).length;
    return matches > 3;
  }

  /// Thêm ~4 token overhead cho mỗi message (role, delimiters...) — theo
  /// kinh nghiệm chung của các API dạng chat completion.
  static int estimateMessage(String content) => estimate(content) + 4;
}
