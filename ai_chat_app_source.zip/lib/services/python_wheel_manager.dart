import 'dart:io';
import 'package:path_provider/path_provider.dart';

/// Quản lý các file `.whl` (gói Python đã đóng gói sẵn — pure-Python hoặc
/// đã biên dịch sẵn cho WASM/Pyodide) do NGƯỜI DÙNG tự upload, để
/// [PythonSandboxService] cài vào sandbox qua `micropip.install("emfs:...")`
/// — KHÔNG cần mạng lúc chạy (xem HANDOFF.md mục 35).
///
/// Lưu vĩnh viễn trong thư mục riêng của app (`.../app_docs/python_wheels/`)
/// để còn dùng lại ở lần mở app sau (WebView sandbox tạo lại từ đầu mỗi lần
/// app khởi động, không tự nhớ gì).
///
/// LƯU Ý THÀNH THẬT: tự upload không đảm bảo file `.whl` đó CHẠY ĐƯỢC trên
/// Pyodide — nếu gói có phần biên dịch C/Rust (C-extension) mà KHÔNG phải
/// bản build riêng cho `wasm32-emscripten` (khác hẳn bản `.whl` tải từ PyPI
/// bình thường cho Windows/Linux/macOS), `micropip.install` sẽ báo lỗi rõ
/// ràng — không phải app "cố ý chặn", mà do bản thân WASM không chạy được
/// code máy biên dịch cho kiến trúc CPU khác. Gói THUẦN Python (không có
/// phần C) thì luôn cài được, bất kể tải từ đâu.
class PythonWheelManager {
  PythonWheelManager._();
  static final PythonWheelManager instance = PythonWheelManager._();

  Future<Directory> _dir() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('${docs.path}/python_wheels');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// Danh sách tên file `.whl` đã lưu (không kèm đường dẫn).
  Future<List<String>> list() async {
    final dir = await _dir();
    final files = dir.listSync().whereType<File>().where((f) => f.path.toLowerCase().endsWith('.whl'));
    return files.map((f) => f.uri.pathSegments.last).toList()..sort();
  }

  /// Lưu 1 file `.whl` mới (ghi đè nếu trùng tên).
  Future<void> add(String fileName, List<int> bytes) async {
    final dir = await _dir();
    final file = File('${dir.path}/$fileName');
    await file.writeAsBytes(bytes, flush: true);
  }

  Future<void> remove(String fileName) async {
    final dir = await _dir();
    final file = File('${dir.path}/$fileName');
    if (await file.exists()) await file.delete();
  }

  Future<List<int>> readBytes(String fileName) async {
    final dir = await _dir();
    return File('${dir.path}/$fileName').readAsBytes();
  }

  /// Tên gói suy ra từ tên file wheel chuẩn PEP 427:
  /// `<tên_gói>-<version>-<...>.whl` → lấy phần trước dấu `-` đầu tiên.
  /// Dùng để hiển thị gọn cho người dùng và để đưa vào prompt dạy AI biết
  /// "sandbox hiện có sẵn thư viện gì".
  static String packageNameFromFile(String fileName) {
    final base = fileName.endsWith('.whl') ? fileName.substring(0, fileName.length - 4) : fileName;
    final parts = base.split('-');
    return parts.isNotEmpty ? parts.first : base;
  }
}
