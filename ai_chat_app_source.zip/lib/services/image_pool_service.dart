import 'dart:typed_data';

class PooledImage {
  final String id;
  final Uint8List bytes;
  final String caption;
  final DateTime addedAt;
  PooledImage({required this.id, required this.bytes, required this.caption, required this.addedAt});
}

/// Trả lời câu hỏi "có ảnh rồi thì app có biết ráp vào đâu không" — TRƯỚC
/// ĐÂY: không, chỉ đưa 1 khối JSON base64 rời để người dùng tự copy/dán tay
/// vào ĐÚNG chỗ trong cấu trúc tài liệu, app không biết gì về "chỗ nào".
///
/// Cơ chế này giải quyết đúng vấn đề đó theo cách THỰC TẾ nhất: bản thân
/// app KHÔNG "hiểu" nội dung để tự quyết định 1 ảnh nên nằm ở đoạn nào —
/// nhưng AI tổng hợp (Tier 1, `SecretaryPromptBuilder.build`) THÌ có, vì nó
/// đọc toàn bộ văn bản nguồn. Nên thay vì bắt người dùng tự ráp, đưa
/// DANH SÁCH ảnh có sẵn (kèm mô tả ngắn) vào PROMPT gửi cho AI đó, để CHÍNH
/// AI quyết định ảnh nào nên minh hoạ cho đoạn nào — chỉ cần AI ghi 1 tham
/// chiếu NGẮN `{"type":"image","ref":"img1"}` vào đúng chỗ, KHÔNG cần chép
/// nguyên base64 (vừa đỡ nhầm lẫn vị trí, vừa đỡ tốn token — base64 của 1
/// ảnh có thể dài hàng trăm nghìn ký tự, tham chiếu chỉ vài ký tự).
///
/// Phạm vi CỐ Ý giới hạn trong bộ nhớ (KHÔNG lưu Hive/đĩa) — kho ảnh chỉ
/// tồn tại trong phiên làm việc hiện tại (mất khi tắt app), vì mục đích là
/// "vừa trích xuất xong, dùng ngay lúc tổng hợp" — không phải kho lưu trữ
/// ảnh lâu dài (đã có "Tài liệu nguồn" cho việc đó, nhưng đó là kho TEXT).
class ImagePoolService {
  ImagePoolService._();
  static final ImagePoolService instance = ImagePoolService._();

  final List<PooledImage> _images = [];
  int _counter = 0;

  List<PooledImage> get images => List.unmodifiable(_images);

  String add(Uint8List bytes, {String? caption}) {
    _counter++;
    final id = 'img$_counter';
    _images.add(PooledImage(
      id: id,
      bytes: bytes,
      caption: (caption == null || caption.trim().isEmpty) ? 'Ảnh $_counter (chưa đặt mô tả)' : caption.trim(),
      addedAt: DateTime.now(),
    ));
    return id;
  }

  PooledImage? byId(String id) {
    for (final img in _images) {
      if (img.id == id) return img;
    }
    return null;
  }

  void remove(String id) => _images.removeWhere((img) => img.id == id);

  void clear() {
    _images.clear();
    _counter = 0;
  }

  /// Chèn vào prompt gửi cho AI tổng hợp (xem
  /// `SecretaryPromptBuilder.build`) — liệt kê ảnh có sẵn để AI TỰ QUYẾT
  /// ĐỊNH đặt ảnh nào ở đâu trong tài liệu, chỉ cần ghi tham chiếu ngắn.
  /// Rỗng nếu kho chưa có ảnh nào (không thêm đoạn thừa vào prompt).
  String describeForPrompt() {
    if (_images.isEmpty) return '';
    final buffer = StringBuffer();
    buffer.writeln(
      'Có sẵn ${_images.length} ảnh đã trích xuất (từ trình duyệt), DÙNG LẠI '
      'bằng cách ghi {"type":"image","ref":"<id>","caption":"..."} vào ĐÚNG '
      'chỗ trong tài liệu mà bạn thấy hợp — KHÔNG chép base64, chỉ cần đúng '
      'id dưới đây:',
    );
    for (final img in _images) {
      buffer.writeln('- id="${img.id}": ${img.caption}');
    }
    return buffer.toString();
  }
}
