import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/conversation.dart';
import '../models/message.dart';
import '../models/provider_config.dart';
import '../models/generated_file.dart';
import '../models/source_document.dart';
import '../services/api_service.dart';
import '../services/context_manager.dart';
import '../services/secretary_prompt_builder.dart';
import '../services/storage_service.dart';
import '../services/token_estimator.dart';
import '../services/usage_service.dart';

class ChatProvider extends ChangeNotifier {
  final StorageService storage;
  final ApiService apiService = ApiService();
  late final ContextManager contextManager;
  late final UsageService usageService;

  Conversation? current;
  bool isStreaming = false;
  bool isSummarizing = false;
  String? lastError;

  final _uuid = const Uuid();

  ChatProvider(this.storage) {
    contextManager = ContextManager(apiService);
    usageService = UsageService(storage.settings);
  }

  // ---------------- Quản lý danh sách hội thoại / folder ----------------

  List<Conversation> conversationsInFolder(String? folderId) =>
      storage.conversationsInFolder(folderId);

  List<ChatFolder> get folders => storage.folders.values.toList();

  Future<Conversation> createConversation({String? folderId, ProviderConfig? provider}) async {
    final conv = Conversation(
      id: _uuid.v4(),
      title: 'Cuộc trò chuyện mới',
      messages: [],
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      folderId: folderId,
      providerConfigId: provider?.id,
    );
    await storage.conversations.put(conv.id, conv);
    current = conv;
    notifyListeners();
    return conv;
  }

  Future<void> deleteConversation(String id) async {
    await storage.conversations.delete(id);
    if (current?.id == id) current = null;
    notifyListeners();
  }

  Future<void> renameConversation(Conversation c, String newTitle) async {
    c.title = newTitle;
    await c.save();
    notifyListeners();
  }

  Future<void> togglePin(Conversation c) async {
    c.pinned = !c.pinned;
    await c.save();
    notifyListeners();
  }

  Future<ChatFolder> createFolder(String name) async {
    final folder = ChatFolder(id: _uuid.v4(), name: name);
    await storage.folders.put(folder.id, folder);
    notifyListeners();
    return folder;
  }

  /// Đổi Thinking/Temperature RIÊNG cho đoạn chat này ngay trong lúc chat —
  /// áp dụng từ tin nhắn tiếp theo, không cần vào lại Cài đặt Provider.
  Future<void> setChatOverrides(
    Conversation conv, {
    String? reasoningEffort,
    bool clearReasoningEffort = false,
    double? temperature,
    bool clearTemperature = false,
    bool? webSearch,
    bool clearWebSearch = false,
  }) async {
    if (clearReasoningEffort) {
      conv.reasoningEffortOverride = null;
    } else if (reasoningEffort != null) {
      conv.reasoningEffortOverride = reasoningEffort;
    }
    if (clearTemperature) {
      conv.temperatureOverride = null;
    } else if (temperature != null) {
      conv.temperatureOverride = temperature;
    }
    if (clearWebSearch) {
      conv.webSearchOverride = null;
    } else if (webSearch != null) {
      conv.webSearchOverride = webSearch;
    }
    await conv.save();
    notifyListeners();
  }

  Future<void> updateSystemPrompt(Conversation conv, String prompt) async {
    conv.systemPrompt = prompt;
    await conv.save();
    notifyListeners();
  }

  /// Ghi nhận 1 file vừa xuất ra vào panel "File đã tạo" của đoạn chat.
  Future<void> recordGeneratedFile(
    Conversation conv, {
    required String fileName,
    required String type,
    required String sourceMessageId,
  }) async {
    conv.generatedFiles.add(GeneratedFile(
      id: _uuid.v4(),
      fileName: fileName,
      type: type,
      sourceMessageId: sourceMessageId,
      createdAt: DateTime.now(),
    ));
    await conv.save();
    notifyListeners();
  }

  Future<void> removeGeneratedFile(Conversation conv, GeneratedFile file) async {
    conv.generatedFiles.removeWhere((f) => f.id == file.id);
    await conv.save();
    notifyListeners();
  }

  /// Đổi danh sách đoạn chat được liên kết. Không tự gọi API ở đây — cache
  /// tóm tắt sẽ được làm mới (nếu cần) ở lượt gửi tin nhắn tiếp theo, để
  /// không tốn request ngay cả khi người dùng chỉ đang thử bật/tắt link.
  Future<void> setLinkedConversations(Conversation conv, List<String> linkedIds) async {
    conv.linkedConversationIds = linkedIds;
    await conv.save();
    notifyListeners();
  }

  void selectConversation(Conversation c) {
    current = c;
    notifyListeners();
  }

  /// Trả về 1 ProviderConfig "hiệu lực" cho lượt gọi API hiện tại: giữ
  /// nguyên mọi thứ từ provider gốc đã lưu, CHỈ áp dụng override riêng của
  /// đoạn chat (nếu có) cho temperature/reasoningEffort. KHÔNG ghi đè lên
  /// provider gốc trong Hive — đây chỉ là 1 bản sao tạm dùng cho request.
  ProviderConfig _effectiveProvider(ProviderConfig base, Conversation conv) {
    if (conv.reasoningEffortOverride == null &&
        conv.temperatureOverride == null &&
        conv.webSearchOverride == null) {
      return base;
    }
    return ProviderConfig(
      id: base.id,
      name: base.name,
      baseUrl: base.baseUrl,
      apiKey: base.apiKey,
      model: base.model,
      format: base.format,
      maxContextTokens: base.maxContextTokens,
      temperature: conv.temperatureOverride ?? base.temperature,
      customRequestTemplate: base.customRequestTemplate,
      isDefault: base.isDefault,
      dailyTokenQuota: base.dailyTokenQuota,
      reasoningEffort: conv.reasoningEffortOverride ?? base.reasoningEffort,
      webSearchEnabled: conv.webSearchOverride ?? base.webSearchEnabled,
    );
  }

  /// Chuyển model đang dùng cho đoạn chat NGAY GIỮA CHỪNG, không cần người
  /// dùng giải thích lại ngữ cảnh — và tiết kiệm token tối đa (xem chi tiết
  /// giải thích trong ContextManager.switchModel).
  Future<void> switchProvider(Conversation conv, ProviderConfig newProvider) async {
    final oldProvider = storage.providerFor(conv) ?? newProvider;
    isSummarizing = true;
    notifyListeners();
    try {
      await contextManager.switchModel(conv, oldProvider, newProvider);
      conv.providerConfigId = newProvider.id;
      conv.liveTokenEstimate = contextManager.buildContext(conv, newProvider).estimatedTokens;
      await conv.save();
    } finally {
      isSummarizing = false;
      notifyListeners();
    }
  }

  // ---------------- Gửi tin nhắn (lõi tối ưu token) ----------------

  /// Gửi tin nhắn của người dùng, TỰ ĐỘNG:
  /// 1. Kiểm tra & tóm tắt ngữ cảnh cũ nếu hội thoại đã dài (tiết kiệm token).
  /// 2. Build context tối ưu (sliding window + summary) thay vì gửi toàn bộ.
  /// 3. Gọi API streaming, cập nhật UI theo từng chunk.
  Future<void> sendMessage(String text) async {
    final conv = current;
    if (conv == null) return;
    final provider = storage.providerFor(conv);
    if (provider == null) {
      lastError = 'Chưa cấu hình Provider API. Vào Cài đặt để thêm.';
      notifyListeners();
      return;
    }

    lastError = null;

    final userMsg = ChatMessage(
      id: _uuid.v4(),
      role: MessageRole.user,
      content: text,
      createdAt: DateTime.now(),
      approxTokens: TokenEstimator.estimateMessage(text),
    );
    conv.messages.add(userMsg);
    conv.updatedAt = DateTime.now();
    await conv.save();
    notifyListeners();

    // Bước 1: tự động tóm tắt nếu hội thoại đã dài / phức tạp, để giảm số
    // token phải gửi lại ở các lượt sau — đây chính là điểm "tiết kiệm token
    // tối ưu nhất" khi đoạn chat dài ra.
    if (contextManager.needsSummarization(conv, provider)) {
      isSummarizing = true;
      notifyListeners();
      try {
        await contextManager.summarizeIfNeeded(
          conv,
          provider,
          onUsage: (usage) => usageService.record(provider.id, usage),
        );
        await conv.save();
      } catch (e) {
        // Nếu tóm tắt lỗi (vd. mất mạng), vẫn tiếp tục gửi bằng sliding window
        // thường, không chặn người dùng.
      }
      isSummarizing = false;
      notifyListeners();
    }

    // Làm mới cache tóm tắt của các đoạn chat LIÊN KẾT (nếu có) — chỉ thực
    // sự gọi API khi cache đã cũ (xem refreshLinkedContext), nên không tốn
    // token thêm ở phần lớn các lượt gửi.
    if (conv.linkedConversationIds.isNotEmpty) {
      try {
        await contextManager.refreshLinkedContext(conv, storage, provider);
        await conv.save();
      } catch (_) {}
    }

    // Bước 2: build context tối ưu thay vì gửi toàn bộ lịch sử.
    // Áp dụng override riêng của đoạn chat (nếu có) cho temperature/thinking.
    final effectiveProvider = _effectiveProvider(provider, conv);
    final built = contextManager.buildContext(conv, provider);
    conv.liveTokenEstimate = built.estimatedTokens;

    final assistantMsg = ChatMessage(
      id: _uuid.v4(),
      role: MessageRole.assistant,
      content: '',
      createdAt: DateTime.now(),
    );
    conv.messages.add(assistantMsg);
    isStreaming = true;
    notifyListeners();

    try {
      final buffer = StringBuffer();
      await for (final chunk in apiService.sendMessageStream(
        config: effectiveProvider,
        messages: built.messages,
        onUsage: (usage) {
          usageService.record(provider.id, usage);
          // Có số thật rồi thì dùng luôn thay vì ước lượng, cho các quyết
          // định tóm tắt/hiển thị ở lượt sau chính xác hơn.
          conv.liveTokenEstimate = usage.totalTokens;
        },
      )) {
        buffer.write(chunk);
        assistantMsg.content = buffer.toString();
        notifyListeners();
      }
      assistantMsg.approxTokens = TokenEstimator.estimateMessage(assistantMsg.content);

      if (conv.title == 'Cuộc trò chuyện mới' && conv.messages.length >= 2) {
        conv.title = text.length > 40 ? '${text.substring(0, 40)}...' : text;
      }
    } catch (e) {
      lastError = e.toString();
      assistantMsg.content = assistantMsg.content.isEmpty
          ? '⚠️ Lỗi khi gọi API: $e'
          : assistantMsg.content;
    } finally {
      isStreaming = false;
      conv.updatedAt = DateTime.now();
      await conv.save();
      notifyListeners();
    }
  }

  /// "Thư ký AI": đọc [sources] (tài liệu upload hoặc trích xuất từ webview,
  /// KHÔNG tốn token) + [instruction] người dùng gõ thêm, rồi gọi API
  /// ĐÚNG 1 LẦN (không streaming, không lặp theo từng tài liệu) để tổng hợp
  /// thành 1 bản trả lời theo đúng cú pháp mà exporter [outputFormat] cần.
  ///
  /// Kết quả được thêm vào đoạn chat như 1 tin nhắn assistant bình thường
  /// (có ghi isSystemNote=false để vẫn tính đúng token đã dùng) — để người
  /// dùng luôn thấy rõ chính xác cái gì đã được gửi lên/nhận về, và có thể
  /// dùng lại panel "File đã tạo" / ExportMenu sẵn có để xuất file, thay vì
  /// phải xây thêm 1 luồng xuất file riêng.
  ///
  /// Trả về [ChatMessage] vừa tạo (để gọi ExportRunner.run ngay sau đó),
  /// hoặc null nếu lỗi.
  Future<ChatMessage?> compileSources({
    required List<SourceDocument> sources,
    required String instruction,
    required String outputFormat, // 'docx' | 'pptx' | 'xlsx' | 'zip'
  }) async {
    final conv = current;
    if (conv == null) return null;
    // Ưu tiên provider RIÊNG cho Thư ký AI (nếu người dùng đã chọn ở màn
    // WebviewCaptureScreen/SourceDocumentsScreen) — độc lập với provider
    // của đoạn chat đang mở, để dùng model rẻ/nhanh riêng cho tác vụ này.
    final provider = storage.secretaryProvider ?? storage.providerFor(conv);
    if (provider == null) {
      lastError = 'Chưa cấu hình Provider API. Vào Cài đặt để thêm.';
      notifyListeners();
      return null;
    }

    final prompt = SecretaryPromptBuilder.build(
      sources: sources,
      instruction: instruction,
      outputFormat: outputFormat,
    );

    final userNote = ChatMessage(
      id: _uuid.v4(),
      role: MessageRole.user,
      content: '📎 [Thư ký AI] Tổng hợp ${sources.length} tài liệu nguồn '
          '(${sources.map((s) => s.title).join(', ')}) → $outputFormat.\n'
          'Yêu cầu: ${instruction.trim().isEmpty ? '(mặc định) tổng hợp toàn bộ' : instruction.trim()}',
      createdAt: DateTime.now(),
      approxTokens: TokenEstimator.estimateMessage(prompt),
    );
    conv.messages.add(userNote);

    final assistantMsg = ChatMessage(
      id: _uuid.v4(),
      role: MessageRole.assistant,
      content: '',
      createdAt: DateTime.now(),
    );
    conv.messages.add(assistantMsg);
    isStreaming = true;
    notifyListeners();

    try {
      final effectiveProvider = _effectiveProvider(provider, conv);
      final result = await apiService.sendMessageOnce(
        config: effectiveProvider,
        messages: [ApiMessage('user', prompt)],
        onUsage: (usage) => usageService.record(provider.id, usage),
      );
      assistantMsg.content = result;
      assistantMsg.approxTokens = TokenEstimator.estimateMessage(result);
      return assistantMsg;
    } catch (e) {
      lastError = e.toString();
      assistantMsg.content = '⚠️ Lỗi khi gọi API: $e';
      return null;
    } finally {
      isStreaming = false;
      conv.updatedAt = DateTime.now();
      await conv.save();
      notifyListeners();
    }
  }

  /// Bật/tắt/chỉnh danh sách model cùng tham gia thảo luận cho đoạn chat.
  Future<void> setDiscussionProviders(Conversation conv, List<String> providerIds) async {
    conv.discussionProviderIds = providerIds;
    await conv.save();
    notifyListeners();
  }

  /// Gửi tin nhắn trong chế độ THẢO LUẬN NHIỀU MODEL: mỗi model trong
  /// `conv.discussionProviderIds` LẦN LƯỢT trả lời (1 lượt/model cho mỗi tin
  /// nhắn người dùng gửi), mỗi model thấy được câu trả lời của (các) model
  /// nói trước nó trong cùng lượt này — giống 1 bàn tròn thảo luận.
  /// Vẫn áp dụng đầy đủ cơ chế tối ưu token (sliding window/tóm tắt) RIÊNG
  /// cho từng model, vì mỗi model có `maxContextTokens` khác nhau.
  Future<void> sendDiscussionMessage(String text) async {
    final conv = current;
    if (conv == null || conv.discussionProviderIds.isEmpty) return;
    lastError = null;

    conv.messages.add(ChatMessage(
      id: _uuid.v4(),
      role: MessageRole.user,
      content: text,
      createdAt: DateTime.now(),
      approxTokens: TokenEstimator.estimateMessage(text),
    ));
    conv.updatedAt = DateTime.now();
    await conv.save();
    notifyListeners();

    isStreaming = true;
    notifyListeners();

    // Làm mới cache liên kết 1 LẦN trước cả vòng lặp thảo luận (dùng provider
    // đầu tiên trong danh sách để tóm tắt nếu cần) — không cần làm lại cho
    // từng model, vì nội dung tóm tắt liên kết không phụ thuộc model nào.
    if (conv.linkedConversationIds.isNotEmpty && conv.discussionProviderIds.isNotEmpty) {
      try {
        final firstProvider =
            storage.providers.values.firstWhere((p) => p.id == conv.discussionProviderIds.first);
        await contextManager.refreshLinkedContext(conv, storage, firstProvider);
        await conv.save();
      } catch (_) {}
    }

    for (final providerId in conv.discussionProviderIds) {
      ProviderConfig? provider;
      try {
        provider = storage.providers.values.firstWhere((p) => p.id == providerId);
      } catch (_) {
        continue; // provider đã bị xoá từ lúc thêm vào danh sách thảo luận
      }

      if (contextManager.needsSummarization(conv, provider)) {
        isSummarizing = true;
        notifyListeners();
        try {
          await contextManager.summarizeIfNeeded(
            conv,
            provider,
            onUsage: (usage) => usageService.record(provider!.id, usage),
          );
        } catch (_) {}
        isSummarizing = false;
        notifyListeners();
      }

      final built = contextManager.buildContext(conv, provider);
      conv.liveTokenEstimate = built.estimatedTokens;
      final effectiveProvider = _effectiveProvider(provider, conv);

      final assistantMsg = ChatMessage(
        id: _uuid.v4(),
        role: MessageRole.assistant,
        content: '',
        createdAt: DateTime.now(),
        speakerProviderId: provider.id,
        speakerName: provider.name,
      );
      conv.messages.add(assistantMsg);
      notifyListeners();

      try {
        final buffer = StringBuffer();
        await for (final chunk in apiService.sendMessageStream(
          config: effectiveProvider,
          messages: built.messages,
          onUsage: (usage) {
            usageService.record(provider!.id, usage);
            conv.liveTokenEstimate = usage.totalTokens;
          },
        )) {
          buffer.write(chunk);
          assistantMsg.content = buffer.toString();
          notifyListeners();
        }
        assistantMsg.approxTokens = TokenEstimator.estimateMessage(assistantMsg.content);
      } catch (e) {
        assistantMsg.content = assistantMsg.content.isEmpty
            ? '⚠️ Lỗi khi gọi ${provider.name}: $e'
            : assistantMsg.content;
      }
    }

    isStreaming = false;
    conv.updatedAt = DateTime.now();
    await conv.save();
    notifyListeners();
  }

  /// Ước lượng % ngữ cảnh đang dùng so với giới hạn của model, để hiển thị
  /// thanh tiến trình token cho người dùng biết khi nào app sắp tự tóm tắt.
  double contextUsageRatio() {
    final conv = current;
    if (conv == null) return 0;
    final provider = storage.providerFor(conv);
    if (provider == null) return 0;
    return (conv.liveTokenEstimate / provider.maxContextTokens).clamp(0, 1);
  }

  @override
  void dispose() {
    apiService.dispose();
    super.dispose();
  }
}
