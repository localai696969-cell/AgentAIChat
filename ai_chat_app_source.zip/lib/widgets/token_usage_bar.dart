import 'package:flutter/material.dart';

/// Thanh nhỏ hiển thị % ngữ cảnh đang dùng so với giới hạn model, giúp người
/// dùng thấy trực quan việc app đang tối ưu token (đổi màu khi gần ngưỡng
/// tự động tóm tắt).
class TokenUsageBar extends StatelessWidget {
  final double ratio; // 0..1
  final bool isSummarizing;

  const TokenUsageBar({super.key, required this.ratio, this.isSummarizing = false});

  @override
  Widget build(BuildContext context) {
    final color = ratio > 0.85
        ? Colors.red
        : ratio > 0.6
            ? Colors.orange
            : Theme.of(context).colorScheme.primary;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: ratio.clamp(0.02, 1.0),
                minHeight: 5,
                backgroundColor: color.withOpacity(0.15),
                valueColor: AlwaysStoppedAnimation(color),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            isSummarizing ? 'Đang tóm tắt để tiết kiệm token…' : '${(ratio * 100).toStringAsFixed(0)}% ngữ cảnh',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(color: color),
          ),
        ],
      ),
    );
  }
}
