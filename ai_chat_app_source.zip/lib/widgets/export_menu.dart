import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/conversation.dart';
import '../models/message.dart';
import '../providers/chat_provider.dart';
import '../services/secretary_prompt_builder.dart';
import 'export_runner.dart';

/// Hiển thị bottom sheet cho phép người dùng chọn 1 tin nhắn (thường là câu
/// trả lời cuối của AI) và xuất ra .docx / .pptx / .xlsx / .zip source code.
/// File xuất ra sẽ tự động được ghi vào panel "File đã tạo" của đoạn chat.
///
/// QUAN TRỌNG (vá lỗ hổng "AI không có tool thì sao xuất được file giàu
/// định dạng"): [ExportRunner] thử parse JSON DSL trước, rơi về markdown
/// rút gọn nếu AI không trả lời đúng JSON — nhưng NẾU người dùng chưa từng
/// báo trước cho AI biết phải trả lời theo JSON DSL, phần lớn model (nhất
/// là model không "quen" định dạng này) sẽ trả lời văn xuôi bình thường và
/// rơi vào nhánh rút gọn (mất bảng thật/ảnh/biểu đồ/mục lục). Mỗi dòng
/// dưới đây giờ có thêm nút 💡 "Copy hướng dẫn định dạng" — DÙNG TRƯỚC KHI
/// hỏi AI câu hỏi tiếp theo (dán vào đầu tin nhắn), y hệt tinh thần nút
/// "Copy prompt định dạng" đã có sẵn ở luồng "thư ký AI" (thư mục
/// `screens/sources`) — giờ áp dụng cho CẢ luồng chat bình thường. AI
/// KHÔNG cần bất kỳ tool/công cụ chạy code nào — chỉ cần trả lời đúng
/// cú pháp JSON/markdown quy định, phần "thực thi" (dựng file thật) hoàn
/// toàn do app tự làm ở [ExportRunner]/`DslDocumentBuilder`/các Exporter.
class ExportMenu extends StatelessWidget {
  final Conversation conversation;
  final ChatProvider chat;
  final List<ChatMessage> assistantMessages;

  const ExportMenu({
    super.key,
    required this.conversation,
    required this.chat,
    required this.assistantMessages,
  });

  static Future<void> show(
    BuildContext context,
    Conversation conv,
    ChatProvider chat,
    List<ChatMessage> assistantMessages,
  ) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => ExportMenu(conversation: conv, chat: chat, assistantMessages: assistantMessages),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (assistantMessages.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Text('Chưa có câu trả lời nào của AI trong đoạn chat này để xuất file.'),
      );
    }
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Xuất câu trả lời gần nhất thành file', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 2),
            Text(
              'Nút 💡 ở mỗi dòng: copy hướng dẫn định dạng để dán TRƯỚC câu hỏi '
              'kế tiếp — giúp AI trả lời sẵn đúng khuôn giàu định dạng (bảng '
              'thật/ảnh/biểu đồ/mục lục), thay vì để app tự đoán sau. AI không '
              'cần tool gì cả, chỉ cần theo đúng cú pháp.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 8),
            _tile(context, Icons.description_outlined, 'Word (.docx)', null, 'docx'),
            _tile(context, Icons.slideshow_outlined, 'PowerPoint (.pptx)',
                'Nội dung cần theo dạng slide: # tiêu đề, - gạch đầu dòng, --- ngăn slide', 'pptx'),
            _tile(context, Icons.table_chart_outlined, 'Excel (.xlsx)',
                'Nội dung cần theo dạng bảng, các cột cách nhau bởi |', 'xlsx'),
            _tile(context, Icons.folder_zip_outlined, 'Source code dự án (.zip)',
                'Tự nhận diện các code block có đường dẫn file để đóng gói', 'zip'),
            _tile(context, Icons.notes_outlined, 'Văn bản thuần (.txt)',
                'Ghi nguyên văn tin nhắn, không cần định dạng gì', 'txt'),
            _tile(context, Icons.menu_book_outlined, 'Sách điện tử (.epub)',
                'Cần JSON: {"title":"...","chapters":[{"title":"...","paragraphs":["...","..."]}]}', 'epub'),
          ],
        ),
      ),
    );
  }

  Widget _tile(BuildContext context, IconData icon, String title, String? subtitle, String type) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      subtitle: subtitle == null ? null : Text(subtitle),
      onTap: () => _run(context, assistantMessages.last, type),
      trailing: SecretaryPromptBuilder.formatInstruction(type).isEmpty
          ? null
          : IconButton(
              icon: const Icon(Icons.tips_and_updates_outlined, size: 20),
              tooltip: 'Copy hướng dẫn định dạng (dán TRƯỚC câu hỏi kế tiếp)',
              onPressed: () => _copyFormatHint(context, type),
            ),
    );
  }

  void _copyFormatHint(BuildContext context, String type) {
    Clipboard.setData(ClipboardData(text: SecretaryPromptBuilder.formatInstruction(type)));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text(
        'Đã copy — dán vào ĐẦU tin nhắn tiếp theo trước khi hỏi AI, để câu trả lời '
        'sẵn đúng định dạng giàu hơn khi xuất file (không cần AI có tool gì cả).',
      )),
    );
  }

  Future<void> _run(BuildContext context, ChatMessage msg, String type) async {
    await ExportRunner.run(context: context, chat: chat, conv: conversation, sourceMessage: msg, type: type);
    if (context.mounted) Navigator.pop(context);
  }
}
