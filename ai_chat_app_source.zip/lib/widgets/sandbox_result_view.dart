import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/python_sandbox_service.dart';

class SandboxResultView extends StatelessWidget {
  final PythonSandboxResult result;
  const SandboxResultView({super.key, required this.result});

  void _copy(BuildContext context, String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã copy.')));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final r = result;
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: r.ok ? theme.colorScheme.outlineVariant : theme.colorScheme.error,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                r.ok ? Icons.check_circle_outline : Icons.error_outline,
                size: 16,
                color: r.ok ? Colors.green : theme.colorScheme.error,
              ),
              const SizedBox(width: 6),
              Text(
                r.ok ? 'Đã chạy xong (chỉ trên sandbox cô lập)' : 'Lỗi',
                style: theme.textTheme.labelMedium,
              ),
            ],
          ),
          if (r.error != null) ...[
            const SizedBox(height: 6),
            SelectableText(r.error!, style: TextStyle(color: theme.colorScheme.error, fontSize: 12)),
          ],
          if (r.stdout.isNotEmpty) ...[
            const SizedBox(height: 6),
            const Text('stdout:', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
            SelectableText(r.stdout, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
          ],
          if (r.stderr.isNotEmpty) ...[
            const SizedBox(height: 6),
            const Text('stderr:', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.red)),
            SelectableText(r.stderr, style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: Colors.red)),
          ],
          if (r.ok && r.stdout.isEmpty && r.stderr.isEmpty && r.files.isEmpty)
            const Text('(Không có output — code chạy xong nhưng không in/gán gì.)',
                style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic)),
          if (r.files.isNotEmpty) ...[
            const SizedBox(height: 6),
            const Text('Biến OUTPUT_FILES đã gán:', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
            for (final entry in r.files.entries)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: SelectableText(
                        '${entry.key}: ${entry.value.length > 300 ? '${entry.value.substring(0, 300)}… (${entry.value.length} ký tự, đã cắt bớt)' : entry.value}',
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 11),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.content_copy, size: 14),
                      visualDensity: VisualDensity.compact,
                      tooltip: 'Copy nguyên văn ${entry.key}',
                      onPressed: () => _copy(context, entry.value),
                    ),
                  ],
                ),
              ),
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Text(
                'Lưu ý: OUTPUT_FILES chỉ hữu ích khi xuất tài liệu (docx/pptx/xlsx/epub) '
                'qua nút xuất file — chạy thử ở đây KHÔNG tự lưu thành file trên máy.',
                style: TextStyle(fontSize: 11, fontStyle: FontStyle.italic),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
