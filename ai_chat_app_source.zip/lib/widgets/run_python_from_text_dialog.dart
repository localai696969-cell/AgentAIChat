import 'package:flutter/material.dart';
import '../services/python_sandbox_service.dart';
import 'sandbox_result_view.dart';
import 'sandbox_run_progress.dart';

/// Hộp thoại "Chạy Python (từ nội dung trang)" — dùng ở
/// `webview_capture_screen.dart`. Vì hầu hết web chat AI (Claude.ai,
/// ChatGPT...) hiển thị khối code bằng `<pre>/<code>` có tô màu cú pháp,
/// KHÔNG có dấu ``` thật trong DOM, nên không thể chắc chắn tự động cắt
/// đúng phần code từ text trích được — thay vào đó cho phép người dùng TỰ
/// XEM/SỬA đoạn code trong ô văn bản này (đã cố đoán sẵn nếu tìm thấy khối
/// ```python) trước khi bấm Chạy.
class RunPythonFromTextDialog extends StatefulWidget {
  final String initialCode;
  const RunPythonFromTextDialog({super.key, required this.initialCode});

  @override
  State<RunPythonFromTextDialog> createState() => _RunPythonFromTextDialogState();
}

class _RunPythonFromTextDialogState extends State<RunPythonFromTextDialog> {
  late final TextEditingController _codeController;
  bool _running = false;
  bool _runWasFirstLoad = false;
  PythonSandboxResult? _result;

  @override
  void initState() {
    super.initState();
    _codeController = TextEditingController(text: widget.initialCode);
  }

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final code = _codeController.text;
    if (code.trim().isEmpty) return;
    final firstLoad = !PythonSandboxService.instance.isReady;
    setState(() {
      _running = true;
      _runWasFirstLoad = firstLoad;
      _result = null;
    });
    final result = await PythonSandboxService.instance.run(context, code);
    if (!mounted) return;
    setState(() {
      _running = false;
      _result = result;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Chạy Python (từ nội dung trang)'),
      content: SizedBox(
        width: double.maxFinite,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Kiểm tra/sửa lại đúng phần code cần chạy bên dưới (app cố đoán '
                'sẵn nếu tìm thấy khối ```python trong nội dung trang, nhưng '
                'nhiều web chat AI không để dấu ``` thật trong trang, nên có thể '
                'cần bạn tự cắt bớt phần chữ giải thích không phải code).',
                style: TextStyle(fontSize: 12),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _codeController,
                maxLines: 12,
                minLines: 6,
                style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Dán/sửa code Python ở đây...',
                ),
              ),
              if (_running) ...[
                const SizedBox(height: 10),
                SandboxRunProgress(firstLoad: _runWasFirstLoad),
              ],
              if (_result != null) ...[
                const SizedBox(height: 10),
                SandboxResultView(result: _result!),
              ],
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Đóng')),
        FilledButton.icon(
          onPressed: _running ? null : _run,
          icon: const Icon(Icons.play_arrow),
          label: const Text('Chạy'),
        ),
      ],
    );
  }
}
