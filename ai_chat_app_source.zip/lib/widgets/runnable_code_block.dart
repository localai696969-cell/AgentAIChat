import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:markdown/markdown.dart' as md;
import '../services/python_sandbox_service.dart';

/// Builder gắn vào [MarkdownBody] (xem `message_bubble.dart`) cho tag
/// `pre` — mọi khối code dạng ```lang ... ``` trong tin nhắn chat đi qua
/// đây. Nếu ngôn ngữ khai báo là python/py, vẽ thêm nút "Chạy thử" dùng
/// LẠI [PythonSandboxService] đã có sẵn cho luồng xuất tài liệu (Tier 2 —
/// xem HANDOFF.md) — đây là phần mở rộng để tính năng đó dùng được cho
/// MỌI tin nhắn chat bình thường, không chỉ lúc tổng hợp tài liệu.
/// Các ngôn ngữ khác vẫn hiển thị y hệt trước đây (chỉ code, không nút).
class RunnableCodeBlockBuilder extends MarkdownElementBuilder {
  // `pre` luôn là phần tử khối (không phải code inline `like this`, cái đó
  // là tag `code` KHÔNG nằm trong `pre` — nên đăng ký builder ở tag `pre`,
  // không phải `code`, để không ảnh hưởng code inline trong câu văn).
  @override
  bool isBlockElement() => true;

  @override
  Widget? visitElementAfterWithContext(
    BuildContext context,
    md.Element element,
    TextStyle? preferredStyle,
    TextStyle? parentStyle,
  ) {
    md.Element? codeElement;
    for (final child in element.children ?? const <md.Node>[]) {
      if (child is md.Element && child.tag == 'code') {
        codeElement = child;
        break;
      }
    }
    final code = (codeElement ?? element).textContent.replaceAll(RegExp(r'\n$'), '');
    String lang = '';
    final cls = codeElement?.attributes['class'] ?? '';
    if (cls.startsWith('language-')) lang = cls.substring('language-'.length).toLowerCase();
    final isPython = lang == 'python' || lang == 'py';
    return _CodeBlockCard(code: code, language: lang, runnable: isPython);
  }
}

class _CodeBlockCard extends StatefulWidget {
  final String code;
  final String language;
  final bool runnable;
  const _CodeBlockCard({required this.code, required this.language, required this.runnable});

  @override
  State<_CodeBlockCard> createState() => _CodeBlockCardState();
}

class _CodeBlockCardState extends State<_CodeBlockCard> {
  bool _running = false;
  PythonSandboxResult? _result;

  Future<void> _run() async {
    setState(() {
      _running = true;
      _result = null;
    });
    final result = await PythonSandboxService.instance.run(context, widget.code);
    if (!mounted) return;
    setState(() {
      _running = false;
      _result = result;
    });
  }

  void _copy(String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã copy.')));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 4, 0),
            child: Row(
              children: [
                Text(
                  widget.language.isEmpty ? 'code' : widget.language,
                  style: theme.textTheme.labelSmall?.copyWith(color: theme.colorScheme.outline),
                ),
                const Spacer(),
                if (widget.runnable)
                  Tooltip(
                    message: 'Chạy TRONG sandbox cô lập trên máy, không mạng, chỉ có '
                        'thư viện chuẩn Python trừ khi đã tự cài thêm (màn hình "Thư '
                        'viện Python cho sandbox"). Không phù hợp việc cần mạng/thư '
                        'viện ngoài phức tạp — khi đó dùng Tier 3 (nhờ AI khác tự chạy).',
                    child: IconButton(
                      icon: _running
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.play_arrow, size: 20),
                      onPressed: _running ? null : _run,
                      visualDensity: VisualDensity.compact,
                    ),
                  ),
                IconButton(
                  icon: const Icon(Icons.content_copy, size: 16),
                  onPressed: () => _copy(widget.code),
                  visualDensity: VisualDensity.compact,
                  tooltip: 'Copy code',
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: SelectableText(
              widget.code,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
            ),
          ),
          if (_result != null) _buildResult(theme),
        ],
      ),
    );
  }

  Widget _buildResult(ThemeData theme) {
    final r = _result!;
    return Container(
      margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: r.ok ? theme.colorScheme.outlineVariant : theme.colorScheme.error,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                r.ok ? Icons.check_circle_outline : Icons.error_outline,
                size: 16,
                color: r.ok ? Colors.green : theme.colorScheme.error,
              ),
              const SizedBox(width: 6),
              Text(
                r.ok ? 'Đã chạy xong (chỉ trên sandbox cô lập)' : 'Lỗi',
                style: theme.textTheme.labelMedium,
              ),
            ],
          ),
          if (r.error != null) ...[
            const SizedBox(height: 6),
            SelectableText(r.error!, style: TextStyle(color: theme.colorScheme.error, fontSize: 12)),
          ],
          if (r.stdout.isNotEmpty) ...[
            const SizedBox(height: 6),
            const Text('stdout:', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
            SelectableText(r.stdout, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
          ],
          if (r.stderr.isNotEmpty) ...[
            const SizedBox(height: 6),
            const Text('stderr:', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.red)),
            SelectableText(r.stderr, style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: Colors.red)),
          ],
          if (r.ok && r.stdout.isEmpty && r.stderr.isEmpty && r.files.isEmpty)
            const Text('(Không có output — code chạy xong nhưng không in/gán gì.)',
                style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic)),
          if (r.files.isNotEmpty) ...[
            const SizedBox(height: 6),
            const Text('Biến OUTPUT_FILES đã gán:', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
            for (final entry in r.files.entries)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: SelectableText(
                        '${entry.key}: ${entry.value.length > 300 ? '${entry.value.substring(0, 300)}… (${entry.value.length} ký tự, đã cắt bớt)' : entry.value}',
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 11),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.content_copy, size: 14),
                      visualDensity: VisualDensity.compact,
                      tooltip: 'Copy nguyên văn ${entry.key}',
                      onPressed: () => _copy(entry.value),
                    ),
                  ],
                ),
              ),
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Text(
                'Lưu ý: OUTPUT_FILES chỉ hữu ích khi xuất tài liệu (docx/pptx/xlsx/epub) '
                'qua nút xuất file — chạy thử ở đây KHÔNG tự lưu thành file trên máy.',
                style: TextStyle(fontSize: 11, fontStyle: FontStyle.italic),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
