import 'dart:async';
import 'package:flutter/material.dart';

/// Thanh tiến độ hiện trong lúc chạy code Python trong sandbox (Tier 2).
///
/// LƯU Ý THÀNH THẬT: Pyodide không phát ra tín hiệu "đã xong bao nhiêu %"
/// cho 1 đoạn code tuỳ ý đang chạy (khác việc tải file có Content-Length
/// biết trước) — nên đây là thanh tiến độ DẠNG ĐỘNG (indeterminate, chạy
/// qua lại liên tục) chứ KHÔNG phải % thật. Bù lại, hiện thêm bộ đếm giây
/// đã trôi qua + nhãn đúng giai đoạn (đang tải môi trường Python lần đầu,
/// hay đang chạy code) để người dùng biết máy không bị treo, không phải
/// hiện % giả vờ chính xác.
class SandboxRunProgress extends StatefulWidget {
  /// true nếu tại thời điểm bắt đầu, sandbox CHƯA nạp xong Pyodide — lần
  /// chạy này sẽ mất thêm thời gian nạp môi trường (thường 20–45s tuỳ máy)
  /// TRƯỚC KHI code thật sự bắt đầu chạy.
  final bool firstLoad;

  const SandboxRunProgress({super.key, required this.firstLoad});

  @override
  State<SandboxRunProgress> createState() => _SandboxRunProgressState();
}

class _SandboxRunProgressState extends State<SandboxRunProgress> {
  late final Stopwatch _stopwatch;
  late final Timer _timer;
  int _seconds = 0;

  @override
  void initState() {
    super.initState();
    _stopwatch = Stopwatch()..start();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() => _seconds = _stopwatch.elapsed.inSeconds);
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    _stopwatch.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final label = widget.firstLoad && _seconds < 45
        ? 'Lần đầu cần tải môi trường Python trong máy (~20–45 giây), sau đó '
            'các lần chạy sau sẽ nhanh hơn nhiều…'
        : 'Đang chạy code trong sandbox…';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const ClipRRect(
            borderRadius: BorderRadius.all(Radius.circular(4)),
            child: LinearProgressIndicator(minHeight: 4),
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Expanded(
                child: Text(label, style: theme.textTheme.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis),
              ),
              Text('${_seconds}s', style: theme.textTheme.bodySmall),
            ],
          ),
        ],
      ),
    );
  }
}
