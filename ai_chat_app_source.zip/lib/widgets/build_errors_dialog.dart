import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Trả lời đúng yêu cầu: "xuất chức năng log nếu chạy Python lỗi ra màn
/// hình cho bên kia biết nếu bên kia đưa code Python bị lỗi" — hiện TOÀN
/// BỘ lỗi gặp phải khi build 1 tài liệu (thường là do khối "python" trong
/// JSON DSL AI viết bị lỗi cú pháp/gọi sai OUTPUT_FILES...), kèm nút copy
/// sẵn — dán thẳng vào chat, yêu cầu AI (dù là AI trong app hay AI ngoài ở
/// Tier 3) tự sửa code rồi trả lời lại.
Future<void> showBuildErrorsDialog(BuildContext context, List<String> errors) async {
  if (errors.isEmpty) return;
  final combined = errors.asMap().entries.map((e) => '${e.key + 1}. ${e.value}').join('\n\n');
  final forAi = 'Code Python bạn đưa bị lỗi khi tôi chạy thử, sửa lại rồi trả lời lại '
      'NGUYÊN VĂN JSON đầy đủ (không chỉ phần đã sửa):\n\n$combined';
  await showDialog(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: Text('${errors.length} lỗi khi build tài liệu'),
      content: SizedBox(
        width: double.maxFinite,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Tài liệu VẪN được tạo ra (phần lỗi thay bằng chữ nghiêng mô tả lỗi '
                'ngay trong file) — nhưng nếu lỗi do khối Python AI viết sai, dán '
                'log dưới đây cho AI để nhờ sửa lại.',
                style: TextStyle(fontSize: 12),
              ),
              const SizedBox(height: 10),
              SelectableText(combined, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Đóng')),
        FilledButton.icon(
          icon: const Icon(Icons.content_copy, size: 16),
          label: const Text('Copy để dán cho AI'),
          onPressed: () {
            Clipboard.setData(ClipboardData(text: forAi));
            ScaffoldMessenger.of(dialogContext).showSnackBar(const SnackBar(
              content: Text('Đã copy — dán vào chat với AI để nhờ sửa code Python.'),
            ));
            Navigator.pop(dialogContext);
          },
        ),
      ],
    ),
  );
}
