import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import '../models/message.dart';
import 'run_python_from_text_dialog.dart';
import 'runnable_code_block.dart';

/// Đoán (KHÔNG dùng AI, không tốn token) xem tin nhắn có khả năng chứa
/// code Python nhưng KHÔNG được AI bọc trong khối ```python hay không —
/// đúng lỗ hổng người dùng phản ánh: "app ko nhận diện đc code python nếu
/// ko nằm trong ngoặc" (vì [RunnableCodeBlockBuilder] chỉ bắt được khối
/// code markdown CÓ dấu ```, đây là giới hạn của chính cách markdown hoạt
/// động, không phải lỗi rời rạc).
///
/// VỀ CÂU HỎI "dùng API model nhận diện có tốn token không": CÓ — bất kỳ
/// lệnh gọi API nào (kể cả chỉ để hỏi "đoạn này có phải code Python
/// không") đều tính phí theo số token gửi + nhận, dù là 1 câu hỏi ngắn.
/// Với 1 tin nhắn dài, gửi NGUYÊN VĂN cho AI đọc lại chỉ để phân loại có
/// thể tốn kém hơn cả bản thân câu trả lời gốc. Cách đoán CỤC BỘ dưới đây
/// KHÔNG tốn token nào (chạy hoàn toàn trên máy) — đánh đổi lại là kém
/// chính xác hơn AI thật (dò theo từ khoá/cấu trúc quen thuộc của Python,
/// có thể đoán nhầm với đoạn văn nói VỀ Python mà không phải code thật).
/// Nút hiện ra CHỈ LÀ GỢI Ý — người dùng vẫn tự xem/sửa lại code trước khi
/// chạy (xem [RunPythonFromTextDialog]), nên đoán nhầm không gây hại, chỉ
/// mất công bấm rồi thấy sai.
bool looksLikeUnfencedPython(String text) {
  if (text.contains('```')) return false; // đã có khối code thật, tránh nút trùng
  const signals = ['def ', 'import ', 'print(', 'elif ', 'return ', 'class ', 'self.', 'lambda ', 'except '];
  var hits = 0;
  for (final s in signals) {
    if (text.contains(s)) hits++;
    if (hits >= 2) return true;
  }
  return false;
}

class MessageBubble extends StatelessWidget {
  final ChatMessage message;
  const MessageBubble({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    final isUser = message.role == MessageRole.user;
    final theme = Theme.of(context);

    if (message.isSystemNote) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        child: Center(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: theme.colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.swap_horiz, size: 14),
                const SizedBox(width: 6),
                Text(message.content, style: theme.textTheme.labelSmall),
              ],
            ),
          ),
        ),
      );
    }

    if (message.isSummary) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: theme.colorScheme.secondaryContainer.withOpacity(0.4),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: theme.colorScheme.outlineVariant),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.summarize_outlined, size: 16),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Đã tóm tắt để tiết kiệm token:\n${message.content}',
                  style: theme.textTheme.bodySmall,
                ),
              ),
            ],
          ),
        ),
      );
    }

    if (message.collapsedIntoSummary) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 12),
        child: Opacity(
          opacity: 0.45,
          child: Text(
            (isUser ? 'Bạn: ' : 'Trợ lý: ') + message.content,
            style: theme.textTheme.bodySmall?.copyWith(fontStyle: FontStyle.italic),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      );
    }

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Column(
        crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          if (message.speakerName != null)
            Padding(
              padding: const EdgeInsets.only(left: 16, right: 16, bottom: 2),
              child: Text(
                message.speakerName!,
                style: theme.textTheme.labelSmall?.copyWith(
                  color: theme.colorScheme.primary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          Container(
            margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
            decoration: BoxDecoration(
              color: isUser ? theme.colorScheme.primary : theme.colorScheme.surfaceContainerHigh,
              borderRadius: BorderRadius.circular(16),
            ),
            child: message.content.isEmpty
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : MarkdownBody(
                    data: message.content,
                    selectable: true,
                    styleSheet: MarkdownStyleSheet.fromTheme(theme).copyWith(
                      p: TextStyle(color: isUser ? theme.colorScheme.onPrimary : theme.colorScheme.onSurface),
                    ),
                    // Tự vẽ mọi khối ```code``` — khối python được gắn thêm
                    // nút "Chạy trong sandbox" ngay tại đây (xem
                    // runnable_code_block.dart), áp dụng cho MỌI tin nhắn
                    // chat bình thường, không chỉ lúc tổng hợp tài liệu.
                    builders: {'pre': RunnableCodeBlockBuilder()},
                  ),
          ),
          if (message.content.isNotEmpty && looksLikeUnfencedPython(message.content))
            Padding(
              padding: const EdgeInsets.only(left: 12, right: 12, bottom: 4),
              child: TextButton.icon(
                onPressed: () => showDialog(
                  context: context,
                  builder: (_) => RunPythonFromTextDialog(initialCode: message.content),
                ),
                icon: const Icon(Icons.play_circle_outline, size: 16),
                label: const Text('Có vẻ có code Python chưa đóng khung — Chạy thử?', style: TextStyle(fontSize: 12)),
                style: TextButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 4), minimumSize: Size.zero),
              ),
            ),
        ],
      ),
    );
  }
}
