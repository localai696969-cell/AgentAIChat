import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/secretary_prompt_builder.dart';
import 'run_python_from_text_dialog.dart';

class ChatInputBar extends StatefulWidget {
  final bool isStreaming;
  final ValueChanged<String> onSend;
  final VoidCallback onExportTap;
  final VoidCallback onBrowseTap;

  const ChatInputBar({
    super.key,
    required this.isStreaming,
    required this.onSend,
    required this.onExportTap,
    required this.onBrowseTap,
  });

  @override
  State<ChatInputBar> createState() => _ChatInputBarState();
}

class _ChatInputBarState extends State<ChatInputBar> {
  final _controller = TextEditingController();

  void _submit() {
    final text = _controller.text.trim();
    if (text.isEmpty || widget.isStreaming) return;
    widget.onSend(text);
    _controller.clear();
  }

  /// Mở hộp thoại chạy Python thủ công (`RunPythonFromTextDialog`, đã có
  /// sẵn từ mục 41) — tự đoán prefill từ clipboard nếu người dùng vừa
  /// copy sẵn đoạn code từ tin nhắn AI (chọn text trong bong bóng chat rồi
  /// copy, vì `SelectableText`/`MarkdownBody` không hỗ trợ kéo-chọn xuyên
  /// nhiều dòng dễ dàng như 1 ô văn bản thường) — nếu clipboard trống hoặc
  /// lỗi đọc, mở hộp thoại trống để người dùng tự gõ/dán tay.
  Future<void> _openManualPythonRunner() async {
    String initial = '';
    try {
      final data = await Clipboard.getData(Clipboard.kTextPlain);
      initial = data?.text ?? '';
    } catch (_) {
      // Bỏ qua — không có clipboard hoặc lỗi đọc, mở hộp thoại trống.
    }
    if (!mounted) return;
    await showDialog(
      context: context,
      builder: (_) => RunPythonFromTextDialog(initialCode: initial),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
              tooltip: 'Xuất tài liệu / source code',
              onPressed: widget.onExportTap,
              icon: const Icon(Icons.attach_file),
            ),
            // Trước đây phải: mở menu (drawer) → "Tài liệu nguồn" → "Duyệt
            // web" mới tới được trình duyệt (đúng phản ánh của người dùng:
            // "sao ko có nút chọn ngay trên khung chat mà phải vào tài
            // liệu nguồn để chọn"). Giờ mở thẳng từ đây, 1 lần bấm.
            IconButton(
              tooltip: 'Duyệt web (lấy nội dung/chạy Python/đóng gói zip)',
              onPressed: widget.onBrowseTap,
              icon: const Icon(Icons.public),
            ),
            // Đúng phản ánh: nếu AI trả lời code Python KHÔNG bọc trong
            // ```python (nút ▶ tự động ở message_bubble.dart không nhận
            // diện chắc chắn được — mục 45), cho người dùng tự
            // COPY/DÁN/GÕ TAY đoạn code cần chạy, thay vì chỉ trông chờ
            // đoán tự động. Gộp chung 1 nút với việc copy sẵn 1 câu nhắc
            // AI trả lời đúng khuôn — đỡ thêm 1 icon riêng.
            PopupMenuButton<int>(
              tooltip: 'Chạy Python thủ công / nhắc AI đúng khuôn',
              icon: const Icon(Icons.terminal),
              onSelected: (v) async {
                if (v == 0) {
                  await _openManualPythonRunner();
                } else if (v == 1) {
                  await Clipboard.setData(const ClipboardData(text: SecretaryPromptBuilder.pythonFormatReminder));
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                      content: Text('Đã copy — dán vào ĐẦU câu hỏi tiếp theo để AI trả lời đúng khuôn ```python.'),
                    ));
                  }
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 0, child: Text('Dán/gõ code Python để chạy (nếu AI trả lời không đúng khuôn)')),
                PopupMenuItem(value: 1, child: Text('Copy câu nhắc AI luôn trả lời đúng khuôn ```python')),
              ],
            ),
            Expanded(
              child: TextField(
                controller: _controller,
                minLines: 1,
                maxLines: 6,
                textInputAction: TextInputAction.newline,
                decoration: InputDecoration(
                  hintText: 'Nhắn tin... (yêu cầu tạo docx, pptx, xlsx, source code...)',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
              ),
            ),
            const SizedBox(width: 4),
            IconButton.filled(
              onPressed: widget.isStreaming ? null : _submit,
              icon: widget.isStreaming
                  ? const SizedBox(
                      width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.send),
            ),
          ],
        ),
      ),
    );
  }
}
