import 'package:flutter/material.dart';

class ChatInputBar extends StatefulWidget {
  final bool isStreaming;
  final ValueChanged<String> onSend;
  final VoidCallback onExportTap;
  final VoidCallback onBrowseTap;

  const ChatInputBar({
    super.key,
    required this.isStreaming,
    required this.onSend,
    required this.onExportTap,
    required this.onBrowseTap,
  });

  @override
  State<ChatInputBar> createState() => _ChatInputBarState();
}

class _ChatInputBarState extends State<ChatInputBar> {
  final _controller = TextEditingController();

  void _submit() {
    final text = _controller.text.trim();
    if (text.isEmpty || widget.isStreaming) return;
    widget.onSend(text);
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
              tooltip: 'Xuất tài liệu / source code',
              onPressed: widget.onExportTap,
              icon: const Icon(Icons.attach_file),
            ),
            // Trước đây phải: mở menu (drawer) → "Tài liệu nguồn" → "Duyệt
            // web" mới tới được trình duyệt (đúng phản ánh của người dùng:
            // "sao ko có nút chọn ngay trên khung chat mà phải vào tài
            // liệu nguồn để chọn"). Giờ mở thẳng từ đây, 1 lần bấm.
            IconButton(
              tooltip: 'Duyệt web (lấy nội dung/chạy Python/đóng gói zip)',
              onPressed: widget.onBrowseTap,
              icon: const Icon(Icons.public),
            ),
            Expanded(
              child: TextField(
                controller: _controller,
                minLines: 1,
                maxLines: 6,
                textInputAction: TextInputAction.newline,
                decoration: InputDecoration(
                  hintText: 'Nhắn tin... (yêu cầu tạo docx, pptx, xlsx, source code...)',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
              ),
            ),
            const SizedBox(width: 4),
            IconButton.filled(
              onPressed: widget.isStreaming ? null : _submit,
              icon: widget.isStreaming
                  ? const SizedBox(
                      width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.send),
            ),
          ],
        ),
      ),
    );
  }
}
