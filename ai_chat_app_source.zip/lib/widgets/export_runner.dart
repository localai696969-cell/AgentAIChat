import 'package:flutter/material.dart';
import 'dart:convert';
import '../models/conversation.dart';
import '../models/message.dart';
import '../providers/chat_provider.dart';
import '../services/export/docx_export.dart';
import '../services/export/dsl_document_builder.dart';
import '../services/export/pptx_export.dart';
import '../services/export/xlsx_export.dart';
import '../services/export/code_zip_export.dart';
import '../utils/file_saver.dart';

/// Logic xuất file DÙNG CHUNG cho cả bottom sheet "Xuất tài liệu" (lần đầu)
/// và panel "File đã tạo" (xuất lại). Tách riêng để không lặp code, và để
/// panel bên phải có thể "xuất lại" đúng y hệt cách đã tạo lần đầu.
class ExportRunner {
  /// Xuất + lưu + ghi nhận vào panel "File đã tạo". Trả về tên file nếu
  /// thành công, null nếu không xuất được (ví dụ zip không tìm thấy code
  /// block hợp lệ).
  static Future<String?> run({
    required BuildContext context,
    required ChatProvider chat,
    required Conversation conv,
    required ChatMessage sourceMessage,
    required String type, // 'docx' | 'pptx' | 'xlsx' | 'zip' | 'txt' | 'epub'
  }) async {
    final content = sourceMessage.content;
    List<int>? bytes;
    String ext = type;

    // Thử JSON DSL trước (giàu định dạng: đậm/nghiêng/màu, bảng thật, ảnh,
    // biểu đồ/sơ đồ, mục lục, công thức Excel) — nếu AI trả lời không phải
    // JSON hợp lệ (ví dụ model cũ/yếu chưa theo kịp), rơi về cú pháp
    // markdown/bảng "|" rút gọn cũ (tương thích ngược).
    switch (type) {
      case 'docx':
        if (context.mounted) {
          bytes = await DslDocumentBuilder.buildDocx(context, content, imageGenProvider: chat.storage.imageGenProvider);
        }
        bytes ??= DocxExporter.export(title: 'Tài liệu', markdownLike: content);
        break;
      case 'pptx':
        if (context.mounted) {
          bytes = await DslDocumentBuilder.buildPptx(context, content, imageGenProvider: chat.storage.imageGenProvider);
        }
        bytes ??= PptxExporter.export(content);
        break;
      case 'xlsx':
        if (context.mounted) {
          bytes = await DslDocumentBuilder.buildXlsx(context, content);
        }
        bytes ??= XlsxExporter.export(content);
        break;
      case 'zip':
        bytes = CodeZipExporter.exportFromResponse(
          content,
          readmeExtra: '# Dự án được tạo bởi AgentAiChat\n\nGiải nén và push lên GitHub để build.',
        );
        break;
      case 'txt':
        // .txt không cần "render" gì cả — chính là nội dung tin nhắn, ghi
        // thẳng ra bytes UTF-8. KHÔNG qua JSON DSL/sandbox vì không cần.
        bytes = utf8.encode(content);
        break;
      case 'epub':
        if (context.mounted) {
          bytes = await DslDocumentBuilder.buildEpub(context, content);
        }
        // KHÔNG có fallback markdown-thô cho epub như docx/pptx/xlsx (chưa
        // có exporter dự phòng) — nếu JSON DSL lỗi/sandbox lỗi, báo rõ cho
        // người dùng thay vì âm thầm trả về null khó hiểu.
        break;
    }

    if (bytes == null) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Không xuất được — nội dung nguồn không còn phù hợp định dạng này.')),
        );
      }
      return null;
    }

    final fileName = '${_prefixFor(type)}_${DateTime.now().millisecondsSinceEpoch}.$ext';
    await FileSaver.saveAndShare(bytes, fileName);
    await chat.recordGeneratedFile(
      conv,
      fileName: fileName,
      type: type,
      sourceMessageId: sourceMessage.id,
    );
    return fileName;
  }

  static String _prefixFor(String type) {
    switch (type) {
      case 'docx':
        return 'tai_lieu';
      case 'pptx':
        return 'trinh_bay';
      case 'xlsx':
        return 'bang_tinh';
      case 'zip':
        return 'source_code';
      case 'txt':
        return 'van_ban';
      case 'epub':
        return 'sach_dien_tu';
      default:
        return 'file';
    }
  }
}
