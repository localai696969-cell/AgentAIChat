import 'package:flutter/material.dart';
import '../models/conversation.dart';
import '../providers/chat_provider.dart';

/// Cho phép chỉnh Thinking / Temperature / System prompt NGAY TRONG LÚC
/// CHAT, riêng cho đoạn chat đang mở — giống cách các web chat (Claude.ai,
/// ChatGPT...) cho đổi cài đặt giữa chừng mà không cần vào trang cấu hình
/// riêng. Không đụng tới giá trị mặc định đã lưu ở Provider.
class ChatQuickSettingsSheet extends StatefulWidget {
  final Conversation conversation;
  final ChatProvider chat;
  const ChatQuickSettingsSheet({super.key, required this.conversation, required this.chat});

  static Future<void> show(BuildContext context, Conversation conv, ChatProvider chat) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => ChatQuickSettingsSheet(conversation: conv, chat: chat),
    );
  }

  @override
  State<ChatQuickSettingsSheet> createState() => _ChatQuickSettingsSheetState();
}

class _ChatQuickSettingsSheetState extends State<ChatQuickSettingsSheet> {
  late String? _reasoningEffort;
  late bool _useCustomTemperature;
  late double _temperature;
  late bool? _webSearch; // null = mặc định Provider, true/false = ép bật/tắt
  late final TextEditingController _systemPrompt;

  @override
  void initState() {
    super.initState();
    final conv = widget.conversation;
    _reasoningEffort = conv.reasoningEffortOverride;
    _useCustomTemperature = conv.temperatureOverride != null;
    _temperature = conv.temperatureOverride ?? 0.7;
    _webSearch = conv.webSearchOverride;
    _systemPrompt = TextEditingController(text: conv.systemPrompt);
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          left: 16, right: 16, top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Cài đặt riêng cho đoạn chat này', style: Theme.of(context).textTheme.titleMedium),
              Text(
                'Áp dụng ngay từ tin nhắn tiếp theo, không ảnh hưởng tới các '
                'đoạn chat khác hay cấu hình mặc định của Provider.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 16),

              Text('Thinking / Reasoning effort', style: Theme.of(context).textTheme.labelLarge),
              DropdownButtonFormField<String?>(
                value: _reasoningEffort,
                items: const [
                  DropdownMenuItem(value: null, child: Text('Dùng mặc định của Provider')),
                  DropdownMenuItem(value: 'none', child: Text('Tắt')),
                  DropdownMenuItem(value: 'low', child: Text('Thấp')),
                  DropdownMenuItem(value: 'medium', child: Text('Trung bình')),
                  DropdownMenuItem(value: 'high', child: Text('Cao')),
                ],
                onChanged: (v) => setState(() => _reasoningEffort = v),
              ),

              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: Text('Tuỳ chỉnh Temperature riêng', style: Theme.of(context).textTheme.labelLarge),
                  ),
                  Switch(
                    value: _useCustomTemperature,
                    onChanged: (v) => setState(() => _useCustomTemperature = v),
                  ),
                ],
              ),
              if (_useCustomTemperature) ...[
                Text('Temperature: ${_temperature.toStringAsFixed(2)}'),
                Slider(
                  value: _temperature,
                  min: 0.0,
                  max: 2.0,
                  divisions: 40,
                  label: _temperature.toStringAsFixed(2),
                  onChanged: (v) => setState(() => _temperature = v),
                ),
              ],

              const SizedBox(height: 20),
              Text('Tìm kiếm web khi trả lời', style: Theme.of(context).textTheme.labelLarge),
              DropdownButtonFormField<bool?>(
                value: _webSearch,
                items: const [
                  DropdownMenuItem(value: null, child: Text('Dùng mặc định của Provider')),
                  DropdownMenuItem(value: true, child: Text('Ép BẬT cho đoạn chat này')),
                  DropdownMenuItem(value: false, child: Text('Ép TẮT cho đoạn chat này')),
                ],
                onChanged: (v) => setState(() => _webSearch = v),
              ),

              const SizedBox(height: 20),
              Text('System prompt của đoạn chat này', style: Theme.of(context).textTheme.labelLarge),
              const SizedBox(height: 6),
              TextField(
                controller: _systemPrompt,
                maxLines: 4,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Ví dụ: Luôn trả lời bằng tiếng Việt, giọng văn trang trọng...',
                ),
              ),

              const SizedBox(height: 20),
              FilledButton(
                onPressed: () async {
                  await widget.chat.setChatOverrides(
                    widget.conversation,
                    reasoningEffort: _reasoningEffort,
                    clearReasoningEffort: _reasoningEffort == null,
                    temperature: _useCustomTemperature ? _temperature : null,
                    clearTemperature: !_useCustomTemperature,
                    webSearch: _webSearch,
                    clearWebSearch: _webSearch == null,
                  );
                  await widget.chat.updateSystemPrompt(widget.conversation, _systemPrompt.text.trim());
                  if (context.mounted) Navigator.pop(context);
                },
                child: const Text('Áp dụng'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
