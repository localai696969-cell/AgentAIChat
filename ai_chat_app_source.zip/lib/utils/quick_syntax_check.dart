import 'dart:convert';

/// Soi lỗi cú pháp THÔ — KHÔNG phải trình biên dịch thật (app không có
/// Dart/Flutter SDK để phân tích đúng nghĩa), chỉ đếm các cặp ký tự phải
/// cân bằng (`{}`, `()`, `[]`, dấu nháy) để bắt được lỗi "quên đóng ngoặc/
/// nháy" — loại lỗi RẤT PHỔ BIẾN khi 1 AI dán/thiếu 1 đoạn code — TRƯỚC KHI
/// tốn cả 1 vòng push GitHub + chờ build (vài phút) mới biết.
///
/// CỐ Ý không cố phân tích đúng ngữ pháp ngôn ngữ thật (không phân biệt
/// được ngoặc trong comment/string một cách hoàn hảo cho MỌI trường hợp) —
/// mục tiêu chỉ là lưới lọc thô, có thể báo nhầm (false positive) với code
/// hợp lệ nhưng lạ (hiếm), nên LUÔN cho người dùng lựa chọn "vẫn cứ đẩy đi"
/// thay vì chặn cứng.
class QuickSyntaxCheck {
  /// Trả về danh sách cảnh báo (rỗng nếu không thấy vấn đề gì). Mỗi phần tử
  /// là 1 dòng mô tả `"<đường dẫn file>: <mô tả vấn đề>"`.
  static List<String> check(Map<String, String> files) {
    final warnings = <String>[];
    for (final entry in files.entries) {
      final path = entry.key;
      final content = entry.value;
      final ext = path.contains('.') ? path.substring(path.lastIndexOf('.') + 1) : '';
      if (!['dart', 'json', 'yaml', 'yml'].contains(ext)) continue; // chỉ soi định dạng hay gặp lỗi copy/paste thiếu

      if (ext == 'json') {
        // JSON thì có cách kiểm CHÍNH XÁC (không phải đoán) — thử parse thật
        // bằng dart:convert, không phải tự đoán/tự viết lại parser.
        try {
          jsonDecode(content);
        } catch (e) {
          warnings.add('$path: JSON không hợp lệ ($e)');
        }
        continue;
      }

      final braceDiff = _diff(content, '{', '}');
      final parenDiff = _diff(content, '(', ')');
      final bracketDiff = _diff(content, '[', ']');
      if (braceDiff != 0) warnings.add('$path: lệch ${braceDiff > 0 ? "$braceDiff dấu {" : "${-braceDiff} dấu }"} (thiếu 1 bên)');
      if (parenDiff != 0) warnings.add('$path: lệch ${parenDiff > 0 ? "$parenDiff dấu (" : "${-parenDiff} dấu )"} (thiếu 1 bên)');
      if (bracketDiff != 0) warnings.add('$path: lệch ${bracketDiff > 0 ? "$bracketDiff dấu [" : "${-bracketDiff} dấu ]"} (thiếu 1 bên)');

      if (ext == 'dart') {
        final singleQuotes = "'".allMatches(content).length - "\\'".allMatches(content).length;
        final doubleQuotes = '"'.allMatches(content).length - '\\"'.allMatches(content).length;
        // Dart cho phép cả 2 loại nháy, kiểm lẻ/chẵn từng loại (thô, có thể
        // báo nhầm với raw string r'...' chứa nháy — chấp nhận, chỉ là gợi ý).
        if (singleQuotes % 2 != 0 && !content.contains("'''")) {
          warnings.add("$path: có thể thiếu 1 dấu nháy đơn (')");
        }
        if (doubleQuotes % 2 != 0 && !content.contains('"""')) {
          warnings.add('$path: có thể thiếu 1 dấu nháy kép (")');
        }
      }
    }
    return warnings;
  }

  static int _diff(String content, String open, String close) {
    // Bỏ qua phần trong dòng comment "//" một cách thô (không xử lý được
    // comment nhiều dòng /* */ hay ngoặc trong string) — đủ dùng cho lưới
    // lọc thô, không phải phân tích cú pháp đầy đủ.
    final withoutLineComments = content.split('\n').map((line) {
      final idx = line.indexOf('//');
      return idx >= 0 ? line.substring(0, idx) : line;
    }).join('\n');
    final opens = open.allMatches(withoutLineComments).length;
    final closes = close.allMatches(withoutLineComments).length;
    return opens - closes;
  }
}
