import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// Lưu bytes ra file tạm rồi mở share sheet của hệ điều hành, để người dùng
/// chọn "Lưu vào máy", "Gửi qua Zalo/Email/Drive...", v.v.
class FileSaver {
  static Future<File> saveAndShare(List<int> bytes, String fileName) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/$fileName');
    await file.writeAsBytes(bytes, flush: true);
    await Share.shareXFiles([XFile(file.path)], text: fileName);
    return file;
  }

  static Future<File> saveOnly(List<int> bytes, String fileName) async {
    final dir = await getApplicationDocumentsDirectory();
    final exportsDir = Directory('${dir.path}/exports');
    if (!await exportsDir.exists()) {
      await exportsDir.create(recursive: true);
    }
    final file = File('${exportsDir.path}/$fileName');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }
}
