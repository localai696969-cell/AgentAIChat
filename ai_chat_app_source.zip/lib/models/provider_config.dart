import 'package:hive/hive.dart';

part 'provider_config.g.dart';

/// Định dạng payload mà API endpoint mong đợi.
/// App KHÔNG hardcode bất kỳ model/hãng cụ thể nào — người dùng tự cấu hình.
@HiveType(typeId: 3)
enum ApiFormat {
  /// Chuẩn "/v1/chat/completions" (OpenAI, Groq, OpenRouter, LM Studio, Ollama-openai, ...)
  @HiveField(0)
  openaiCompatible,

  /// Chuẩn "/v1/messages" (Anthropic Claude API)
  @HiveField(1)
  anthropicCompatible,

  /// Người dùng tự định nghĩa cấu trúc field bằng JSON template (nâng cao).
  @HiveField(2)
  custom,
}

@HiveType(typeId: 4)
class ProviderConfig extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String name; // tên hiển thị, ví dụ "OpenRouter - GPT-4o-mini"

  @HiveField(2)
  String baseUrl; // ví dụ https://api.openai.com/v1

  @HiveField(3)
  String apiKey;

  @HiveField(4)
  String model; // tên model, người dùng tự nhập, không hardcode

  @HiveField(5)
  ApiFormat format;

  @HiveField(6)
  int maxContextTokens; // ngưỡng ngữ cảnh tối đa của model đang dùng

  @HiveField(7)
  double temperature;

  @HiveField(8)
  String? customRequestTemplate; // dùng khi format = custom

  @HiveField(9)
  bool isDefault;

  /// Hạn mức token/ngày do CHÍNH NGƯỜI DÙNG tự khai báo (ví dụ họ đọc thấy
  /// free tier của provider là bao nhiêu thì tự nhập vào) — app không
  /// hardcode con số này vì mỗi hãng/gói mỗi khác và có thể đổi bất cứ lúc
  /// nào. null = không theo dõi hạn mức, chỉ hiển thị số đã dùng.
  @HiveField(10)
  int? dailyTokenQuota;

  /// Mức độ "suy luận sâu" (Thinking/Reasoning) trước khi trả lời.
  /// Giá trị: null (mặc định của model) | 'none' | 'low' | 'medium' | 'high'.
  /// Bật mức cao giúp model lập kế hoạch kỹ hơn trước khi viết code, giảm
  /// hẳn tình trạng trả về khối code chỉ có comment mà không có logic thật.
  /// Áp dụng cho Gemini (reasoning_effort qua endpoint OpenAI-compatible),
  /// các model OpenAI dòng suy luận (o-series/gpt-5 reasoning), và được tự
  /// động chuyển đổi sang "thinking budget" khi dùng định dạng Anthropic.
  @HiveField(11)
  String? reasoningEffort;

  /// Bật tìm kiếm web (grounding) để model tra cứu thông tin mới trước khi
  /// trả lời. Cách áp dụng khác nhau theo từng định dạng (xem
  /// `api_service.dart` hàm `_buildBody`):
  /// - Anthropic: thêm tool `web_search_20250305` — được tài liệu chính
  ///   thức xác nhận, hoạt động ổn định.
  /// - OpenAI-compatible (OpenAI thật): thêm `web_search_options: {}` —
  ///   CHỈ hoạt động nếu bạn chọn đúng model có hỗ trợ tìm kiếm (ví dụ
  ///   `gpt-4o-search-preview`, `gpt-5-search-api`), model thường sẽ bỏ
  ///   qua field này.
  /// - Gemini (qua endpoint OpenAI-compatible): tài liệu hiện tại của Google
  ///   CHƯA xác nhận field tương đương cho endpoint chat/completions (chỉ
  ///   thấy tài liệu cho ảnh/video) — bật lên có thể không có tác dụng gì
  ///   với Gemini cho tới khi Google bổ sung, nhưng không gây lỗi (field lạ
  ///   sẽ bị bỏ qua theo cơ chế tương thích của họ).
  @HiveField(12)
  bool webSearchEnabled;

  ProviderConfig({
    required this.id,
    required this.name,
    required this.baseUrl,
    required this.apiKey,
    required this.model,
    required this.format,
    this.maxContextTokens = 128000,
    this.temperature = 0.7,
    this.customRequestTemplate,
    this.isDefault = false,
    this.dailyTokenQuota,
    this.reasoningEffort,
    this.webSearchEnabled = false,
  });
}
