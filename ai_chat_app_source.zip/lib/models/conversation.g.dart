// GENERATED CODE (viết tay thay cho build_runner)
part of 'conversation.dart';

class ConversationAdapter extends TypeAdapter<Conversation> {
  @override
  final int typeId = 5;

  @override
  Conversation read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return Conversation(
      id: fields[0] as String,
      title: fields[1] as String,
      messages: (fields[2] as List).cast<ChatMessage>(),
      createdAt: fields[3] as DateTime,
      updatedAt: fields[4] as DateTime,
      folderId: fields[5] as String?,
      pinned: fields[6] == null ? false : fields[6] as bool,
      providerConfigId: fields[7] as String?,
      systemPrompt: fields[8] == null ? 'Bạn là một trợ lý AI hữu ích.' : fields[8] as String,
      liveTokenEstimate: fields[9] == null ? 0 : fields[9] as int,
      discussionProviderIds: fields[10] == null ? <String>[] : (fields[10] as List).cast<String>(),
      reasoningEffortOverride: fields[11] as String?,
      temperatureOverride: fields[12] as double?,
      webSearchOverride: fields[13] as bool?,
      generatedFiles: fields[14] == null ? <GeneratedFile>[] : (fields[14] as List).cast<GeneratedFile>(),
      linkedConversationIds: fields[15] == null ? <String>[] : (fields[15] as List).cast<String>(),
      linkedContextCache: fields[16] == null ? <String, String>{} : (fields[16] as Map).cast<String, String>(),
      linkedContextCacheVersion: fields[17] == null ? <String, int>{} : (fields[17] as Map).cast<String, int>(),
    );
  }

  @override
  void write(BinaryWriter writer, Conversation obj) {
    writer
      ..writeByte(18)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.messages)
      ..writeByte(3)
      ..write(obj.createdAt)
      ..writeByte(4)
      ..write(obj.updatedAt)
      ..writeByte(5)
      ..write(obj.folderId)
      ..writeByte(6)
      ..write(obj.pinned)
      ..writeByte(7)
      ..write(obj.providerConfigId)
      ..writeByte(8)
      ..write(obj.systemPrompt)
      ..writeByte(9)
      ..write(obj.liveTokenEstimate)
      ..writeByte(10)
      ..write(obj.discussionProviderIds)
      ..writeByte(11)
      ..write(obj.reasoningEffortOverride)
      ..writeByte(12)
      ..write(obj.temperatureOverride)
      ..writeByte(13)
      ..write(obj.webSearchOverride)
      ..writeByte(14)
      ..write(obj.generatedFiles)
      ..writeByte(15)
      ..write(obj.linkedConversationIds)
      ..writeByte(16)
      ..write(obj.linkedContextCache)
      ..writeByte(17)
      ..write(obj.linkedContextCacheVersion);
  }
}

class ChatFolderAdapter extends TypeAdapter<ChatFolder> {
  @override
  final int typeId = 6;

  @override
  ChatFolder read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return ChatFolder(
      id: fields[0] as String,
      name: fields[1] as String,
      colorValue: fields[2] == null ? 0xFF6750A4 : fields[2] as int,
    );
  }

  @override
  void write(BinaryWriter writer, ChatFolder obj) {
    writer
      ..writeByte(3)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.colorValue);
  }
}
