// GENERATED CODE (viết tay thay cho build_runner)
part of 'source_document.dart';

class SourceDocumentAdapter extends TypeAdapter<SourceDocument> {
  @override
  final int typeId = 8;

  @override
  SourceDocument read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return SourceDocument(
      id: fields[0] as String,
      title: fields[1] as String,
      content: fields[2] as String,
      origin: fields[3] as String,
      sourceLabel: fields[4] as String,
      createdAt: fields[5] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, SourceDocument obj) {
    writer
      ..writeByte(6)
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.title)
      ..writeByte(2)
      ..write(obj.content)
      ..writeByte(3)
      ..write(obj.origin)
      ..writeByte(4)
      ..write(obj.sourceLabel)
      ..writeByte(5)
      ..write(obj.createdAt);
  }
}
