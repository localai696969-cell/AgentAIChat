import 'package:hive/hive.dart';

part 'source_document.g.dart';

/// Một "tài liệu nguồn" để AI thư ký (secretary) đọc và tổng hợp thành file
/// theo yêu cầu (docx/pptx/xlsx/zip). Có 2 nguồn:
///  - 'upload'  : người dùng tự chọn file (txt/md/docx text thô/nội dung đã
///                xuất từ nơi khác, ví dụ file "Tải xuống thông tin của bạn"
///                từ Facebook, hoặc file export từ hệ thống nội bộ công ty).
///  - 'webview' : trích xuất TRỰC TIẾP nội dung trang đang mở trong trình
///                duyệt nhúng (WebViewCaptureScreen) bằng JS
///                `document.body.innerText` — KHÔNG gọi API model, nên
///                KHÔNG tốn token cho bước này, chỉ tốn token 1 LẦN DUY NHẤT
///                khi người dùng bấm "Tổng hợp".
@HiveType(typeId: 8)
class SourceDocument extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String title;

  /// Nội dung dạng text thuần đã trích xuất/đọc được.
  @HiveField(2)
  String content;

  /// 'upload' | 'webview'
  @HiveField(3)
  String origin;

  /// Tên file gốc hoặc URL trang đã trích xuất — hiển thị lại cho người
  /// dùng biết tài liệu này đến từ đâu.
  @HiveField(4)
  String sourceLabel;

  @HiveField(5)
  DateTime createdAt;

  SourceDocument({
    required this.id,
    required this.title,
    required this.content,
    required this.origin,
    required this.sourceLabel,
    required this.createdAt,
  });
}
