import 'package:hive/hive.dart';

part 'generated_file.g.dart';

/// Ghi nhận 1 file đã được xuất ra (docx/pptx/xlsx/zip) trong đoạn chat,
/// để hiển thị lại trong panel "File đã tạo" (giống panel Artifacts bên
/// phải của Claude), thay vì phải lục lại từng tin nhắn để xuất lại.
@HiveType(typeId: 7)
class GeneratedFile extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String fileName;

  /// 'docx' | 'pptx' | 'xlsx' | 'zip'
  @HiveField(2)
  String type;

  /// id của ChatMessage (câu trả lời AI) đã dùng để sinh ra file này — dùng
  /// để "xuất lại/chia sẻ lại" mà không cần lưu trữ file thật lâu dài.
  @HiveField(3)
  String sourceMessageId;

  @HiveField(4)
  DateTime createdAt;

  GeneratedFile({
    required this.id,
    required this.fileName,
    required this.type,
    required this.sourceMessageId,
    required this.createdAt,
  });
}
