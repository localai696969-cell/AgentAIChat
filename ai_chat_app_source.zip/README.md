# AgentAiChat (Flutter)

Ứng dụng Android (và iOS/Web nếu cần) đóng vai trò **client chat AI đa nhà
cung cấp**: gọi bất kỳ API model nào bạn cấu hình (OpenAI-compatible,
Anthropic-compatible, hoặc custom JSON template) — **không hardcode model
hay hãng cụ thể nào**.

## Tính năng chính

- **Quản lý nhiều đoạn chat** theo thư mục, ghim, đổi tên, xóa — giống các
  app chat AI phổ biến.
- **Không hardcode provider**: bạn tự nhập Base URL / API Key / Model name /
  Định dạng request trong màn hình *Cài đặt → Provider API*. Có thể tạo
  nhiều provider và đặt 1 cái làm mặc định, hoặc gán riêng provider cho từng
  đoạn chat.
- **Tối ưu token khi chat dài / công việc phức tạp** (xem chi tiết bên dưới).
- **Xuất tài liệu trực tiếp từ câu trả lời của AI**: Word (.docx),
  PowerPoint (.pptx), Excel (.xlsx), và **source code dự án đóng gói .zip**
  để tải lên GitHub build.
- Toàn bộ dữ liệu (hội thoại, API key) lưu **cục bộ trên máy** bằng Hive —
  ứng dụng không có backend riêng, chỉ gọi thẳng tới API bạn khai báo.

## Cơ chế tiết kiệm token (xem `lib/services/context_manager.dart`)

1. **Sliding window**: chỉ giữ nguyên văn N tin nhắn gần nhất (mặc định 12)
   để gửi lên model.
2. **Auto-summarize**: khi tổng token ước tính vượt 65% giới hạn ngữ cảnh
   của model đang dùng, các tin nhắn cũ hơn cửa sổ trượt được tự động gọi
   API tóm tắt lại thành 1 đoạn ngắn gọn, thay thế cho toàn bộ lịch sử cũ ở
   các lượt gửi sau.
3. **Incremental summary**: các lần tóm tắt sau sẽ gộp bản tóm tắt cũ + tin
   nhắn mới, tránh việc tích tụ nhiều đoạn tóm tắt chồng nhau.
4. **Safety margin 15%**: không bao giờ build ngữ cảnh sát 100% giới hạn,
   luôn chừa chỗ cho phần trả lời.
5. Thanh tiến trình token (`TokenUsageBar`) hiển thị trực quan % ngữ cảnh
   đang dùng ngay trong màn hình chat.

Vì app không hardcode model, việc đếm token dùng công thức ước lượng
(`lib/services/token_estimator.dart`) thay vì tokenizer chính xác của từng
hãng — đủ chính xác để quyết định thời điểm tóm tắt, có biên an toàn.

## Tìm kiếm web khi trả lời

Bật ở 2 nơi:
- **Mặc định cho Provider**: switch "Tìm kiếm web khi trả lời" khi thêm/sửa
  Provider trong Cài đặt.
- **Riêng từng đoạn chat**: trong bảng ⚙️ Cài đặt nhanh lúc chat, dropdown
  tri-state "Dùng mặc định / Ép BẬT / Ép TẮT" — ưu tiên cao hơn mặc định
  Provider, không ảnh hưởng các đoạn chat khác.

Cách áp dụng khác nhau theo định dạng API (xem `api_service.dart`):

| Định dạng | Cơ chế | Độ tin cậy |
|---|---|---|
| Anthropic-compatible | Tool chính thức `web_search_20250305`, server tự chạy | Ổn định, có tài liệu chính thức |
| OpenAI-compatible (OpenAI thật) | Field `web_search_options: {}` | Chỉ có tác dụng nếu **model** là dòng search (`gpt-4o-search-preview`, `gpt-5-search-api`...) — model thường sẽ bỏ qua field này |
| Gemini (qua endpoint OpenAI-compatible) | Cũng gửi `web_search_options: {}` | Tài liệu chính thức của Google (tính đến giờ) CHƯA xác nhận field tương đương cho endpoint chat/completions — có thể chưa có tác dụng, nhưng không gây lỗi request (field lạ bị bỏ qua an toàn theo cơ chế tương thích của họ) |
| Custom | Thêm `web_search_options: {}` vào JSON template | Tuỳ backend bạn trỏ tới có hỗ trợ hay không |

Nói thẳng: đây là tính năng "bật/tắt đúng cờ API", KHÔNG phải app tự cào
web (không có scraping/browser nào chạy ngầm) — nếu provider/model bạn chọn
không hỗ trợ, model vẫn trả lời bình thường bằng kiến thức có sẵn, chỉ là
không tra cứu được thông tin mới.

## Chỉnh Thinking / Temperature / System prompt ngay trong lúc chat

Trước đây các cài đặt này chỉ đặt được lúc thêm Provider (áp dụng chung cho
mọi đoạn chat dùng provider đó). Giờ bấm icon ⚙️ (tune) trên thanh tiêu đề
màn hình chat để mở **Cài đặt riêng cho đoạn chat này** — đổi ngay, áp dụng
từ tin nhắn tiếp theo, giống cách các web chat khác cho phép:

- **Thinking/Reasoning effort**: đổi riêng cho đoạn chat này (Mặc định /
  Tắt / Thấp / Trung bình / Cao), không cần vào lại Cài đặt Provider.
- **Temperature**: bật công tắc để tuỳ chỉnh riêng (0.0–2.0), tắt công tắc
  để quay lại dùng giá trị mặc định của Provider.
- **System prompt**: sửa trực tiếp cho đoạn chat đang mở.

Override này KHÔNG ghi đè lên Provider gốc (Provider vẫn giữ giá trị mặc
định để dùng cho các đoạn chat khác) — xem `ChatProvider._effectiveProvider`
và `Conversation.reasoningEffortOverride/temperatureOverride`.

Ngoài ra, `temperature` giờ có ô chỉnh (slider) khi thêm/sửa Provider trong
Cài đặt — trước đây field này có trong code nhưng chưa có UI, giờ đã thêm.

## Tên app & icon

App tên hiển thị **"AgentAiChat"**, icon riêng (2 bubble chat chồng nhau,
tượng trưng nhiều model cùng tham gia hội thoại) tại
`assets/icon/app_icon.png`. CI tự sinh icon cho mọi độ phân giải Android
bằng `flutter_launcher_icons` — không cần làm gì thêm khi build qua
GitHub Actions. Muốn đổi icon: thay file PNG đó (khuyến nghị 1024×1024)
rồi build lại.

## Thảo luận nhóm nhiều model cùng lúc

Bấm icon 👥 trên thanh tiêu đề màn hình chat → chọn ≥2 Provider đã thêm.
Từ tin nhắn tiếp theo, **mỗi model sẽ lần lượt trả lời** cùng 1 câu hỏi của
bạn, theo đúng thứ tự đã chọn — model sau LUÔN thấy được câu trả lời của
(các) model nói trước nó trong cùng lượt (giống 1 bàn tròn chuyên gia), nhờ
mỗi câu trả lời được gắn nhãn tên model (`[Tên model]: ...`) khi đưa vào
ngữ cảnh gửi cho model tiếp theo — để nó hiểu đây là phát biểu của người
khác, không phải lượt trả lời trước đó của chính nó.

Toàn bộ cơ chế tối ưu token (sliding window/tự tóm tắt) vẫn áp dụng **riêng
cho từng model** trong nhóm, vì mỗi model có `maxContextTokens` khác nhau.
Bỏ chọn hết (hoặc chỉ giữ 1 model) để quay lại chat bình thường.

## Panel "File đã tạo" (giống Artifacts của Claude)

Icon 📁 trên thanh tiêu đề (có badge số lượng) mở panel bên phải liệt kê
mọi file đã xuất trong đoạn chat — xem lại tên file, **chia sẻ lại** (xuất
lại từ đúng câu trả lời gốc, không cần lục tin nhắn), hoặc xoá khỏi danh
sách. Không lưu trữ bytes file lâu dài — "chia sẻ lại" sẽ regenerate file
từ nội dung gốc mỗi lần, nên panel này nhẹ, không tốn dung lượng máy.

## Liên kết đoạn chat với nhau (bắt buộc tối ưu token, không phình to)

Icon 🔗 trên thanh tiêu đề → chọn các đoạn chat khác để liên kết tới đoạn
chat đang mở. Nội dung đoạn chat liên kết **KHÔNG BAO GIỜ được gửi nguyên
văn** — chỉ đưa vào dưới dạng bản tóm tắt đã rút gọn cứng, qua
`ContextManager.refreshLinkedContext`:

1. Nếu đoạn chat được liên kết **đã tự có sẵn bản tóm tắt** (do đủ dài để
   tự kích hoạt auto-summarize) → tái dùng nguyên vẹn, **0 request thêm**.
2. Nếu đoạn chat đó còn ngắn (≤4 tin nhắn) → lấy nguyên văn (vốn đã ngắn),
   cũng không cần gọi API.
3. Chỉ khi đoạn chat đó dài nhưng chưa từng tự tóm tắt, mới gọi **đúng 1**
   request tóm tắt cực ngắn (≤100 từ).
4. Mọi bản tóm tắt đều bị **cắt cứng tối đa 600 ký tự** trước khi lưu cache
   — dù đoạn chat được liên kết dài hàng nghìn tin nhắn, phần chèn vào ngữ
   cảnh vẫn chỉ chiếm 1 khối nhỏ cố định.
5. Cache chỉ được tính lại khi đoạn chat kia có thêm ≥5 tin nhắn mới kể từ
   lần cache trước — nếu không, dùng lại cache, hoàn toàn không gọi API.

Nhờ vậy, chi phí token cho việc liên kết bị chặn trên ở một hằng số cố định
nhân với số lượng đoạn chat được liên kết — **không bao giờ tỉ lệ thuận**
với độ dài từng đoạn chat đó. Bản tóm tắt link luôn được cộng vào phần tính
ngân sách token/ngưỡng tự tóm tắt của chính đoạn chat đang mở, nên không
bao giờ bị tính thiếu.

## Cách build ra file APK

Mình không thể build sẵn file `.apk` trong quá trình tạo project (môi
trường tạo code không có Android SDK/mạng), nhưng bạn có 2 cách sau:

### Cách 2 — Để GitHub tự build (khuyên dùng — không cần cài Flutter ở máy bạn)

Workflow đã được cập nhật để **tự sinh thư mục `android/` và tự thêm quyền
Internet ngay trên GitHub Actions** — bạn không cần chạy `flutter create`
hay sửa AndroidManifest ở máy mình nữa. Chỉ cần:

1. Tạo 1 repo GitHub mới, push **nguyên trạng** toàn bộ nội dung zip này lên
   (đúng như giải nén ra, không cần thêm/sửa gì).
2. Vào tab **Actions** của repo — workflow "Build APK" tự chạy khi push lên
   nhánh `main`.
3. Chờ xong (lần đầu ~5-8 phút vì phải cài Flutter + sinh project) → vào
   run đó → mục **Artifacts** → tải `app-release-apk` về, giải nén ra là có
   `app-release.apk` cài được ngay lên điện thoại.

### Cách 1 — Build trên máy bạn (chỉ cần khi muốn debug nhanh, không bắt buộc)

```bash
# 1. Cài Flutter SDK: https://docs.flutter.dev/get-started/install

# 2. Giải nén project này ra 1 thư mục, ví dụ ai_chat_app/, rồi vào đó
cd ai_chat_app

# 3. Tạo phần khung Android/iOS còn thiếu (project mình gửi chỉ có lib/ +
#    pubspec.yaml, KHÔNG có sẵn thư mục android/ios vì cần đúng phiên bản
#    Gradle/Kotlin khớp với Flutter bạn đang cài)
flutter create --org com.example --project-name ai_chat_app .

# Lệnh trên có thể ghi đè lib/main.dart mẫu — nếu vậy, chỉ cần copy lại
# toàn bộ thư mục lib/ và pubspec.yaml từ file zip mình gửi, đè lên lại.

# 4. Mở android/app/src/main/AndroidManifest.xml, thêm quyền Internet
#    (bắt buộc để gọi API):
#    <uses-permission android:name="android.permission.INTERNET"/>

# 5. Cài dependencies
flutter pub get

# 6. Build APK
flutter build apk --release

# File kết quả nằm ở:
# build/app/outputs/flutter-apk/app-release.apk
```

## Cấu trúc thư mục

```
lib/
  models/          # ChatMessage, Conversation, ProviderConfig (+ Hive adapters .g.dart)
  services/
    api_service.dart          # Gọi API model (OpenAI/Anthropic/Custom), hỗ trợ streaming
    context_manager.dart      # Lõi tối ưu token (sliding window + auto-summarize)
    token_estimator.dart      # Ước lượng token không phụ thuộc hãng cụ thể
    storage_service.dart      # Lưu trữ local bằng Hive
    export/
      docx_export.dart        # Sinh file Word
      pptx_export.dart        # Sinh file PowerPoint
      xlsx_export.dart        # Sinh file Excel
      code_zip_export.dart    # Đóng gói source code AI sinh ra thành .zip
  providers/
    chat_provider.dart        # State management (Provider/ChangeNotifier)
  screens/
    chat/chat_screen.dart
    home/conversation_drawer.dart
    settings/provider_settings_screen.dart
    settings/provider_edit_screen.dart
  widgets/
    message_bubble.dart, chat_input_bar.dart, token_usage_bar.dart, export_menu.dart
```

## Bật "Thinking" (suy luận sâu) — giảm code rỗng chỉ có comment

Khi thêm/sửa Provider, có dropdown **"Thinking / Reasoning effort"**: Tắt /
Thấp / Trung bình / Cao. Đặt **Cao** khi yêu cầu model viết code — bắt model
lập luận kỹ (từng bước, kiểm tra logic) TRƯỚC khi xuất code, giảm hẳn tình
trạng trả về hàm rỗng chỉ có `// TODO` mà không có logic thật.

Cách áp dụng theo từng định dạng (xem `api_service.dart` hàm `_buildBody`):

- **Gemini (OpenAI-compatible)**: gửi field `reasoning_effort` thẳng trong
  body — Google tự map nội bộ sang `thinking_level`/`thinking_budget`. Chọn
  "Cao" tương đương `thinking_level: high`.
- **Anthropic-compatible**: quy đổi mức đã chọn sang `thinking.budget_tokens`
  (Thấp=2000, Trung bình=8000, Cao=16000 token suy luận).
- **OpenAI / Custom OpenAI-compatible**: gửi `reasoning_effort` (áp dụng cho
  các model dòng suy luận như o-series/gpt-5-reasoning).

Đánh đổi: bật Thinking khiến model trả lời **chậm hơn** và tốn thêm token
"suy nghĩ" (được tính vào completion tokens, hiện đúng trong màn hình Thống
kê token) — nên chỉ bật Cao cho các yêu cầu code/logic phức tạp, có thể để
mặc định hoặc Thấp cho chat thông thường để tiết kiệm.

## Thống kê token đã dùng / được cấp

Bấm icon 📊 trong Drawer để xem, theo từng Provider:

- **Số token THẬT** đã dùng hôm nay/tháng này — lấy trực tiếp từ trường
  `usage` mà chính API trả về sau mỗi lượt gọi (không phải ước lượng), gồm
  cả các lượt gọi ẩn để tự động tóm tắt.
- Nếu bạn tự khai báo "Hạn mức token/ngày" khi thêm Provider (ví dụ bạn biết
  free tier Gemini là bao nhiêu token/ngày), app sẽ vẽ thanh % đã dùng/được
  cấp và đổi màu cảnh báo khi gần hết. App KHÔNG tự biết hạn mức của từng
  hãng (vì nó thay đổi liên tục và khác nhau theo tài khoản/khu vực) — số
  liệu này do bạn tự nhập.
- Ngay khi có số token thật từ API, app dùng luôn số đó (thay vì ước lượng)
  để tính khi nào cần tự động tóm tắt ở lượt tiếp theo — chính xác hơn ước
  lượng ký tự/token thuần tuý.

## Chuyển đổi model giữa chừng đoạn chat (tiết kiệm token khi tiếp tục)

Bấm icon 🔁 trên thanh tiêu đề màn hình chat để chuyển sang provider/model
khác NGAY GIỮA đoạn hội thoại. Cơ chế (xem `context_manager.dart` hàm
`switchModel`):

- Chèn 1 "mốc" hiển thị cho người dùng biết điểm chuyển đổi — **không tốn
  token** (không gửi lên API).
- Nếu model mới có giới hạn ngữ cảnh ≥ model cũ: **tái sử dụng nguyên vẹn**
  bản tóm tắt + lịch sử đã có, không gọi thêm bất kỳ request tóm tắt nào.
- Nếu model mới có ngữ cảnh nhỏ hơn hẳn: chỉ nén thêm dựa trên bản tóm tắt
  đã có (rẻ hơn tóm tắt lại từ đầu), chứ không bao giờ gửi lại toàn bộ lịch
  sử gốc.

Nhờ vậy, lượt gửi đầu tiên cho model mới luôn ngang bằng hoặc rẻ hơn lượt
gửi cuối cùng cho model cũ.

## Tự động build APK qua GitHub (không cần build tay)

`lib/services/github_build_service.dart` cung cấp vòng lặp "đẩy code → build
→ đọc lỗi → tự sửa bằng AI → build lại" hoàn toàn qua GitHub REST API. Lưu ý
quan trọng:

- Việc biên dịch APK **thật sự chạy trên máy chủ GitHub Actions** (không
  thể chạy Gradle/Android SDK ngay trên điện thoại) — app chỉ điều phối qua
  HTTP, không phải "phép màu build trong khung chat".
- Cần: 1 GitHub Personal Access Token (quyền `repo` + `workflow`), 1 repo đã
  có sẵn workflow `.github/workflows/build_apk.yml` (project này đã có).
- Đây là service, chưa có màn hình UI đi kèm — bạn có thể yêu cầu mình làm
  tiếp màn hình "Auto-build" nếu muốn tích hợp trực tiếp vào app.

## Về tài liệu học thuật/kỹ thuật và bản vẽ kỹ thuật

Bộ xuất `.docx` hiện tại hỗ trợ heading, đoạn văn, bullet — đủ cho tài liệu
ngắn. Với tiểu luận/luận văn/tài liệu kỹ thuật cần bìa, mục lục tự động,
header/footer đánh số trang, đánh số chương theo chuẩn học thuật, cần nâng
cấp thêm — hãy yêu cầu mình làm tiếp phần này với format cụ thể bạn cần.

Với "bản vẽ kỹ thuật": AI có thể tạo **sơ đồ minh họa** (sơ đồ khối, sơ đồ
nguyên lý dạng vector) nhúng vào tài liệu, nhưng **không thay thế được bản
vẽ CAD chính xác** dùng để sản xuất/thi công thật (dung sai, tỷ lệ, tiêu
chuẩn kỹ thuật) — loại đó cần phần mềm CAD chuyên dụng và kỹ sư có chuyên
môn kiểm tra lại trước khi dùng vào thực tế.

## Lưu ý khi dùng tính năng xuất PPTX/XLSX

Để AI trả lời đúng định dạng mà bộ xuất file nhận diện được, bạn nên thêm
vào system prompt của đoạn chat (Cài đặt đoạn chat → System prompt), ví dụ:

- PPTX: yêu cầu AI trả lời theo dạng `# Tiêu đề slide`, các dòng `- ` là
  bullet, mỗi slide cách nhau bằng dòng `---`.
- XLSX: yêu cầu AI trả lời dạng bảng, các cột cách nhau bằng `|`.
- Source code project: yêu cầu AI luôn đặt tên file ngay trên dòng đầu mỗi
  code block, ví dụ: ` ```lib/main.dart ` rồi xuống dòng viết nội dung file.

## Giấy phép

Bạn toàn quyền sử dụng, chỉnh sửa, phát hành lại project này.
