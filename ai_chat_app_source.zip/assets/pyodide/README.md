# Thư mục này được CI tự tải, KHÔNG commit file nhị phân Pyodide vào git

`.github/workflows/build_apk.yml` (bước "Tải Pyodide...") tự động tải
`pyodide-core-<version>.tar.bz2` từ
https://github.com/pyodide/pyodide/releases và giải nén vào đây TRƯỚC khi
chạy `flutter pub get`/`flutter build apk`.

## Build cục bộ (không qua GitHub Actions)

Nếu build trên máy của bạn, tự tải thủ công (thay `314.0.2` bằng đúng version
ghi trong bước CI nếu đã cập nhật):

```bash
curl -fL -o /tmp/pyodide-core.tar.bz2 \
  https://github.com/pyodide/pyodide/releases/download/314.0.2/pyodide-core-314.0.2.tar.bz2
tar -xjf /tmp/pyodide-core.tar.bz2 -C /tmp
cp -r /tmp/pyodide/* assets/pyodide/
```

Sau đó thư mục này phải có ít nhất `pyodide.js` + file `.wasm` đi kèm (tên
chính xác tuỳ bản, ví dụ `pyodide.asm.wasm`) thì
`lib/services/python_sandbox_service.dart` mới hoạt động được — mở file
`.tar.bz2` ra xem danh sách nếu không chắc.

## Vì sao dùng bản "core" (không phải bản đầy đủ ~200MB)

Bản `pyodide-core` chỉ có runtime CPython/WASM + thư viện chuẩn — KHÔNG có
numpy/pandas/PIL... để giữ APK nhỏ. Vì sandbox cố tình KHÔNG có mạng (xem
`assets/sandbox/sandbox.html`), bất kỳ code Python nào cố `pyodide.loadPackage(...)`
để tải thêm gói từ CDN sẽ thất bại — đây là điều CHỦ ĐỘNG, không phải thiếu
sót. Prompt dạy AI (`lib/services/secretary_prompt_builder.dart`) đã ghi rõ
sandbox chỉ có thư viện chuẩn.
