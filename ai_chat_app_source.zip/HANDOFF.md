# HANDOFF: AI Chat App (Flutter) — Trạng thái & tiếp tục từ đây

> Đọc file này thay vì đọc lại hội thoại gốc. Mục tiêu: build app Android
> hoàn chỉnh từ source đã có, KHÔNG lặp lại các quyết định/lỗi bên dưới.

## 1. Mục tiêu sản phẩm (yêu cầu gốc của người dùng)

- Tên app: **AgentAiChat** (đổi từ "ai_chat_app" theo yêu cầu), icon riêng
  đã tạo (`assets/icon/app_icon.png`, tự sinh mọi size qua
  `flutter_launcher_icons` trên CI).
- App chat AI kiểu Claude/ChatGPT, gọi **API model bất kỳ do người dùng tự
  cấu hình** — **tuyệt đối không hardcode hãng/model nào**.
- Quản lý nhiều đoạn chat như app chat khác: folder, ghim, đổi tên, xóa.
- **Ưu tiên #1 xuyên suốt dự án: tối ưu token khi chat dài/phức tạp.**
- Xuất file từ câu trả lời AI: docx, pptx, xlsx, zip source code (để push
  GitHub build).
- Chuyển model giữa chừng 1 đoạn chat, tiếp tục mạch, **không đốt token**
  để "giải thích lại ngữ cảnh".
- **Thảo luận nhóm nhiều model**: chọn ≥2 provider cùng tham gia 1 đoạn
  chat, mỗi model lần lượt trả lời, thấy được ý kiến model nói trước (xem
  mục 4.8).
- (Đề xuất, chưa hoàn thiện) Tự động build APK qua GitHub Actions, tự đọc
  lỗi và tự sửa bằng AI.

## 2. Stack & lý do chọn

| Quyết định | Lý do |
|---|---|
| Flutter | 1 codebase → APK, CI build dễ nhất qua GitHub Actions |
| Hive (không phải sqflite) | NoSQL nhẹ, không cần server, đủ cho local storage |
| `provider` package | State management đơn giản, đủ dùng |
| `archive` package tự dựng XML | docx/pptx/xlsx đều là zip+XML — tự viết để tránh phụ thuộc thư viện Office nặng/trả phí |
| Hive adapters **viết tay**, KHÔNG dùng `build_runner` | Môi trường dev lúc viết code không có mạng để chạy codegen — đã viết `.g.dart` thủ công khớp 100% với model |

## 3. Kiến trúc thư mục (đã code xong, nằm trong `ai_chat_app_source.zip` đã gửi)

```
lib/
  models/         ChatMessage, Conversation, ChatFolder, ProviderConfig (+ .g.dart tay)
  services/
    api_service.dart        gọi API 3 định dạng: openaiCompatible / anthropicCompatible / custom
    context_manager.dart     LÕI tối ưu token (xem mục 4)
    token_estimator.dart     ước lượng token (không có tokenizer thật vì đa hãng)
    usage_service.dart       lưu token THẬT (từ field usage của API) theo ngày/provider
    storage_service.dart     Hive boxes
    github_build_service.dart  auto-build qua GitHub API (CHƯA có UI, xem mục 6)
    export/{docx,pptx,xlsx,code_zip}_export.dart
  providers/chat_provider.dart   ChangeNotifier trung tâm, nối tất cả service trên
  screens/  chat/ home/ settings/(provider_settings, provider_edit, usage_stats)
  widgets/  message_bubble, chat_input_bar, token_usage_bar, export_menu
```

## 4. Cơ chế tối ưu token (đã implement, ĐỪNG thiết kế lại từ đầu)

1. **Sliding window** 12 tin nhắn gần nhất giữ nguyên văn.
2. **Auto-summarize**: khi tổng token ước tính > 65% `maxContextTokens` của
   provider đang dùng → gọi chính model đó tóm tắt phần cũ, thay thế lịch sử
   gốc bằng bản tóm tắt (message có `isSummary=true`; message gốc đánh dấu
   `collapsedIntoSummary=true`, vẫn hiển thị UI nhưng không gửi API nữa).
3. **Incremental summary**: tóm tắt lần sau = tóm tắt cũ + tin mới, không
   tóm tắt lại từ đầu.
4. Safety margin 15% — không bao giờ build context sát giới hạn.
5. **Usage THẬT từ API** (`ApiUsage` parse từ field `usage` trong response,
   kể cả streaming qua `stream_options.include_usage`/Anthropic
   `message_delta`) ghi đè lên số ước lượng ngay khi có, để các quyết định
   sau chính xác hơn.
6. **Chuyển model giữa chừng** (`ContextManager.switchModel`): chèn 1
   message `isSystemNote=true` (không tính token, không gửi API) đánh dấu
   mốc chuyển; nếu model mới có `maxContextTokens` ≥ model cũ → **tái dùng
   nguyên bản tóm tắt cũ, KHÔNG gọi thêm request tóm tắt nào**; chỉ tóm tắt
   nén thêm khi model mới có ngữ cảnh nhỏ hơn hẳn.
7. **Thinking/reasoning_effort** (field `reasoningEffort` trên
   ProviderConfig): map sang `reasoning_effort` (OpenAI-compat/Gemini) hoặc
   `thinking.budget_tokens` (Anthropic: low=2000/medium=8000/high=16000).
   Bật cao hơn tốn thêm completion token — đánh đổi có chủ đích, không phải
   bug.
8. **Thảo luận nhóm nhiều model** (`Conversation.discussionProviderIds`,
   `ChatMessage.speakerProviderId/speakerName`, `ChatProvider.
   sendDiscussionMessage`): mỗi model trong danh sách lần lượt trả lời 1
   câu hỏi, context của model sau có prefix `[Tên model]: ` trên các tin
   nhắn assistant trước đó (xử lý trong `ContextManager.buildContext`) để
   nó hiểu đó là phát biểu của model KHÁC, không phải lượt trả lời cũ của
   chính nó. Token vẫn tối ưu riêng theo `maxContextTokens` của TỪNG model
   tham gia — không dùng chung 1 ngân sách.
9. **Override riêng theo từng đoạn chat** (`Conversation.
   reasoningEffortOverride`/`temperatureOverride`/`webSearchOverride`,
   `ChatProvider._effectiveProvider`/`setChatOverrides`, UI:
   `chat_quick_settings_sheet.dart`, icon ⚙️ trên chat_screen):
   Thinking/Temperature/System prompt/Web search giờ đổi được NGAY TRONG
   LÚC CHAT, riêng cho từng đoạn chat, không cần vào lại Cài đặt Provider —
   khắc phục hạn chế "cài đặt chết" mà người dùng phản ánh. `temperature`
   cũng đã có UI (slider) ở màn hình sửa Provider — trước đó field có
   trong model nhưng bị thiếu UI, đã bổ sung.
10. **Tìm kiếm web** (`ProviderConfig.webSearchEnabled`,
    `Conversation.webSearchOverride`, xử lý trong `api_service.dart
    _buildBody`): Anthropic dùng tool chính thức `web_search_20250305`
    (ổn định, có tài liệu). OpenAI-compatible/Custom gửi
    `web_search_options: {}` — CHỈ có tác dụng thật với model dòng search
    của OpenAI (gpt-4o-search-preview, gpt-5-search-api); với Gemini qua
    endpoint OpenAI-compat, tài liệu Google hiện KHÔNG xác nhận field
    tương đương cho chat/completions (chỉ thấy cho ảnh/video) — đã tra
    cứu kỹ, không đoán mò, ghi rõ mức độ tin cậy khác nhau theo từng
    provider trong cả README lẫn UI. Không phải scraping/browser — chỉ là
    bật đúng field API.
11. **Panel "File đã tạo"** (`models/generated_file.dart` typeId=7,
    `Conversation.generatedFiles`, `widgets/generated_files_panel.dart`,
    `widgets/export_runner.dart` — logic xuất file dùng chung, tách khỏi
    `export_menu.dart` để panel "xuất lại" gọi lại được y hệt): icon 📁 mở
    endDrawer liệt kê file đã xuất, có nút chia sẻ lại (regenerate từ
    `sourceMessageId`, KHÔNG lưu bytes lâu dài) và xoá khỏi danh sách.
12. **Liên kết đoạn chat** (`Conversation.linkedConversationIds` +
    `linkedContextCache`/`linkedContextCacheVersion`, `ContextManager.
    refreshLinkedContext`, UI: `widgets/link_conversations_sheet.dart`,
    icon 🔗): BẮT BUỘC theo yêu cầu người dùng — không phình token dù đoạn
    chat liên kết dài bao nhiêu. Cơ chế: tái dùng summary có sẵn của đoạn
    chat kia (0 request) → nếu ngắn thì lấy nguyên văn (0 request) → chỉ
    khi dài mà chưa từng tóm tắt mới gọi 1 request tóm tắt ≤100 từ → MỌI
    kết quả bị cắt cứng ≤600 ký tự trước khi cache → cache chỉ tính lại khi
    đoạn chat kia có thêm ≥5 tin nhắn mới (`linkedRefreshThreshold`). Nếu
    sửa lại cơ chế này, PHẢI giữ nguyên tinh thần "chặn trên cố định, không
    tỉ lệ thuận độ dài nguồn" — đây là yêu cầu tường minh của người dùng,
    không phải tối ưu tuỳ chọn.

## 5. Cấu hình API đã xác nhận hoạt động (điền trực tiếp, không cần đoán)

| Provider | Base URL | Format | Ghi chú |
|---|---|---|---|
| Gemini (free tier) | `https://generativelanguage.googleapis.com/v1beta/openai` | openaiCompatible | Giới hạn request/phút chặt ở free tier; dữ liệu free tier có thể bị dùng train trừ khi trả phí |
| DeepSeek chính thức | `https://api.deepseek.com` | openaiCompatible | model: `deepseek-chat` / `deepseek-reasoner`, rẻ |
| Anthropic | chuẩn `/v1/messages` | anthropicCompatible | cần `x-api-key` + header `anthropic-version` |

## 6. Việc CÒN DANG DỞ — làm tiếp từ đây, đúng thứ tự ưu tiên

1. ~~Tạo phần khung Android~~ — **ĐÃ SỬA**: workflow tự chạy
   `flutter create --platforms=android .` trên CI nếu chưa có `android/`.
2. ~~Auto-generate ghi đè code thật bằng app đếm số mẫu~~ — **ĐÃ SỬA**:
   thêm bước backup `lib/`+`pubspec.yaml` ra `/tmp` TRƯỚC khi chạy
   `flutter create`, rồi phục hồi đè lại NGAY SAU — đảm bảo APK build ra
   luôn từ code thật.
3. ~~`file_picker` gây lỗi build (đòi compileSdk 36, project auto-gen ở
   34)~~ — **ĐÃ SỬA**: xoá `file_picker` + `flutter_highlight` khỏi
   `pubspec.yaml` (cả 2 đều KHÔNG được dùng trong code, an toàn khi xoá).
4. ~~`flutter_launcher_icons` gây lỗi Gradle~~ — **ĐÃ SỬA** (build #15
   fail với lỗi `Could not find method kotlin()` trên project `:jni`, do
   dependency `jni` của package này đụng độ với cách Flutter mới build
   Kotlin/KGP): bỏ hẳn package `flutter_launcher_icons`. Thay bằng: tự
   generate sẵn 5 file PNG kích thước chuẩn (mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi)
   ngay trong `assets/icon/mipmap-*/ic_launcher.png` lúc soạn code (không
   sinh trên CI), workflow chỉ COPY file thẳng vào
   `android/app/src/main/res/mipmap-*/` + xoá `mipmap-anydpi-v26` (icon
   adaptive mặc định) — không thêm dependency Dart/Gradle nào nên không
   thể vỡ theo kiểu tương tự. Icon gốc (1024×1024) vẫn giữ ở
   `assets/icon/app_icon.png` để tái sinh size khác nếu cần (dùng PIL/
   ImageMagick, không phải Flutter).
5. ~~Build #16 vẫn ra lỗi `jni` y hệt build #15 dù đã xoá
   `flutter_launcher_icons`~~ — **ĐÃ SỬA**: nguyên nhân là bước tự giải nén
   dùng `cp -rn` (no-clobber) — nếu repo đã có sẵn `pubspec.yaml`/file cũ
   nằm thẳng ở gốc (ví dụ do từng làm theo hướng dẫn cũ "di chuyển file thủ
   công" ở các lượt build đầu tiên), file đó KHÔNG BAO GIỜ bị ghi đè dù zip
   mới có nội dung khác — build luôn dùng nhầm bản pubspec cũ. Đổi sang
   `cp -rf` (force overwrite, zip luôn thắng) + luôn `rm -rf android` trước
   khi `flutter create` lại (không còn kiểu "chỉ tạo nếu chưa có") + thêm
   `cat pubspec.yaml` vào cuối bước giải nén để LOG BUILD hiện rõ nội dung
   pubspec thực sự dùng — nếu lỗi tái diễn, đọc đoạn log này trước tiên
   thay vì đoán tiếp.
6. ~~Build #22 vẫn ra lỗi `jni` y hệt dù đã sửa mục (4) và (5)~~ — **ĐÃ TÌM
   ĐÚNG NGUYÊN NHÂN THẬT**: KHÔNG phải do `flutter_launcher_icons` (bỏ
   package đó ở mục 4 không sai nhưng không phải nguyên nhân chính, chỉ là
   phòng ngừa thêm). Thủ phạm thật là **`share_plus: ^9.0.0`** (bản rất cũ)
   — chính package này áp dụng Kotlin Gradle Plugin theo cách cũ, kéo theo
   dependency `jni` gây lỗi `Could not find method kotlin()`. Manh mối đã
   nằm sẵn trong MỌI log lỗi từ build #9 tới giờ (dòng "WARNING: ... plugins
   that apply Kotlin Gradle Plugin (KGP): share_plus") nhưng bị bỏ qua vì
   tưởng chỉ là warning không quan trọng — bài học: dòng WARNING chỉ đích
   danh tên package luôn đáng đọc kỹ trước khi đoán nguyên nhân khác.
   **ĐÃ SỬA**: nâng `share_plus` lên `^13.0.0` (bản cũ 9.0.0 → mới nhất tại
   thời điểm build #22 là 13.3.0, đã fix compileSdk/Gradle config theo
   chính changelog của package). API `Share.shareXFiles` dùng trong
   `file_saver.dart` vẫn hoạt động ở bản 13.x (deprecated nhưng chưa bị
   xoá) — KHÔNG cần sửa code, chỉ cần bump version trong `pubspec.yaml`.
7. **Trạng thái build hiện tại**: đã sửa xong lỗi (3), (4), (5) và (6),
   người dùng ĐANG chờ kết quả lần chạy tiếp theo sau khi thay file zip mới
   nhất — **CHƯA XÁC NHẬN build thành công**. Việc đầu tiên khi tiếp tục:
   hỏi/kiểm tra log Actions mới nhất trước khi sửa thêm bất cứ gì. Nếu vẫn
   lỗi `jni`/Gradle sau bản sửa này, nghi ngờ tiếp theo nên là các package
   Android khác chưa nâng cấp (`path_provider`, `hive_flutter`) — kiểm tra
   dòng WARNING nêu tên package trước, đừng đoán mò lại từ đầu.
8. **GithubBuildService chưa có màn hình UI** — code service đã xong
   (push file, trigger workflow, poll, đọc log lỗi, nhờ AI tự sửa, lặp tối
   đa N lần, tải artifact). Cần: 1 màn hình nhập PAT/owner/repo + nút chạy +
   hiển thị log tiến trình.
9. **Enhanced docx cho luận văn/tài liệu kỹ thuật** (bìa, mục lục thật,
   header/footer đánh số trang, đánh số chương) — ĐÃ HỨA nhưng CHƯA làm,
   chờ người dùng cho chuẩn định dạng cụ thể trước khi code.

## 7. Bối cảnh vận hành — QUAN TRỌNG, ảnh hưởng cách hỗ trợ tiếp theo

- **Người dùng CHỈ dùng điện thoại, KHÔNG có máy tính** — mọi hướng dẫn
  KHÔNG được yêu cầu chạy lệnh local (Termux là phương án cuối, không phải
  mặc định). Toàn bộ luồng phải làm được qua GitHub web mobile.
- **Luồng deploy hiện tại đã chốt** (đừng đề xuất lại cách khác trừ khi
  luồng này thất bại hẳn):
  1. Tạo file `.github/workflows/build_apk.yml` bằng **"Create new file"**
     trên GitHub mobile (gõ path đầy đủ, dán nội dung — không cần thư mục
     có sẵn).
  2. Upload **1 file `.zip` duy nhất** (không giải nén tay) bằng
     **"Upload files"** — mobile chỉ chọn được file lẻ, không chọn được cả
     cây thư mục, nên đây là cách duy nhất khả thi.
  3. Workflow tự tìm bất kỳ file `*.zip` nào ở gốc repo, tự giải nén, tự bóc
     lớp thư mục `ai_chat_app/` bên trong ra gốc.
  4. Vào Actions → Run workflow → tải APK ở Artifacts khi xong.
- Repo hiện tại của người dùng tên **AgentAIChat**, đã chạy build đến lần
  #9. Lịch sử lỗi đã qua: (a) chỉ upload zip không giải nén → lỗi thiếu
  `lib` → đã có bước tự giải nén; (b) `flutter create` đè code thật thành
  app đếm số mặc định → đã có backup/restore; (c) `file_picker` đòi
  compileSdk 36 → đã xoá dependency.
- Người dùng đã khá bực vì phải thử đi thử lại nhiều lần — **ưu tiên đưa
  giải pháp làm được ngay trên điện thoại, tránh hỏi lại các bước đã xác
  nhận, và xin log thật thay vì đoán khi có lỗi mới.**

## 8. Bẫy/lỗi kỹ thuật đã gặp — TRÁNH LẶP LẠI

- **Hive adapter viết tay**: mỗi lần thêm field mới vào model phải sửa
  ĐỒNG BỘ 2 chỗ — field trong class VÀ `writeByte(N)`/danh sách field đọc
  trong `.g.dart` tương ứng (N = tổng số field, đếm từ 0). Quên 1 trong 2
  chỗ → lỗi runtime hoặc mất dữ liệu khi đọc box cũ. TypeId đã dùng: 1–6
  (MessageRole, ChatMessage, ApiFormat, ProviderConfig, Conversation,
  ChatFolder) — model mới phải dùng `typeId` từ 7 trở lên.
- **Trường "thinking"/"reasoning" không bao giờ được lẫn vào nội dung hiển
  thị**: code parse response CHỈ đọc field `content`/`text`, cố tình bỏ qua
  `reasoning_content`/block type `thinking` — nếu sửa hàm
  `_extractDeltaText`/`_extractFullText` trong `api_service.dart`, phải giữ
  nguyên tính chọn lọc này, không gộp chung.
- **Anthropic format hiện hardcode `max_tokens: 4096`** trong
  `_buildBody` — nếu người dùng cần output dài hơn, đây là chỗ cần sửa
  thành field cấu hình được, chưa làm.
- **Không thể build APK ngay trong môi trường tạo code** (không có Android
  SDK/mạng) — đừng cố "tự build trực tiếp trong chat", luôn cần 1 trong 2:
  build tay bằng Flutter SDK, hoặc CI qua `.github/workflows/build_apk.yml`
  (đã có sẵn trong project) hoặc `GithubBuildService`.
- **Đã xoá `file_picker`, `flutter_highlight`** khỏi `pubspec.yaml` (không
  dùng trong code + `file_picker` gây lỗi compileSdk) — ĐỪNG thêm lại
  `file_picker` mà không đồng thời set `compileSdk`/`targetSdk` phù hợp
  trong `android/app/build.gradle.kts` sau khi `flutter create` sinh ra.
- **`flutter create` có thể ghi đè `lib/`+`pubspec.yaml` bằng app mẫu** nếu
  không backup/restore trước — xem cơ chế đã vá ở mục 6.2, đừng bỏ 2 bước
  đó nếu sửa lại workflow.

- **Đã đổi `name:` trong `pubspec.yaml` từ `ai_chat_app` → `agent_ai_chat`**
  (Dart package name, snake_case) — đã đồng bộ với `--project-name
  agent_ai_chat` trong CI. Nếu sửa 1 trong 2 chỗ mà quên chỗ kia, project
  name lệch nhau có thể gây lỗi khi `flutter create` sinh `android/`. Toàn
  bộ code trong `lib/` dùng import tương đối (không dùng `package:
  agent_ai_chat/...`) nên đổi tên này KHÔNG ảnh hưởng gì tới import — an
  toàn để đổi tiếp nếu cần.
- **Icon** sinh bằng `flutter_launcher_icons` đọc từ
  `assets/icon/app_icon.png` — nếu đổi icon, chỉ cần thay file PNG này
  (giữ tỉ lệ vuông, khuyến nghị ≥512×512), không cần sửa gì khác.

## 9. File đã gửi cho người dùng

`ai_chat_app_source.zip` — toàn bộ `lib/` + `pubspec.yaml` (đã xoá
file_picker/flutter_highlight) + README + `.github/workflows/build_apk.yml`
(đã có đủ: tự giải nén zip, backup/restore code thật, tự sinh `android/`,
tự thêm quyền Internet). CHƯA có `android/`, `ios/` thật trong zip — do CI
tự sinh lúc build, KHÔNG cần thêm vào zip.

## 10. Cập nhật 29/07/2026 — Thư ký AI + Tài liệu nguồn + Sửa source code zip

**Bối cảnh:** người dùng cần (a) đăng nhập vào hệ thống web công ty ngay
trong app để lấy nội dung thay vì tự copy/export thủ công, (b) tổng hợp
nhiều tài liệu thành docx/pptx/xlsx theo yêu cầu, (c) upload 1 zip source
code bất kỳ để AI sửa và trả lại zip hoàn chỉnh — và MUỐN TIẾT KIỆM TOKEN
(không gọi API cho bước không cần thiết).

**KHÔNG làm** (và tại sao): tự động đăng nhập + đọc tin nhắn riêng tư của
người khác từ Facebook/Zalo/Messenger. Các nền tảng này chủ động chặn việc
đọc nội dung qua WebView (CSP, phát hiện script lạ) và việc này có thể làm
khoá tài khoản thật của người dùng; hơn nữa tin nhắn liên quan đến người
khác vẫn cần họ đồng ý mới nên tự động hoá trích xuất/lưu trữ ngoài ý muốn
của họ. Nếu người dùng thật sự cần dữ liệu Facebook/Zalo, hướng dẫn dùng
tính năng "Tải xuống thông tin của bạn" chính chủ của nền tảng đó, rồi
upload file kết quả vào mục 10.2 bên dưới.

### 10.1. lib/screens/sources/webview_capture_screen.dart (MỚI)
Trình duyệt nhúng (webview_flutter) để đăng nhập BẤT KỲ hệ thống web nào
(web nội bộ công ty, ...) bằng chính phiên đăng nhập thật của người dùng.
Nút "Trích xuất nội dung trang" chạy document.body.innerText — thuần JS,
KHÔNG gọi API model, không tốn token ở bước này.

### 10.2. lib/models/source_document.dart (+ .g.dart, typeId 8, MỚI)
Lưu tài liệu nguồn (origin = 'upload' | 'webview') vào box Hive mới
source_documents (đăng ký trong storage_service.dart).

### 10.3. lib/screens/sources/source_documents_screen.dart (MỚI)
Danh sách tài liệu nguồn, upload file (txt/md/csv/json/...), mở webview
capture, chọn nhiều tài liệu, bottom sheet nhập yêu cầu + chọn định dạng,
gọi ChatProvider.compileSources (secretary_prompt_builder.dart dựng prompt)
- ĐÚNG 1 LẦN GỌI API (sendMessageOnce, không streaming) cho toàn bộ việc
tổng hợp, bất kể có bao nhiêu tài liệu nguồn. Kết quả được thêm vào đoạn
chat như 1 cặp tin nhắn user/assistant bình thường (minh bạch token đã
dùng) rồi tái dùng ExportRunner có sẵn để xuất docx/pptx/xlsx.

### 10.4. lib/screens/code/zip_edit_screen.dart (MỚI)
Upload 1 file .zip bất kỳ, giải nén bằng ZipDecoder (đã có sẵn qua archive),
lọc file text (bỏ qua file nhị phân), người dùng tick chọn file cần AI xem,
1 LẦN GỌI API yêu cầu AI CHỈ trả về các file thay đổi/thêm mới theo đúng cú
pháp CodeZipExporter đã hỗ trợ, merge với file gốc không đổi, xuất zip hoàn
chỉnh bằng CodeZipExporter.export (tái dùng, không viết exporter mới).

### 10.5. Đã THÊM LẠI file_picker (khác lần trước!)
Lần này có kèm bước ép compileSdk/targetSdk = 36 trong
.github/workflows/build_apk.yml (bước "Ép compileSdk/targetSdk = 36" ngay
sau khi sinh android/) - đúng điều kiện mà mục 8 ở trên yêu cầu. Nếu build
CI vẫn lỗi liên quan compileSdk/AGP/Kotlin, kiểm tra log ở đúng bước này
trước - có thể cần đổi số 36 sang version SDK khác tuỳ bản file_picker/
Flutter tại thời điểm build (không kiểm chứng được bằng cách build thật
trong môi trường tạo code, vì môi trường đó không có mạng/Android SDK).

### 10.6. CHƯA làm (còn nợ, người dùng chưa xác nhận ưu tiên)
"Chat nhóm nội bộ" nhiều người dùng thật cùng vào 1 đoạn chat trong chính
app (không phải nhiều AI model thảo luận - cái đó đã có qua
discussionProviderIds) - cần thêm 1 lớp đồng bộ dữ liệu giữa các thiết bị
(hiện app 100% local Hive, không có backend), nên đây là thay đổi kiến trúc
lớn, chưa làm vội để tránh phá vỡ nguyên tắc "không cần backend" của app.

## 11. Cập nhật 29/07/2026 (bổ sung) — Tải file thật qua link download trong WebView

Bổ sung cho mục 10.1: trước đây `webview_capture_screen.dart` chỉ trích
xuất được TEXT hiển thị trên trang (`document.body.innerText`) — không lấy
được nếu code/tài liệu nằm trong 1 FILE THẬT (zip/docx/pdf...) mà trang chỉ
cho bấm link tải xuống, vì WebView (giống Chrome/Safari) không tự tải file
đính kèm.

**Đã thêm:** `onNavigationRequest` chặn các URL có đuôi file
(zip/rar/7z/docx/pdf/xlsx/pptx/csv/...) trước khi WebView load, rồi tự tải
bằng `http` GET kèm cookie phiên đăng nhập THẬT lấy qua package
`webview_cookie_manager` (đọc CookieManager gốc của Android/iOS — khác
`document.cookie` trong JS vì đọc được cả cookie đánh dấu HttpOnly, mà
cookie session/đăng nhập thường bị đánh dấu HttpOnly vì lý do bảo mật).

- Nếu file tải về là `.zip` → tự động mở luôn màn `ZipEditScreen` (đã sửa
  để nhận `initialBytes`/`initialName`), không cần chọn lại file lần 2.
- Nếu là `.txt/.md/.csv/.json/.html/.xml/.log` → lưu thẳng thành
  `SourceDocument` (giống upload file thường).
- Nếu là `.docx/.pdf/.xlsx/.pptx/.doc/.ppt/.xls` → ĐÃ TẢI ĐƯỢC FILE nhưng
  CHƯA đọc được nội dung text bên trong (đây là định dạng nhị phân có cấu
  trúc riêng, cần parser riêng cho từng loại — chưa làm, báo nếu cần).

**CHƯA kiểm chứng được bằng build thật** (môi trường tạo code không có
mạng/Android SDK) — 2 điểm rủi ro cao nhất cần xem log CI đầu tiên nếu lỗi:
1. API chính xác của `webview_cookie_manager` (`getCookies(url)` trả về
   `List<Cookie>` từ `dart:io`) có thể lệch nhẹ theo version — nếu lỗi biên
   dịch ở đây, kiểm tra README của package trên pub.dev đúng version đã ghim
   trong `pubspec.yaml`.
2. `onNavigationRequest` trả `NavigationDecision` đồng bộ (không `Future`) —
   nếu SDK version yêu cầu `FutureOr<NavigationDecision>`, có thể cần bọc
   `async` (không đổi tôi hành vi vì `_downloadFile` tự chạy async bên trong,
   không cần `await` trước khi return `NavigationDecision.prevent`).

## 12. FIX build lỗi #28 (29/07/2026) — sai version webview_cookie_manager

**Lỗi thật đã xảy ra:** `webview_cookie_manager ^3.0.1 doesn't match any versions`
- Nguyên nhân: tôi ghim version `^3.0.1` cho package này mà KHÔNG kiểm chứng
  được (môi trường code không có mạng để tra pub.dev), và con số đó sai —
  package không có bản 3.x.

**Đã sửa:** đổi 3 dependency mới thêm (mục 10-11) từ ghim đúng patch version
sang RANGE rộng hơn, để `pub get` tự chọn bản thực sự tồn tại thay vì lỗi
version-solving nếu tôi đoán sai số:
- `webview_cookie_manager: ">=1.0.0 <4.0.0"`
- `webview_flutter: ">=4.7.0 <5.0.0"`
- `file_picker: ">=8.0.0 <10.0.0"`

Nếu build vẫn báo lỗi version-solving ở 1 trong 3 dòng này, nghĩa là ngay
cả range trên cũng không khớp bản thật đang có trên pub.dev tại thời điểm
build — mở log, đọc chính xác thông báo "version solving failed" (nó luôn
liệt kê constraint đang xung đột), rồi báo lại cho tôi đúng tên package +
thông báo lỗi để tôi sửa đúng con số.

## 13. FIX build lỗi #31 (29/07/2026) — xung đột win32 giữa file_picker và share_plus

**Lỗi thật:** không phải sai version, mà là XUNG ĐỘT PHỤ THUỘC BẮC CẦU:
- `file_picker` bản < 8.3.3 cần `win32 ^5.x`
- `share_plus` (đã dùng sẵn trong app từ trước, cho tính năng chia sẻ file
  xuất ra) bản ^13.0.0 cần `win32 ^6.x`
- Range tôi ghim trước đó (`<10.0.0`) vô tình chặn mất các bản file_picker
  đủ mới (8.3.3+, có cả bản 12.x) — mà log build đã chỉ đích danh các bản
  đó mới dùng `win32 ^6.x` tương thích với `share_plus`.

**Đã sửa:** `file_picker: ">=8.3.3"` — bỏ hẳn trần trên, để pub tự chọn bản
mới nhất tương thích thay vì tôi đoán số trần rồi lại chặn nhầm bản cần
dùng. Không đụng vào `share_plus` vì đây là dependency ĐÃ CÓ SẴN, đang được
dùng cho tính năng chia sẻ file khác trong app — hạ nó xuống có thể phá
tính năng cũ.

**Bài học chung cho các lần build sau:** khi thêm 1 package mới, rủi ro lớn
nhất không phải version của chính nó, mà là xung đột phụ thuộc bắc cầu (như
win32 ở đây) với package ĐÃ CÓ SẴN trong app. Cách xử lý đúng: đọc kỹ dòng
"Because ... requires ... And because ... requires ..." trong log — pub
luôn liệt kê chuỗi suy luận đầy đủ, chỉ cần nới đúng trần constraint đang
chặn nhầm, không cần hạ dependency cũ.

## 14. FIX build lỗi #34 (29/07/2026) — plugin cũ thiếu namespace (AGP 8+)

**Lỗi thật:** `webview_cookie_manager-2.0.6` (nằm trong pub-cache) không khai
báo `namespace` trong `android/build.gradle` — bắt buộc từ Android Gradle
Plugin 8+, còn plugin này viết từ trước khi có yêu cầu đó. Rất phổ biến với
plugin lâu không cập nhật, không phải lỗi trong code app.

**Đã sửa:** thêm bước "Vá namespace cho plugin Android cũ chưa khai báo"
trong `.github/workflows/build_apk.yml`, chạy NGAY SAU `flutter pub get`
(để package đã có trong pub-cache) và TRƯỚC `flutter build apk`. Bước này
**tự động, không hardcode tên plugin** — dò mọi thư mục `android/` trong
pub-cache, nếu thiếu `namespace` thì lấy `package="..."` từ chính
`AndroidManifest.xml` cũ của plugin đó và khai báo lại thành `namespace`
trong `build.gradle`/`build.gradle.kts` — nên nếu sau này thêm plugin KHÁC
bị lỗi y hệt, cũng tự vá được, không cần sửa workflow lần nữa.

**Nếu build vẫn lỗi liên quan namespace ở đúng bước này:** khả năng cao là
plugin đó không có `AndroidManifest.xml` với `package="..."` (một số dùng
cấu trúc project khác) — cần xem log để biết chính xác path rồi vá tay
riêng cho plugin đó.

## 15. FIX build lỗi #37 (29/07/2026) — bỏ hẳn webview_cookie_manager, tự viết MethodChannel

**Xác nhận:** bước "vá namespace" ở mục 14 KHÔNG giải quyết được (log #37
giống hệt #34) — `webview_cookie_manager` là package bỏ hoang, rủi ro tiếp
tục gây lỗi Gradle khác nếu cứ vá tiếp.

**Đã sửa tận gốc:** BỎ HẲN dependency `webview_cookie_manager` khỏi
`pubspec.yaml`. Thay bằng 1 MethodChannel (`agent_ai_chat/cookies`) tự viết
thẳng vào `MainActivity.kt` — gọi `android.webkit.CookieManager` có sẵn
trong Android SDK, KHÔNG cần thêm bất kỳ dependency Gradle nào nữa nên
KHÔNG THỂ tái diễn lỗi kiểu "namespace/AGP" này được nữa.

Vì `android/` luôn bị `flutter create` sinh lại từ đầu mỗi lần build (xem
mục thiết kế gốc), `MainActivity.kt` cũng bị ghi đè mỗi lần — nên bước mới
"Thêm MethodChannel lấy cookie WebView vào MainActivity.kt" trong
`build_apk.yml` sẽ TỰ GHI LẠI file này sau khi `flutter create` chạy xong,
mỗi lần build, không cần lưu file android riêng trong repo.

**Lưu ý kỹ thuật quan trọng đã tự kiểm chứng được (không cần đoán):** lúc
đầu tôi định dùng `python3 -c "<code nhiều dòng>"` để sinh nội dung
`MainActivity.kt`, nhưng gặp đúng 2 lỗi liên tiếp khi tự mô phỏng chạy thử
(không cần chờ CI thật):
1. Heredoc (`<< EOF`) lồng trong khối YAML `run: |` bị thụt lề → dòng kết
   thúc heredoc dính khoảng trắng → bash không nhận diện được delimiter →
   script vỡ. (Nguyên nhân gốc của việc bước vá ở mục 14 không chạy đúng.)
2. Đổi sang `python3 -c` nhiều dòng thì lại dính `IndentationError` vì
   Python bắt buộc dòng đầu ở cột 0, xung đột với yêu cầu thụt lề tối thiểu
   của YAML block scalar.

**Giải pháp cuối cùng — dùng chuỗi lệnh `echo` bash** (không phải heredoc,
không phải python) — bash hoàn toàn không quan tâm khoảng trắng thụt lề
trước mỗi lệnh, nên tương thích 100% với yêu cầu thụt lề của YAML. Đã tự
trích xuất chính xác script từ YAML bằng PyYAML và CHẠY THỬ THẬT trên 1
`MainActivity.kt` giả lập — xác nhận sinh ra đúng nội dung Kotlin mong
muốn, và `bash -n` xác nhận toàn bộ 12 bước script trong file đều hợp lệ cú
pháp — trước khi gửi bản này, chứ không chỉ đoán.

**Điều duy nhất CHƯA kiểm chứng được** (vì không có Android SDK/Gradle
thật trong môi trường code): bản thân đoạn Kotlin có compile được với
`FlutterActivity`/`FlutterEngine`/`MethodChannel` API đúng hay không —
đây là API rất ổn định, ít thay đổi qua các bản Flutter, nên rủi ro thấp
hơn hẳn so với dùng package ngoài, nhưng nếu build vẫn lỗi ở bước Gradle
liên quan `MainActivity.kt`, gửi log để tôi xem chính xác.

## 16. Cập nhật 29/07/2026 — Dán nội dung vào ô đang chọn (thay cho "auto detect + auto gửi")

**Yêu cầu gốc:** JS tự học/heuristic dò input box + send button trên BẤT KỲ
trang nào (bình luận blog, chat, diễn đàn...), dán code vào, không hardcode
selector.

**Đã làm khác đi có chủ đích** (đã hỏi lại người dùng trước khi làm): thay
vì "dò input box + send button rồi TỰ BẤM GỬI" (rủi ro cao — nếu là ô chat
người thật hoặc form đăng công khai, tool tự gửi thay nghĩa là nội dung đi
luôn mà không ai kịp xem lại, và có thể bị nền tảng coi là hành vi bot), đã
dùng `document.activeElement` (phần tử người dùng ĐANG bấm/focus) để xác
định "ô nào" — không cần dò/hardcode selector, tổng quát với mọi trang —
NHƯNG dừng lại sau khi dán, KHÔNG tự bấm Gửi/Đăng. Người dùng luôn tự xem
lại và bấm gửi bằng tay.

### `lib/screens/sources/webview_capture_screen.dart` (cập nhật)
- Nút "Dán nội dung" (icon paste) trên AppBar → mở bottom sheet chọn 1 Tài
  liệu nguồn có sẵn HOẶC gõ văn bản tuỳ ý → `_pasteIntoFocusedElement`
  chạy JS dán vào `document.activeElement`.
- Dùng NATIVE SETTER qua `Object.getOwnPropertyDescriptor` (không gán
  `el.value = ...` trực tiếp) rồi bắn sự kiện `input`/`change` — cần thiết
  vì các trang viết bằng React/Vue (rất phổ biến cho chat/comment hiện đại)
  ghi đè setter mặc định để tự quản lý state nội bộ; gán trực tiếp sẽ không
  được framework nhận diện là có thay đổi.
- Hỗ trợ cả `<textarea>`/`<input>` VÀ phần tử `contenteditable` (nhiều ô
  chat hiện đại như Messenger/Slack web dùng div contenteditable thay vì
  textarea thật).

**CHƯA làm** (và sẽ không làm trừ khi người dùng xác nhận rõ ràng và hiểu
rủi ro): tự động dò "send button" rồi tự bấm — nếu người dùng sau này thật
sự cần tự động gửi hàng loạt (ví dụ auto-reply), đây là mức rủi ro cao hơn
hẳn (auto-posting/spam khả năng cao), cần cân nhắc riêng, không nên bật mặc
định.

## 17. Cập nhật 29/07/2026 — Hoàn thiện luồng "upload zip → bên kia sửa → tải zip đã sửa"

Trả lời câu hỏi: bottom sheet "Dán nội dung" (mục 16) giờ CHỌN ĐƯỢC file
.zip trực tiếp, và luồng ngược lại (nhận bản đã sửa, tải zip) đã có đủ 2
cách.

### 17.1. `lib/services/export/code_zip_export.dart` — thêm `formatForSharing`
Ghép nhiều file thành 1 chuỗi text theo ĐÚNG cú pháp
```đường/dẫn/file.ext ... ``` mà `extractFiles` đọc lại được — vòng lặp
tròn: format ra → gửi cho bên ngoài → nhận lại → extractFiles → export zip.

### 17.2. `lib/screens/sources/webview_capture_screen.dart` — bottom sheet dán nội dung
Thêm nút "Chọn file .zip (source code)" — đọc toàn bộ file text trong zip,
ghép bằng `formatForSharing`, rồi dán vào ô đang chọn trên trang (dùng
`document.activeElement`, không tự bấm gửi — xem mục 16).

### 17.3. `lib/screens/code/zip_edit_screen.dart` — thêm "Cách 2"
Trước đây chỉ có 1 cách (AI trong app tự sửa, tốn 1 lần API). Giờ có thêm
"Cách 2 — đã có bản sửa từ nơi khác (0 token)": nút "Copy X file đã chọn"
(copy ra clipboard theo cú pháp chuẩn để gửi cho AI khác/người khác), và ô
"Dán kết quả đã sửa" + nút "Ghép & tải zip (không gọi AI)" — parse trực
tiếp bằng `CodeZipExporter.extractFiles` rồi merge + xuất zip, HOÀN TOÀN
KHÔNG gọi `sendMessageOnce` — đúng yêu cầu "bên kia chỉnh sửa, app chỉ tải
lại zip đã sửa", không tốn token của chính app cho bước này.

**Luồng đầy đủ giờ đã khép kín:**
1. `ZipEditScreen`: upload zip, tick file, bấm "Copy X file đã chọn".
2. Mở `WebviewCaptureScreen`, vào trang AI khác/chat người khác, bấm/chạm
   vào ô nhập, bấm 📋 "Dán nội dung" (hoặc dán trực tiếp bằng clipboard hệ
   thống) → tự bấm Gửi.
3. Chờ bên kia trả lời → bấm "Trích xuất nội dung trang" để lưu câu trả
   lời thành Tài liệu nguồn (hoặc copy tay).
4. Quay lại `ZipEditScreen` → dán câu trả lời vào ô "Cách 2" → "Ghép & tải
   zip (không gọi AI)".

Giao diện `ZipEditScreen` đã bọc lại trong `SingleChildScrollView` (danh
sách file giới hạn cao 220px cuộn riêng) để tránh tràn màn hình khi có
thêm nhiều control mới trên máy nhỏ.

## 18. KHÔNG làm (29/07/2026) — network interception / proxy-VPN / giả lập clipboard

Người dùng đề xuất tích hợp thêm: (1) patch `window.fetch`/`XMLHttpRequest`
để đọc request/response ngầm, (2) giả lập sự kiện Ctrl+C để tự copy nội
dung vào clipboard, (3) `shouldInterceptRequest` (WebViewClient) bắt toàn
bộ request native, (4) proxy/VPN local bắt toàn bộ traffic thiết bị — làm
fallback khi JS trích xuất DOM "không ăn thua" với web React.

**KHÔNG làm cả 4 cái này.** Lý do cốt lõi: khác với những gì đã build
(trích xuất DOM hiển thị, dán vào ô đang focus, tải file qua link — đều chỉ
lấy ĐÚNG CÁI người dùng đang nhìn thấy, TẠI ĐÚNG LÚC họ chủ động bấm), cả 4
cơ chế trên đều chạy NGẦM và bắt được NHIỀU HƠN những gì hiển thị trên màn
hình — kể cả dữ liệu người khác (ví dụ 1 trang chat nhóm tải ngầm dữ liệu
của người khác trong nhóm dù chưa hiển thị). Proxy/VPN local đặc biệt là
đúng hạ tầng nền tảng của spyware/stalkerware bất kể mục đích ban đầu, và
không thể giới hạn phạm vi chỉ "đọc code" mà không đồng thời đọc được mọi
traffic khác của thiết bị (mật khẩu, ngân hàng, tin nhắn riêng...).

**Lý do kỹ thuật "React DOM hay đổi" không thực sự đúng:** đã giải thích
cho người dùng — `document.body.innerText` đọc DOM ĐÃ RENDER cuối cùng,
không quan tâm framework nào tạo ra (React/Vue đều ra HTML thật cuối cùng).
Vấn đề thật có thể gặp là TIMING (bấm trích xuất khi trang đang stream dở),
không phải do React.

**Đã làm thay vào đó (vẫn chỉ đọc DOM hiển thị, không đụng network):**
`_extractAndSave` trong `webview_capture_screen.dart` giờ tự đọc lại DOM
tối đa 5 lần (mỗi 500ms), nếu nội dung NGỪNG THAY ĐỔI giữa 2 lần đọc liên
tiếp (dấu hiệu trang đã stream/render xong) thì dừng sớm và dùng bản đó;
nếu sau ~2.5s vẫn còn đổi thì dùng bản cuối cùng. Xử lý đúng ca dùng thật
(bấm trích xuất khi AI web đang gõ dở câu trả lời) mà không cần bất kỳ cơ
chế can thiệp mạng nào.

## 19. Cập nhật 29/07/2026 — OCR cho trang canvas + phản hồi về network interception

**Phản hồi lại 2 điểm người dùng nêu:**

1. *"Mật khẩu/dữ liệu khác là của mình, dữ liệu người khác đâu có trên máy
   mình"* — công nhận 1 phần: patch fetch/XHR chỉ trong 1 tab thì đúng là
   không đụng traffic của app khác. Nhưng nêu rõ 1 điểm KỸ THUẬT cụ thể
   (không phải nguyên tắc chung): request/response NGẦM của 1 trang (ví dụ
   trang chat nhóm) thường tải về nguyên object thông tin TẤT CẢ thành viên
   nhóm (tên/id/avatar/trạng thái) để hiển thị, dù màn hình chỉ render vài
   dòng — patch fetch/XHR bắt được nguyên object đó, DOM-extract thì không.
   Đây là lý do KHÔNG làm fetch/XHR patch, không phải vì nguyên tắc mơ hồ.
   Riêng PROXY/VPN LOCAL thì khác hẳn về kiến trúc: `VPNService` trên
   Android THEO THIẾT KẾ là toàn hệ thống, không thể giới hạn chỉ 1 tab —
   đây là lý do kỹ thuật cứng, không phải lựa chọn của tôi.

2. *"Trang dùng canvas thì bó tay"* — ĐÚNG, đây là giới hạn thật của
   `document.body.innerText` (canvas chỉ là pixel, không có text node).

**Đã thêm để giải quyết điểm 2** (không cần network interception):
`lib/screens/sources/webview_capture_screen.dart` — nút OCR (icon máy quét)
trên AppBar:
- Bọc `WebViewWidget` trong `RepaintBoundary` (key `_webviewKey`).
- Chụp ảnh đúng khung hình đang hiển thị (`boundary.toImage()`) — bao gồm
  cả nội dung vẽ bằng canvas/WebGL, vì đây là ảnh chụp pixel thật, không
  phải đọc DOM.
- Chạy `google_mlkit_text_recognition` (`TextRecognizer`) để nhận diện chữ
  trong ảnh — **xử lý HOÀN TOÀN TRÊN MÁY, không upload ảnh lên server nào**.
  Lưu ý nhỏ (để chính xác, không phóng đại): lần ĐẦU TIÊN dùng, Google Play
  Services có thể cần tải xuống 1 lần bộ model nhận diện chữ (vài MB) —
  BẢN THÂN ẢNH CHỤP thì không rời khỏi máy, chỉ có bước tải model dùng
  mạng, không phải gửi dữ liệu.
- Lưu kết quả thành `SourceDocument` như bình thường, kèm cảnh báo "OCR có
  thể nhận nhầm ký tự, xem lại trước khi dùng" vì OCR không chính xác 100%.

**Dependency mới, RỦI RO BUILD chưa kiểm chứng được** (như các lần trước,
môi trường code không có mạng): `google_mlkit_text_recognition` — thêm
`path_provider` (đã có sẵn), `path` không cần thêm. Nếu build lỗi, khả năng
cao nhất là (a) version không khớp (đã để range rộng
`">=0.13.0 <1.0.0"` để giảm rủi ro), hoặc (b) thiếu cấu hình
Google Play Services / minSdkVersion — gửi log để xử lý tiếp, đây LÀ MỘT
package phổ biến, ổn định hơn `webview_cookie_manager` (đội ngũ
`flutter-mlkit` maintain tích cực), nhưng vẫn cần build thật để xác nhận.

## 20. Cập nhật 29/07/2026 — Giải quyết 4/5 giới hạn đã liệt kê ở mục 19

Người dùng yêu cầu giải quyết luôn 5 giới hạn đã nêu. Kết quả:

### #1 — Trang chặn WebView (SSO/2FA) — CHỈ giải quyết 1 PHẦN
Thêm `setUserAgent(...)` giả 1 chuỗi Chrome mobile chuẩn trong `initState`
của `webview_capture_screen.dart`. Việc này giúp được với hệ thống NỘI BỘ
đơn giản chỉ kiểm tra UA có phải "trình duyệt hiện đại" hay không.
**CỐ Ý KHÔNG nhắm tới việc lách qua chặn OAuth WebView có chủ đích của
Google/Meta** — đó là biện pháp chống lừa đảo bảo vệ chính người dùng
(chống app giả mạo/keylogger đội lốt màn hình đăng nhập), không nằm trong
phạm vi hỗ trợ. Nếu gặp, cách duy nhất đáng tin cậy vẫn là đăng nhập bằng
trình duyệt thật ngoài app trước.

### #2 — Infinite scroll — ĐÃ GIẢI QUYẾT
Hàm `_extractInfiniteScroll` (nút icon mũi tên tròn trên AppBar): tự cuộn
`window.scrollBy` nhiều lần (tối đa 30, dừng sớm nếu `scrollHeight` không
tăng thêm 2 lần liên tiếp), đọc lại DOM sau mỗi lần cuộn, gộp các DÒNG mới
xuất hiện vào `LinkedHashSet` (giữ thứ tự, tự loại trùng). Vẫn chỉ đọc DOM
hiển thị tại mỗi bước.

### #3 — File tải qua `blob:` URL — ĐÃ GIẢI QUYẾT
- Tiêm script ghi đè `URL.createObjectURL` ngay sau mỗi lần trang load xong
  (`onPageFinished`) để "nhớ" lại đối tượng `Blob` gốc ứng với mỗi blob URL
  trang tự sinh ra.
- `onNavigationRequest` bắt link bắt đầu bằng `blob:` → gọi
  `_downloadBlobFile` → đọc lại Blob qua `FileReader.readAsDataURL`, nhận
  base64 qua `JavaScriptChannel` tên `BlobChannel` (dùng `Completer` để chờ
  kết quả bất đồng bộ, timeout 15s).
- Nếu bytes có chữ ký `PK\x03\x04` (zip thật) → mở luôn `ZipEditScreen`.
  Không nhận diện được → lưu vào thư mục Documents của app rồi báo đường
  dẫn.
- Đây vẫn là dữ liệu DO CHÍNH HÀNH ĐỘNG người dùng (bấm nút tải trên trang)
  sinh ra, không phải bắt traffic ngầm.

### #4 — OCR đa ngôn ngữ — ĐÃ GIẢI QUYẾT
Nút OCR trên AppBar đổi thành `PopupMenuButton` chọn
`TextRecognitionScript`: Latin (mặc định, đọc tốt tiếng Việt có dấu),
Trung, Nhật, Hàn, Devanagari (Ấn Độ) — chọn xong chạy OCR luôn với ngôn ngữ
đó.

### #5 — OCR không chính xác 100% — KHÔNG THỂ GIẢI QUYẾT TRIỆT ĐỂ
Giới hạn cố hữu của mọi công nghệ OCR (font quá cách điệu, chữ quá nhỏ,
tương phản thấp). Đã có cảnh báo "xem lại trước khi dùng" trong snackbar
kết quả OCR (mục 19) — không thể làm gì thêm ngoài việc đó.

**Dependency KHÔNG có thêm** — chỉ dùng lại `path_provider` (đã có),
`dart:async`/`dart:collection` (built-in), không tăng thêm rủi ro build so
với mục 19.

**Điểm chưa kiểm chứng được (như thường lệ, không có Android SDK để build
thật):** tên enum `TextRecognitionScript.devanagiri` — package
`google_mlkit_text_recognition` có 1 lỗi chính tả nổi tiếng trong tên enum
này (viết "devanagiri" thay vì "devanagari" đúng chính tả tiếng Phạn), tôi
nhớ là vậy nhưng không có mạng để tra lại chắc chắn — nếu build lỗi đúng
dòng này, đổi thử sang `devanagari` (không có "i" cuối "gi").

## 21. Cập nhật 29/07/2026 — Đọc chữ canvas CHÍNH XÁC (thay thế OCR khi áp dụng được)

Trả lời: "còn cách nào giải quyết ngoài OCR" cho vấn đề #5 (OCR không chính
xác 100%) — CÓ, với 1 giới hạn rõ ràng.

**Kỹ thuật:** khi trang vẽ chữ lên `<canvas>`, phần lớn dùng đúng API chuẩn
`ctx.fillText(text, x, y)` / `ctx.strokeText(...)` — hàm này nhận CHUỖI TEXT
làm tham số, TRƯỚC KHI biến thành pixel. Ghi đè (`override`) 2 hàm này qua
JS tiêm vào NGAY KHI trang bắt đầu load (`onPageStarted`, sớm hơn hẳn
`onPageFinished` để giảm khả năng bỏ lỡ lần vẽ đầu tiên) → lưu mọi chuỗi
text bị vẽ vào `window.__canvasTextLog`. Đây là dữ liệu CHÍNH XÁC 100%
(không qua bước "đoán chữ trong ảnh" như OCR).

Kèm bonus: đọc luôn `aria-label`/`aria-describedby` trên trang — text mà
chính trang cung cấp cho screen reader (accessibility), cũng chính xác
100% cho nội dung canvas/hình ảnh.

### `lib/screens/sources/webview_capture_screen.dart` (cập nhật)
- Script override `fillText`/`strokeText` tiêm trong `onPageStarted`.
- Hàm `_extractCanvasText`: đọc lại `window.__canvasTextLog` + quét
  `aria-label`, gộp lại, lưu thành `SourceDocument`.
- Nút mới trên AppBar (icon "Aa") — đặt TRƯỚC nút OCR, vì nên thử cách này
  trước (chính xác hơn, chỉ khi không ăn thua mới dùng OCR).

**Giới hạn rõ ràng (không phải mọi canvas đều bắt được):**
- Trang vẽ chữ kiểu "sprite ảnh" (mỗi chữ là 1 hình có sẵn, hay gặp ở game)
  → không gọi `fillText` → không bắt được gì → quay lại OCR.
- WebGL thường không có API text chuẩn tương đương → cũng không bắt được
  → chỉ OCR mới xử lý được.
- Injection tại `onPageStarted` là điểm sớm nhất `webview_flutter` cho phép,
  nhưng vẫn có thể có 1 khoảng trễ nhỏ (race condition) nếu trang vẽ NGAY
  LẬP TỨC trong lúc parse HTML — trường hợp thường gặp hơn là canvas vẽ lại
  liên tục (chat, animation), nên phần lớn nội dung vẫn được bắt kể cả có
  bỏ lỡ vài khung hình đầu.

## 22. FIX build lỗi #40 (29/07/2026) — bug import có sẵn từ code gốc, mới lộ ra

**Lỗi thật:** `lib/widgets/export_runner.dart` import tương đối
`'export/docx_export.dart'` (và pptx/xlsx/code_zip tương tự) — nghĩa là kỳ
vọng các file đó nằm ở `lib/widgets/export/`. Nhưng vị trí THẬT của các
exporter là `lib/services/export/` (đã xác nhận bằng `find`). Đây là **bug
có sẵn từ code gốc của dự án, không phải do các thay đổi ở mục 10-21 gây
ra** — nó chỉ chưa từng lộ ra vì các lần build trước đó ĐỀU fail sớm hơn ở
bước Gradle (webview_cookie_manager, version file_picker...) nên trình biên
dịch Dart chưa bao giờ chạy tới đủ xa để phát hiện.

**Đã sửa:** đổi 4 dòng import trong `export_runner.dart` từ
`'export/xxx.dart'` → `'../services/export/xxx.dart'`.

**Về lỗi "Member not found: 'platform'" ở 3 file khác** (source_documents_
screen.dart, zip_edit_screen.dart, webview_capture_screen.dart) — đã kiểm
tra: `FilePicker.platform.pickFiles(...)` là API CHUẨN, đúng, ổn định của
package `file_picker` từ rất lâu, và cả 3 file đều import đúng
`package:file_picker/file_picker.dart`. Nhiều khả năng đây là LỖI DÂY
CHUYỀN (cascading error) — khi trình biên dịch Dart gặp lỗi fatal ở
import của `export_runner.dart`, nó có thể báo sai lệch ở các file khác
trong cùng đồ thị biên dịch. Dự đoán: lỗi này sẽ TỰ BIẾN MẤT sau khi sửa
import ở trên — nếu build #41 vẫn còn báo lỗi `FilePicker.platform` y hệt,
đây là dấu hiệu thật cần điều tra riêng (không phải cascading nữa).

## 23. FIX build lỗi #43 (29/07/2026) — file_picker bị pub chọn nhầm bản beta

**Xác nhận:** lỗi `export_runner.dart` ở mục 22 đã hết hẳn (fix đúng). Lỗi
`FilePicker.platform` ("Member not found") vẫn còn Y HỆT → xác nhận đây
KHÔNG phải cascading error như dự đoán ở mục 22, mà là lỗi thật.

**Nguyên nhân xác định được:** ở mục 17/23 tôi để `file_picker: ">=8.3.3"`
KHÔNG có trần trên (để giải quyết xung đột win32 với `share_plus ^13`, xem
mục 13). Nhưng Dart pub CÓ CHẤP NHẬN bản beta/prerelease khi không loại trừ
tường minh — và theo đúng log lỗi ở build #31 (mục 13), chuỗi bản `file_
picker` dùng `win32 ^6.x` (khớp với `share_plus ^13`) chỉ bắt đầu từ
`12.0.0-beta.1` — TỨC LÀ BẢN BETA, chưa ổn định, API có thể đổi/thiếu so
với bản ổn định 8.x-11.x. Rất có khả năng bản beta này thiếu hẳn getter
`.platform` hoặc cấu trúc lại chưa hoàn thiện.

**Đã sửa tận gốc — bỏ hẳn nhu cầu cần bản beta:**
- `file_picker: ">=8.3.3 <12.0.0"` — chặn cứng, không cho pub chọn bất kỳ
  bản 12.x/beta nào nữa, chỉ dùng dòng ổn định 8.3.3–11.x.
- `share_plus: ^12.0.2` (hạ từ `^13.0.0`, đúng gợi ý CHÍNH THỨC trong log
  lỗi build #31: "Consider downgrading your constraint on share_plus:
  flutter pub add share_plus:^12.0.2") — dòng 12.x của share_plus dùng
  `win32 ^5.x`, khớp với dòng ổn định của file_picker, không còn xung đột.
- Đã kiểm tra `file_saver.dart` chỉ dùng `Share.shareXFiles`/`XFile` — API
  rất ổn định, có từ lâu, chắc chắn còn nguyên trong `share_plus ^12.0.2`,
  không ảnh hưởng chức năng chia sẻ file hiện có.

**Bài học:** khi 1 dependency cần bản MỚI HƠN để giải quyết xung đột phụ
thuộc bắc cầu (như win32), cần kiểm tra kỹ xem bản "mới hơn" đó có phải bản
ỔN ĐỊNH hay chỉ là prerelease/beta — nếu là beta, ưu tiên hạ dependency BÊN
KIA (share_plus) xuống thay vì chấp nhận API chưa ổn định của bản beta.

## 24. FIX build lỗi #46 (29/07/2026) — bỏ hẳn file_picker, chuyển sang file_selector

**Xác nhận quan trọng:** giả thuyết "bản beta" ở mục 23 SAI. Log build #46
cho thấy `share_plus 12.0.2` và `win32 5.15.0` đều là bản ỔN ĐỊNH (không
phải beta/prerelease) — vậy mà lỗi `FilePicker.platform` ("Member not
found") vẫn Y HỆT. Nghĩa là đã đoán sai nguyên nhân 2 LẦN LIÊN TIẾP (mục
23 và giờ). Không đoán tiếp lần 3 nữa.

**Quyết định:** bỏ HẲN `file_picker` khỏi dự án, chuyển toàn bộ 3 chỗ dùng
sang `file_selector` — plugin CHÍNH THỨC do chính đội ngũ Flutter maintain
(nằm trong flutter.dev/packages, cùng nhóm với `path_provider`,
`shared_preferences`...), API tối giản hơn hẳn (`openFile(acceptedTypeGroups:
[XTypeGroup(extensions: [...])])` trả về `XFile?`, chỉ cần `.name` và
`.readAsBytes()`), ít bề mặt để hỏng hơn nhiều so với `file_picker` (vốn hỗ
trợ rất nhiều tính năng phức tạp — multi-pick, custom UI, compression...
mà app này không dùng tới).

### Đã sửa 3 file:
- `lib/screens/sources/source_documents_screen.dart` — `_uploadFile`
- `lib/screens/code/zip_edit_screen.dart` — `_pickZip`
- `lib/screens/sources/webview_capture_screen.dart` — `_pickZipAndPaste`

Cả 3 đổi từ `FilePicker.platform.pickFiles(type: FileType.custom,
allowedExtensions: [...], withData: true)` → `openFile(acceptedTypeGroups:
[XTypeGroup(extensions: [...])])`, và từ `PlatformFile` (có `.bytes`,
`.name`) → `XFile` (dùng `await f.readAsBytes()` + `.name`).

### `pubspec.yaml`
- Bỏ `file_picker`, thêm `file_selector: ">=1.0.0 <2.0.0"`.
- GIỮ NGUYÊN `share_plus: ^12.0.2` (không cần đổi lại — vẫn hoạt động tốt,
  không có lý do để đổi thêm biến số khi đang cố ổn định build).

**Rủi ro còn lại (thành thật, không phóng đại):** đây là lần đầu dùng
`file_selector` trong dự án này, dù tôi tự tin về API hơn `file_picker`
(đơn giản, ít thay đổi, đội Flutter chính thức maintain), vẫn CHƯA kiểm
chứng được bằng build thật. Nếu build #47 vẫn lỗi liên quan `file_selector`
hoặc `XTypeGroup`/`openFile`, gửi log ngay — đây sẽ là dấu hiệu vấn đề nằm
ở chỗ khác hoàn toàn (ví dụ cấu hình Android chung, không phải riêng 1
package nào), cần điều tra theo hướng khác hẳn.

## 25. FIX build lỗi #49 (29/07/2026) — R8 thiếu class ML Kit ngôn ngữ + đơn giản hoá OCR

**Tin tốt trước:** lỗi Dart compile (`FilePicker.platform`) đã HẾT HOÀN
TOÀN sau khi chuyển sang `file_selector` ở mục 24 — xác nhận đúng nguyên
nhân, build tiến xa hơn hẳn (qua hết bước Dart compile, resolve dependency,
tới tận bước R8 minify — bước gần cuối cùng của quy trình build).

**Lỗi mới (khác hẳn, ở tầng R8/ProGuard):**
`google_mlkit_text_recognition` có code Kotlin đã biên dịch sẵn tham chiếu
tới 4 lớp nhận diện chữ Trung/Nhật/Hàn/Devanagari (`ChineseTextRecognizerOptions`,
`JapaneseTextRecognizerOptions`, `KoreanTextRecognizerOptions`,
`DevanagariTextRecognizerOptions`), BẤT KỂ app Dart có thực sự gọi tới các
ngôn ngữ đó hay không — vì code Kotlin của chính plugin có nhánh xử lý cho
cả 4, và R8 (bước thu gọn code khi build release) phân tích TOÀN BỘ nhánh
đó, báo lỗi vì các lớp tương ứng không có trong classpath (app không khai
báo thêm module ngôn ngữ đó, mặc định `google_mlkit_text_recognition` chỉ
có sẵn module Latin).

**Đã sửa 2 phần cùng lúc:**

1. **Đơn giản hoá UI OCR** (`webview_capture_screen.dart`, mục 20 trước đó
   thêm menu chọn ngôn ngữ) — BỎ menu Trung/Nhật/Hàn/Devanagari, chỉ còn
   OCR Latin (đúng nhu cầu thật của người dùng — tiếng Việt dùng bảng chữ
   Latin). Lý do bỏ thay vì thêm dependency ngôn ngữ: thêm dependency thật
   cho 4 ngôn ngữ đó sẽ tăng thêm rủi ro Gradle (kích thước APK, thêm native
   module) mà người dùng không thực sự cần — ĐÚNG nguyên tắc "cái gì tiết
   kiệm được thì tiết kiệm" người dùng đã nói ở đầu phiên làm việc này.

2. **Thêm bước CI ghi `android/app/proguard-rules.pro`** với `-dontwarn`
   cho 4 package Kotlin đó — an toàn vì đã bỏ hẳn khả năng gọi tới các nhánh
   code đó từ Dart (mục 1 ở trên), nên `-dontwarn` không che giấu rủi ro
   crash runtime thật nào. Bước này CŨNG tự kiểm tra và thêm dòng
   `proguardFiles(...)` vào `buildTypes.release` trong `build.gradle.kts`
   NẾU bản Flutter đang dùng chưa tự có sẵn — đã tự mô phỏng chạy thử bằng
   `sed` thật trên file giả lập (không đoán), xác nhận chèn đúng vị trí và
   không chèn trùng lần 2 nếu đã có sẵn.

**Nếu build #50 vẫn lỗi R8** (dù đã thêm dontwarn) — khả năng là còn thiếu
class khác chưa liệt kê hết trong `missing_rules.txt` (log build luôn ghi
đường dẫn file này) — gửi thêm nội dung file đó nếu build tiếp tục lỗi R8.

## 26. FIX build lỗi #52 (29/07/2026) — bước vá proguardFiles ở mục 25 ÂM THẦM THẤT BẠI

**Xác nhận bằng test thật (không đoán):** lỗi R8 ở build #52 GIỐNG HỆT 100%
build #49 (từng dòng, từng class) dù đã thêm bước vá ở mục 25 — nghĩa là
bước đó đã KHÔNG CÓ TÁC DỤNG GÌ. Tự dựng lại file `build.gradle.kts` giả
lập GIỐNG NHƯ THẬT (có `buildTypes { getByName("release") { isMinifyEnabled
= true } } }`, KHÔNG có dòng `signingConfig`) và chạy thử ĐÚNG script trong
mục 25 → xác nhận: sed neo vào `/signingConfig/a\...` bên trong 1 range
`/getByName("release")/,/}/` sẽ ÂM THẦM KHÔNG CHÈN ĐƯỢC GÌ nếu range đó
không có dòng "signingConfig" — không báo lỗi, chỉ đơn giản là không làm
gì, nên trước đó tưởng đã sửa nhưng thực ra vô tác dụng.

**Đã sửa (đã tự test cả 2 kịch bản trước khi gửi):**
- Đổi neo sang chính dòng MỞ `getByName("release") {` — chèn ngay sau dòng
  này bất kể bên trong release{} có gì, không phụ thuộc "signingConfig"
  có tồn tại hay không. Test với file giả lập KHÔNG có signingConfig →
  chèn đúng.
- Thêm fallback: nếu cách trên vẫn không chèn được (ví dụ bản Flutter nào
  đó dùng cú pháp Kotlin DSL rút gọn `release { }` thay vì
  `getByName("release") { }`), thử neo vào đúng cú pháp rút gọn đó. Test
  với file giả lập dùng cú pháp rút gọn → chèn đúng.
- Thêm cảnh báo rõ ràng ra log nếu CẢ 2 cách đều thất bại (thay vì âm thầm
  im lặng như lần trước).
- LUÔN in ra TOÀN BỘ nội dung `build.gradle.kts` cuối bước, để lần build
  sau (nếu vẫn lỗi) có thể đọc thẳng log và biết chính xác file thật trông
  như thế nào, không cần đoán/dựng lại file giả lập nữa.

**Bài học:** khi patch file bằng sed dựa trên "neo vào 1 dòng cụ thể", luôn
tự dựng file giả lập THEO ĐÚNG kịch bản THIẾU dòng neo đó để kiểm tra sed
có ÂM THẦM THẤT BẠI hay không — sed không match thì không báo lỗi gì cả,
rất dễ tưởng đã sửa xong nhưng thực ra không có tác dụng.

## 27. FIX build lỗi #55 (29/07/2026) — tắt R8 full mode thay vì tiếp tục vá -dontwarn

Người dùng đã đúng khi phản đối việc tôi đề xuất bỏ tính năng thay vì cố
tìm cách giải quyết — xin ghi nhận lại rõ ràng hướng xử lý đã áp dụng.

**Đã xác nhận:** người dùng dùng ĐÚNG bản zip mới nhất (mục 26) khi build
#55, vậy mà lỗi R8 vẫn giống hệt 100%. Có 2 khả năng: (a) bước chèn
`proguardFiles` vẫn chưa hoạt động vì lý do khác chưa lường tới, hoặc (b)
`-dontwarn` đơn thuần không đủ vì R8 "full mode" (mặc định từ AGP 7+) nâng
lỗi "missing class" lên thành LỖI CỨNG bất kể có `-dontwarn` hay không.

**Đã thêm (không bỏ tính năng OCR):** bước CI mới "Tắt R8 full mode" — ghi
`android.enableR8.fullMode=false` vào `android/gradle.properties` (tự kiểm
tra, không thêm trùng nếu đã có). Đây là cách xử lý CHÍNH THỨC được Google
tài liệu hoá riêng cho đúng nhóm lỗi "thư viện bên thứ 3 đóng gói không
nhất quán giữa các module" — khác hẳn việc tắt hẳn minify: app vẫn được
thu gọn/obfuscate bình thường, chỉ nới lỏng đúng phần R8 phân tích nghiêm
ngặt toàn chương trình gây ra lỗi cứng này. Giữ nguyên `-dontwarn` ở bước
trước làm lớp phòng thủ thứ 2.

Đã tự test trên file `gradle.properties` giả lập (cả lần đầu ghi và lần 2
kiểm tra không ghi trùng) trước khi gửi.

**Nếu build #56 vẫn lỗi y hệt:** đây sẽ là dấu hiệu RẤT RÕ rằng nguyên nhân
không nằm ở tầng ProGuard/R8 nữa mà ở việc dependency `com.google.mlkit:
text-recognition-chinese/-japanese/-korean/-devanagari` (các module ngôn
ngữ) thực sự KHÔNG được `google_mlkit_text_recognition` tự động kéo về —
lúc đó cách xử lý đúng sẽ khác hẳn: thêm thẳng các dependency Android gốc
đó vào `android/app/build.gradle.kts` (cần biết đúng version tương thích,
rủi ro cao hơn vì đụng trực tiếp vào Maven artifact gốc của Google, không
qua Flutter/Dart nữa).

## 28. FIX build lỗi #58 (29/07/2026) — thêm thẳng dependency ML Kit ngôn ngữ + lưu chẩn đoán

**Xác nhận:** lỗi R8 vẫn Y HỆT sau CẢ 3 cách "ẩn cảnh báo" (dontwarn, sửa
neo sed, tắt full mode) — đúng như dự đoán ở mục 27, chuyển hướng xử lý:
class thực sự KHÔNG có trong classpath, không phải R8 xử lý sai.

**Đã làm (đồng thời 2 việc):**

1. **Thêm thẳng dependency Android gốc** cho 4 module ngôn ngữ ML Kit
   (`com.google.mlkit:text-recognition-chinese/-japanese/-korean/-devanagari`)
   vào `android/app/build.gradle.kts` — bước "Thêm thẳng dependency ML Kit
   ngôn ngữ" trong `build_apk.yml`, đặt ngay sau "Get dependencies". Dùng
   `awk` (KHÔNG dùng heredoc python — lần đầu viết bằng heredoc đã LẶP LẠI
   đúng lỗi thụt lề YAML ở mục 25, đã tự phát hiện bằng cách parse YAML lại
   trước khi gửi và sửa ngay). Đã tự test cả 2 kịch bản (có sẵn
   `dependencies {}` / chưa có) + test idempotent (chạy 2 lần không lặp)
   trên file giả lập, đều đúng.

2. **Luôn lưu lại `missing_rules.txt`** làm artifact GitHub Actions (bước
   "Luôn lưu lại missing_rules.txt...", `if: always()`) — kể cả khi build
   fail. Nếu cách 1 vẫn không đủ, đây là lưới an toàn để LẦN SAU đọc được
   CHÍNH XÁC Google gợi ý gì, thay vì tiếp tục đoán mù.

**Rủi ro đã biết trước (thành thật):** version `16.0.1` cho 4 dependency
trên là phỏng đoán hợp lý (dựa trên các version phổ biến của họ ML Kit text
recognition), CHƯA kiểm chứng bằng build thật. Nếu Gradle báo lỗi resolve
version cho các dependency này, đó là dấu hiệu cần đổi số version — khác
hẳn với việc R8 báo "Missing class" (2 loại lỗi khác nhau, dễ phân biệt
trong log).

## 29. Build lỗi #61 — 5 lần liên tiếp lỗi Y HỆT dù đã đổi 4 chiến lược khác nhau

**Vấn đề nghiêm trọng nhất hiện tại: không phải kỹ thuật, mà là XÁC MINH.**
Lỗi R8 giống hệt byte-by-byte qua build #49, #52, #55, #58, #61 — kể cả sau
khi thêm THẲNG dependency Maven thật (mục 28, đáng lẽ phải giải quyết được
nếu áp dụng đúng). Khả năng cao nhất lúc này KHÔNG còn là "đoán sai kỹ
thuật" nữa, mà là các thay đổi trong workflow CHƯA THỰC SỰ được build sử
dụng (có thể do: build lại từ 1 commit cũ qua nút "Re-run", cache Gradle
cũ, hoặc quy trình đưa code lên repo có vấn đề — đã hỏi người dùng nhưng
chưa có câu trả lời rõ).

**Đã thêm (mã đánh dấu FIX-v28):** bước "Build APK (release)" — bước DUY
NHẤT người dùng luôn dán log của nó — giờ IN RA BẰNG CHỨNG TRỰC TIẾP ngay
trước khi build thật:
- Nội dung `proguard-rules.pro`
- Có dòng `proguardFiles` trong `build.gradle.kts` không
- Có dependency ML Kit ngôn ngữ (chinese/japanese/korean/devanagari) trong
  `build.gradle.kts` không
- Có dòng tắt R8 full mode trong `gradle.properties` không

**Nếu build sau vẫn lỗi:** nhìn NGAY đoạn "XÁC NHẬN CÁC BƯỚC VÁ TRƯỚC ĐÓ"
ở đầu log bước Build APK — nếu bất kỳ dòng nào báo "!!! KHÔNG ... !!!", đó
là bằng chứng CHẮC CHẮN các bước vá trước không chạy/không tới nơi, và vấn
đề nằm ở QUY TRÌNH đưa code lên repo hoặc cách trigger build, KHÔNG PHẢI ở
nội dung các bước vá (vốn đã tự test kỹ trước khi gửi qua nhiều mục 15, 25,
26, 27, 28). Nếu tất cả các dòng đều xác nhận CÓ đầy đủ nhưng build vẫn
lỗi y hệt — lúc đó mới quay lại xem xét vấn đề kỹ thuật sâu hơn (ví dụ
version 16.0.1 sai, hoặc cần version khác của các dependency ML Kit).

## 30. Cập nhật 31/07/2026 — Provider riêng cho Thư ký AI + prompt mồi định dạng chuẩn

### 30.1. Provider riêng cho tác vụ Thư ký AI (độc lập với đoạn chat đang mở)
- `storage_service.dart`: thêm `providerById`, `secretaryProviderId` (đọc/ghi
  qua box `settings` thường, key `secretary_provider_id`), `secretaryProvider`.
- `ChatProvider.compileSources` và `ZipEditScreen._runEdit`: ưu tiên dùng
  `storage.secretaryProvider` nếu người dùng đã chọn, rơi về provider của
  đoạn chat đang mở (hành vi cũ) nếu chưa chọn.
- Widget `SecretaryProviderBar` (định nghĩa trong `webview_capture_screen.dart`,
  dùng chung được vì để public) — dropdown chọn provider, hiển thị ở đầu cả
  `WebviewCaptureScreen` lẫn `SourceDocumentsScreen`. Mục đích: cho phép dùng
  1 model rẻ/nhanh riêng (ví dụ Gemini free qua AI Studio) cho việc trích
  xuất/tổng hợp, tách biệt với model đang dùng để trò chuyện chính.

### 30.2. Prompt "mồi" định dạng chuẩn — giảm tối đa việc phải gọi AI của app
Người dùng đề xuất: nhờ AI khác/người khác xuất SẴN đúng định dạng ngay từ
đầu, để `CodeZipExporter.extractFiles` (thuần code, 0 token) parse được
luôn, khỏi cần app tự gọi thêm AI để "dịch lại" định dạng.

- `CodeZipExporter.formatInstructionPrompt` (hằng số mới): prompt hướng dẫn
  cú pháp ```đường/dẫn/file.ext ... ``` chuẩn.
- `webview_capture_screen.dart` — `_pickZipAndPaste`: TỰ ĐỘNG chèn prompt
  này vào đầu nội dung mỗi khi ghép file từ zip để dán cho bên ngoài (không
  cần thao tác thêm, luôn có sẵn).
- `zip_edit_screen.dart` — khu vực "Cách 2": thêm nút "Copy prompt định
  dạng chuẩn" chủ động (dùng trước khi cần), và khi parse thất bại,
  `SnackBarAction` "Copy prompt định dạng" xuất hiện ngay để gửi lại cho
  bên kia yêu cầu định dạng lại.

### 30.3. Đính chính hiểu lầm quan trọng (không phải code, nhưng cần ghi lại)
Người dùng nhầm Gemini (API cloud của Google, model lớn, qua AI Studio) với
Gemma (model nhỏ, chạy on-device) — đã giải thích đây là 2 dòng sản phẩm
khác nhau. Gemini 2.0 Flash qua AI Studio free tier là lựa chọn tốt để
giảm chi phí (model cloud thật, chất lượng cao, không đánh đổi như chạy
Gemma local) — khuyến khích dùng qua `SecretaryProviderBar` mới thêm.

## 31. Cập nhật 31/07/2026 — Prompt mồi định dạng + xuất thẳng 0 token cho CẢ docx/pptx/xlsx (không chỉ zip)

Người dùng hỏi đúng: mục 30.2 mới chỉ làm cho zip, chưa làm cho docx/pptx/
xlsx. Đã bổ sung đủ, áp dụng ĐÚNG nguyên tắc y hệt.

### `lib/services/secretary_prompt_builder.dart` (refactor)
Tách `formatInstruction(String outputFormat) -> String` thành hàm PUBLIC
riêng (trước đây nằm lồng trong `build()` dùng nội bộ) — trả về đúng đoạn
"định dạng trả lời bắt buộc" cho từng loại (docx/pptx/xlsx/zip), dùng làm
prompt mồi copy ra ngoài. `build()` giờ gọi lại hàm này để không lặp code.

### `lib/screens/sources/source_documents_screen.dart` — `_CompileSheet`
- Nút "Copy prompt định dạng (dán mồi cho bên ngoài)" — copy đúng hướng dẫn
  định dạng khớp với format đang chọn (docx/pptx/xlsx/zip).
- Thêm "Cách 2" (thu gọn mặc định, bấm để mở): "Đã có nội dung đúng định
  dạng từ nơi khác? (0 token)" — ô dán nội dung + nút "Xuất thẳng (không
  gọi AI)", gọi THẲNG đúng exporter tương ứng (`DocxExporter`/`PptxExporter`/
  `XlsxExporter`/`CodeZipExporter`) và `FileSaver.saveAndShare` — HOÀN TOÀN
  không qua `chat.compileSources` (không gọi API của app).

**Ví dụ áp dụng đúng câu hỏi người dùng nêu** (tiểu luận Word): copy prompt
định dạng docx → dán cho ChatGPT/Gemini ngoài kèm đề tài + yêu cầu trình
bày → họ trả lời đúng theo markdown rút gọn (`# Đề tài`, `## Mục`, đoạn
văn...) → dán ngược lại vào "Cách 2" → "Xuất thẳng" → ra file .docx ngay,
0 token phía app.

Không đổi gì ở `CodeZipExporter.formatInstructionPrompt` (giữ nguyên, nội
dung tương đương `SecretaryPromptBuilder.formatInstruction('zip')` nhưng
không hợp nhất thành 1 nguồn vì 1 bên là `static const`, bên kia là hàm —
hợp nhất sẽ phải đổi kiểu, rủi ro không đáng so với lợi ích của việc tránh
lặp 1 đoạn text ngắn).

## 32. Cập nhật 31/07/2026 — JSON DSL giàu định dạng (Tier 1) + Tier 3 Python-ở-nơi-khác

Triển khai đúng mô hình 3 tầng đã thống nhất với người dùng: Tier 1 (JSON
DSL, code thuần) ưu tiên → Tier 3 (nhờ AI khác tự chạy Python trên hạ tầng
CỦA HỌ, tải link về) khi Tier 1 không đủ. KHÔNG có Tier "app tự chạy
Python" — đã giải thích rõ lý do (rủi ro rò API key/cookie/tài liệu, không
giảm bằng cách đặt cuối chuỗi fallback) và người dùng đã đồng thuận hướng
đi này.

### 32.1. `docx_export.dart`, `pptx_export.dart`, `xlsx_export.dart` — thêm `exportJson()`
Giữ nguyên `export()` cũ (markdown/bảng `|` rút gọn, không đổi, không phá
tính năng đang chạy). Thêm `exportJson()` đọc JSON DSL giàu hơn hẳn:
- **Docx**: heading, paragraph có `runs` (đậm/nghiêng/màu từng đoạn nhỏ
  trong 1 câu), bullet/numbered list, **bảng thật** (`w:tbl` OOXML, không
  phải text `|`), ảnh nhúng thật (`w:drawing`), **mục lục tự động** (TOC
  field — Word tự tính số trang khi mở), ngắt trang.
- **Pptx**: mỗi slide có title/bullets/**ảnh nhúng** (`p:pic` shape thật).
- **Xlsx**: nhiều sheet, mỗi ô có thể đậm/nền màu (qua style cố định nhỏ,
  tránh build style động phức tạp dễ sai OOXML), **công thức Excel thật**
  (`<f>=SUM(...)</f>` — Excel tự tính, app chỉ ghi chuỗi công thức), merge
  ô (`mergeCells`).

### 32.2. `chart_renderer.dart` (MỚI) — biểu đồ/sơ đồ minh hoạ
`ChartRenderer.renderToPng(context, block)` — vẽ biểu đồ cột/đường
(`_ChartPainter`) hoặc sơ đồ khối + mũi tên (`_DiagramPainter`) bằng
`CustomPainter` THUẦN HÌNH HỌC (vẽ hình chữ nhật/đường/text theo toạ độ và
SỐ trong JSON — không có bước "thực thi" nào), chụp bằng
`RepaintBoundary.toImage()` (kỹ thuật đã dùng cho OCR ở mục 19) qua 1
`OverlayEntry` đặt hẳn ra ngoài màn hình (không nhấp nháy), trả về PNG
bytes để nhúng vào docx/pptx như ảnh thường.

**Chưa làm** (đã nói rõ với người dùng): ảnh minh hoạ có "người và bối
cảnh" (ảnh sinh bằng AI) — không giải quyết bằng CustomPainter được (đó là
vẽ hình học, không tạo ảnh chân thực), cần 1 dịch vụ sinh ảnh AI riêng
(chưa tích hợp) hoặc tải ảnh có sẵn qua URL (đã hỗ trợ, xem mục 32.3).

### 32.3. `dsl_document_builder.dart` (MỚI) — lớp trung gian cần BuildContext
`DslDocumentBuilder.buildDocx/buildPptx/buildXlsx` — tiền xử lý JSON: block
`chart`/`diagram` → gọi `ChartRenderer` vẽ thành PNG; block `image` có
`base64` → giải mã trực tiếp; có `url` → **tải ảnh qua HTTP GET bình
thường** (chỉ tải bytes ảnh, không thực thi gì — dùng cho trường hợp AI trả
về link ảnh người/bối cảnh đã có sẵn trên mạng, hoặc link ảnh do dịch vụ
sinh ảnh AI khác trả về) — rồi gọi đúng exporter tương ứng.

### 32.4. Wiring: `ExportRunner` + `SourceDocumentsScreen._exportDirect`
Cả 2 chỗ gọi exporter giờ THỬ JSON DSL trước (`DslDocumentBuilder`), CHỈ
rơi về markdown/bảng `|` cũ nếu nội dung không phải JSON hợp lệ — tương
thích ngược hoàn toàn, không cần đổi gì ở nơi khác.

### 32.5. `secretary_prompt_builder.dart` — cập nhật `formatInstruction()` + thêm `tier3PythonPrompt()`
- `formatInstruction()`: mô tả ĐÚNG schema JSON DSL mới (không còn markdown
  rút gọn) cho docx/pptx/xlsx — áp dụng cho cả prompt mồi copy ra ngoài LẪN
  khi AI trong app tự tổng hợp (qua `compileSources`), nên cả 2 đường đều
  nhất quán dùng JSON giàu định dạng.
- `tier3PythonPrompt(outputFormat)` (MỚI): prompt Tier 3 — nhờ 1 AI CÓ SẴN
  khả năng chạy code (Claude.ai/ChatGPT Code Interpreter/Google Colab) TỰ
  viết và TỰ CHẠY Python (python-docx/pptx/openpyxl) trên hạ tầng CỦA HỌ,
  đưa link tải file kết quả — app chỉ tải file đã hoàn thiện (dùng lại cơ
  chế tải qua link đã có ở mục 19-21), KHÔNG có bước nào app tự chạy code.

### 32.6. UI: `source_documents_screen.dart` — `_CompileSheet`
Thêm nút "Tier 3: nhờ bên kia tự chạy Python (khi JSON không đủ)" cạnh nút
copy prompt Tier 1 — dùng khi JSON DSL không biểu đạt đủ yêu cầu quá đặc
thù.

**CHƯA kiểm chứng bằng build/mở file thật** (không có Word/PowerPoint/Excel
thật để mở thử OOXML tự viết tay trong môi trường code này) — rủi ro lớn
nhất nếu có lỗi: sai cú pháp XML nhỏ (thiếu namespace, sai thứ tự phần tử)
khiến Word/Excel/PowerPoint báo "file bị hỏng, có sửa được không?" khi mở
— nếu gặp, gửi lại chính xác thông báo lỗi của Word/Excel để sửa đúng chỗ.

## 33. Cập nhật 31/07/2026 — Provider sinh ảnh AI (fallback sau URL, tiết kiệm token)

Xác nhận: tải + chèn ảnh qua URL vào tài liệu ĐÃ hoạt động từ mục 32.3,
không cần làm gì thêm cho phần đó.

Bổ sung: khi KHÔNG có URL ảnh phù hợp, fallback sang gọi API sinh ảnh AI
(DALL-E/Stability/Imagen qua endpoint kiểu OpenAI-compatible
`/images/generations`) — CHỈ khi cả base64 và url đều không có/thất bại,
đúng thứ tự ưu tiên người dùng yêu cầu (URL trước để tiết kiệm, API sinh
ảnh sau cùng vì tốn phí).

### `lib/services/image_gen_service.dart` (MỚI)
`ImageGenService.generate(ProviderConfig, prompt) -> Uint8List?` — POST
`$baseUrl/images/generations` (Bearer auth, dùng lại đúng `ProviderConfig`
đã có — không tạo model Hive mới, không rủi ro migration). Xử lý cả 2 kiểu
response (`b64_json` trực tiếp, hoặc `url` ảnh đã sinh cần tải thêm 1 lần).

### `lib/services/storage_service.dart`
Thêm `imageGenProviderId`/`imageGenProvider` — theo ĐÚNG pattern
`secretaryProviderId` đã có (lưu trong box `settings` thường, không phải
Hive model mới) — người dùng tạo 1 Provider bình thường (màn "Thêm
Provider" có sẵn) trỏ tới endpoint sinh ảnh, rồi đánh dấu nó làm "Provider
sinh ảnh" qua menu trong `provider_settings_screen.dart` (mục mới "Dùng làm
Provider sinh ảnh (DALL-E/Stability...)").

### `lib/services/export/dsl_document_builder.dart` (viết lại `_resolveImageBytes`)
Thứ tự fallback CHẶT CHẼ cho MỌI block ảnh (docx lẫn pptx):
1. `base64` có sẵn → giải mã trực tiếp.
2. `url` có sẵn → tải qua HTTP GET (miễn phí).
3. CHỈ khi (1) và (2) đều không có/thất bại VÀ có `prompt` mô tả ảnh VÀ đã
   cấu hình Provider sinh ảnh → gọi `ImageGenService` (tốn phí, phương án
   cuối).

### `lib/services/secretary_prompt_builder.dart`
Cập nhật `formatInstruction()` (docx + pptx): dạy AI ưu tiên điền `"url"`
nếu có ảnh sẵn, chỉ điền `"prompt"` (mô tả ảnh cần tạo) khi KHÔNG có url —
để chính AI cũng tuân theo đúng thứ tự tiết kiệm này khi tự chọn cách trả
lời, không chỉ code phía app.

**Rủi ro/giới hạn thành thật:**
- Chỉ hỗ trợ format request/response kiểu OpenAI-compatible (DALL-E và các
  dịch vụ tương thích) — Stability AI/Google Imagen "thuần" (không qua lớp
  tương thích OpenAI) có schema khác, CHƯA hỗ trợ trực tiếp; nếu dùng
  Imagen, khuyên tìm endpoint OpenAI-compatible của Gemini tương tự cách đã
  làm ở mục 20 cho chat.
- Chưa build/test thật (như toàn bộ tính năng OOXML ở mục 32) — cần build
  thật + có API key thật để kiểm chứng request/response khớp.

## 34. Cập nhật 04/08/2026 — Sandbox Python (Tier 2), ĐẢO NGƯỢC quyết định mục 32

**Quan trọng — đọc trước khi động vào bất kỳ file nào liệt kê dưới đây:**
mục 32 từng ghi "KHÔNG có Tier app tự chạy Python" và nói người dùng đã
đồng thuận. Ở phiên làm việc này, người dùng được nhắc lại đúng quyết định
đó (kèm lý do rủi ro rò API key/dữ liệu) và **chủ động xác nhận vẫn muốn
app tự chạy Python**, chấp nhận đánh đổi, với điều kiện: cô lập mạng, không
đọc được key/file khác của app. Đây KHÔNG phải sơ suất bỏ qua quyết định
cũ — đã hỏi lại rõ ràng và có xác nhận mới. Nếu tiếp tục sửa phần này, giữ
đúng tinh thần "cô lập thật, không phải cô lập hình thức" bên dưới.

### 34.1. Kiến trúc chọn: Pyodide (CPython/WASM) chạy trong `WebView` ẩn

Lý do chọn thay vì Chaquopy (Python native cho Android) hay 1 process
Android riêng: `WebView` hệ thống trên Android chạy ở **tiến trình sandbox
riêng của chính hệ điều hành** (renderer process của Chromium WebView),
tách biệt vật lý khỏi tiến trình chính của app Flutter (nơi Hive lưu API
key). Chaquopy thì ngược lại — chạy CÙNG tiến trình app, có thể đọc thẳng
bộ nhớ/file app nếu code Python cố tình làm vậy, nên bị loại.

Lớp cô lập THỰC SỰ nằm ở 2 tầng:
1. **Tiến trình hệ thống riêng** (WebView) — Python/JS trong đó không có
   API nào để với sang tiến trình Flutter chính.
2. **Content-Security-Policy** trong chính trang HTML nạp Pyodide
   (`connect-src 'self'`) — chặn MỌI network request (fetch/XHR) ra ngoài,
   áp dụng cho cả code Python cố `urllib`/`micropip.install` (những thứ đó
   trong Pyodide đều đi qua fetch của trình duyệt bên dưới, nên bị CSP chặn
   y hệt).

**Giới hạn thành thật — KHÔNG bảo vệ khỏi:** tấn công từ chối dịch vụ cục bộ
(code lặp vô hạn ngốn CPU/RAM thiết bị — có timeout + huỷ WebView để giảm
thiểu, không loại bỏ hoàn toàn); rò rỉ dữ liệu QUA kênh không phải network
(ví dụ nếu sau này có ai lỡ thêm JS bridge khác đưa dữ liệu nhạy cảm vào
trang này — hiện KHÔNG có, xem 34.2). Không chống được nếu chính người dùng
dán code Python nguy hiểm cho MÁY CỦA HỌ chạy trong sandbox này (sandbox chỉ
cô lập khỏi APP, không phải khỏi thiết bị — dù bản thân sandbox không có
quyền hệ thống nào đặc biệt để làm hại thiết bị).

### 34.2. File mới/sửa

- `assets/sandbox/sandbox.html` (MỚI): trang nạp Pyodide, có CSP, expose
  `window.__runPython(id, code, inputsJson)`; kết quả trả về qua JS channel
  `PySandboxChannel` — 1 chiều sandbox → Dart.
- `lib/services/python_sandbox_service.dart` (MỚI): `PythonSandboxService`
  — quản lý `WebViewController`, mount off-screen qua `OverlayEntry` (CÙNG
  kỹ thuật `ChartRenderer` đã dùng ở mục 32.2, cần `BuildContext` đang có
  `Overlay`). Timeout cứng 20s/lần chạy, 45s lần đầu nạp Pyodide; giới hạn
  code ≤20.000 ký tự, output ≤8MB; nếu timeout thì HUỶ LUÔN WebView (nghi
  treo), lần gọi sau tạo WebView mới sạch. `run()` CHỈ nhận `code` +
  `inputs` (JSON thuần) — không có tham số nào khác để lỡ truyền
  `ProviderConfig`/Hive box vào.
- `lib/services/export/dsl_document_builder.dart`: thêm xử lý block
  `{"type":"python","produces":"image|table|text",...}` cho docx (mọi vị
  trí trong `blocks`) và pptx (trong `images` của từng slide, chỉ hỗ trợ
  `produces:"image"`); thêm sheet kiểu `{"type":"python",...}` cho xlsx
  (thay bằng `rows` Python trả về). `buildXlsx` đổi chữ ký, giờ CẦN
  `BuildContext` (trước đây không cần) — đã cập nhật 2 nơi gọi:
  `lib/widgets/export_runner.dart` và
  `lib/screens/sources/source_documents_screen.dart` (`_exportDirect`).
- `lib/services/secretary_prompt_builder.dart`: thêm `_pythonBlockGuide()`
  dạy AI schema khối "python" + nhắc rõ CHỈ có thư viện chuẩn (không
  numpy/PIL, không mạng); cập nhật `formatInstruction()` 3 định dạng +
  `tier3PythonPrompt()` (đổi mô tả: Tier 3 giờ dùng khi CẢ Tier 1 lẫn Tier 2
  đều không đủ, không phải "KHÔNG có Tier app tự chạy" như bản cũ).
- `pubspec.yaml`: thêm `flutter.assets` (`assets/sandbox/`,
  `assets/pyodide/`). KHÔNG thêm dependency mới — `webview_flutter` đã có
  sẵn từ trước (dùng cho tính năng đăng nhập web ở mục khác).
- `assets/pyodide/README.md` (MỚI, chỉ là ghi chú): giải thích thư mục này
  KHÔNG chứa file nhị phân Pyodide trong git/zip nguồn (quá nặng, ~15-20MB
  bản "core"), CI tự tải trước khi build.
- `.github/workflows/build_apk.yml`: thêm bước "Tải Pyodide..." TRƯỚC bước
  "Get dependencies" — tải `pyodide-core-0.28.3.tar.bz2` từ GitHub releases
  của dự án Pyodide, giải nén vào `assets/pyodide/`, `exit 1` kèm hướng dẫn
  rõ nếu link lỗi (không âm thầm build thiếu sandbox).

### 34.3. Vì sao dùng bản "pyodide-core" (không phải bản đầy đủ ~200MB+)

Bản đầy đủ có sẵn numpy/pandas/matplotlib... nhưng nặng, làm APK phình to
không cần thiết. Bản "core" chỉ có runtime + thư viện chuẩn Python — ĐÚNG Ý
ĐỒ "sandbox tối giản, không mạng, không thư viện ngoài" mà người dùng yêu
cầu, không phải hạn chế ngoài ý muốn. Do đó khối "python" trong prompt dạy
AI (mục 34.2) được dặn rõ: dùng cho TÍNH TOÁN/BIẾN ĐỔI DỮ LIỆU (→ `produces:
"table"`/`"text"`) là chính; muốn vẽ ảnh vẫn nên ưu tiên khối "chart"/
"diagram" có sẵn (app tự vẽ bằng `CustomPainter`, không cần thư viện ảnh
trong Python).

### 34.4. Đã tra cứu lại (04/08/2026) — sửa 2 chỗ sai, xác nhận phần còn lại

Sau khi bị hỏi lại vì sao ghi "chưa kiểm chứng" trong khi có `web_search`:
đã dùng `web_search` tra tài liệu chính thức pyodide.org/GitHub releases
(KHÔNG phải build thật — vẫn chưa build/chạy trên máy thật, xem 34.5) và
sửa được 2 điểm sai:

1. **Version Pyodide đổi từ `0.28.3` → `314.0.2`**: bản `0.28.3` không còn
   là "ổn định mới nhất" — Pyodide đã đổi hẳn sang CalVer, bản stable hiện
   tại là `314.x` (tương ứng hỗ trợ CPython 3.14). Đã sửa
   `PYODIDE_VERSION` trong `.github/workflows/build_apk.yml` và
   `assets/pyodide/README.md`. Đường dẫn tải (`pyodide-core-<version>.tar.bz2`
   từ GitHub releases) và cách nạp bằng thẻ `<script src="pyodide.js">`
   (không phải ES module) **vẫn đúng và được xác nhận hoạt động ở bản
   314.0.2** (tài liệu chính thức: "If you can't use the es6 module,
   pyodide.js places loadPyodide() on globalThis").
2. **Bug nhỏ trong `assets/sandbox/sandbox.html`**: hàm `batched` của
   `setStdout`/`setStderr` đã tự kèm `\n` khi tách theo dòng — code cũ cộng
   thêm `'\n'` nữa gây dư dòng trống. Đã bỏ phần cộng thêm.

**Đã xác nhận đúng (không cần sửa):** `pyodide.setStdout({batched: fn})` —
đúng y hệt cách dùng ở mọi bản Pyodide từ 0.22 đến 314.0.2 (tài liệu chính
thức có ví dụ y hệt code đã viết). Việc Pyodide đổi tên `pyodide.asm.js` →
`pyodide.asm.mjs` ở bản 314 KHÔNG ảnh hưởng cách nạp qua `pyodide.js` +
`loadPyodide()` đang dùng (chỉ ảnh hưởng ai tự import thẳng file `.asm.js`
hoặc dùng classic worker — không phải trường hợp ở đây).

### 34.5. Vẫn CHƯA kiểm chứng — vì sao khác với mục 34.4

`web_search` tra được ĐÚNG tài liệu/API, nhưng KHÔNG thay thế được việc
**biên dịch + chạy thật trên thiết bị**, vì môi trường viết code này không
cài Flutter/Dart SDK (không phải chỉ thiếu mạng). Cụ thể còn chưa xác nhận
được bằng build thật:
- `loadFlutterAsset` (webview_flutter) có phục vụ đúng đường dẫn tương đối
  `../pyodide/` từ `assets/sandbox/sandbox.html` trên Android thật hay
  không — đây là hành vi riêng của plugin `webview_flutter`, không nằm
  trong tài liệu Pyodide nên `web_search` không xác nhận được từ phía đó.
- Tên file `.wasm` chính xác bên trong gói `pyodide-core-314.0.2.tar.bz2`
  (tài liệu Pyodide không liệt kê đầy đủ danh sách file, chỉ nói "pyodide.js
  + file .wasm đi kèm").
- Hành vi thật của `OverlayEntry` mount `WebViewWidget` off-screen (kỹ
  thuật mượn từ `ChartRenderer` vốn dùng cho `RepaintBoundary`, chưa từng
  dùng thử với `WebViewWidget` trong dự án này).

Nếu build CI báo lỗi cụ thể ở bước "Tải Pyodide" hoặc app crash khi mở màn
hình xuất file có khối "python", gửi nguyên văn log — sẽ tra/sửa đúng chỗ
thay vì đoán lại.

### 34.6. Rà soát code thừa/không dùng (theo yêu cầu 04/08/2026)

Đã rà soát toàn bộ `lib/` và `pubspec.yaml` bằng cách đối chiếu THẬT (grep
từng file/package xem có bị import/dùng ở đâu không, không đoán) — kết quả
chi tiết ở 34.7. Ngoài ra có gỡ 2 thư mục rác `lib/{models,services...}`
(tên thư mục lỗi do 1 lần nén zip trước bị lỗi brace-expansion trong lệnh
`mkdir`, thư mục rỗng, không phải code) — không ảnh hưởng app chạy, chỉ là
rác trong cây thư mục nguồn.

### 34.7. Cập nhật cùng ngày — hoàn thiện `GithubBuildService` (gỡ dead-code + audit dependency)

Sau khi rà soát (34.6) phát hiện `lib/services/github_build_service.dart` là
file DUY NHẤT không được import ở đâu — nhưng đây là tính năng đã ghi trong
mục 6/8 ("code service đã xong, CHƯA có UI"), không phải rác. Theo yêu cầu,
đã hoàn thiện luôn thay vì xoá:

- **Gắn UI**: thêm "Cách 3 — Tự động build APK qua GitHub Actions" ngay
  trong `ZipEditScreen` (dùng lại đúng `_allFiles`/`_selectedPaths` đã có,
  không cần màn hình riêng). Có dialog cấu hình (token/owner/repo/branch/
  tên file workflow, lưu Hive qua `StorageService.github*`) + dialog XÁC
  NHẬN trước khi chạy (vì đây là hành động tạo commit thật lên repo người
  dùng — không tự động chạy ngầm không hỏi).
- **Sửa 1 bug thật trong `github_build_service.dart`**: `fetchRunLog()`
  trước đó decode thẳng bytes .zip thành text (GitHub LUÔN trả log dạng
  .zip chứa nhiều `.txt`) — ra ký tự vô nghĩa, khiến bước "AI tự đọc log
  sửa lỗi" nhận log rác. Đã sửa dùng `archive` giải nén rồi gộp đúng nội
  dung `.txt`.
- **Thêm `extractApkFromArtifactZip()`**: GitHub Actions luôn bọc artifact
  trong 1 lớp .zip ngoài — hàm mới mở lớp đó, lấy đúng file `.apk` (ưu tiên
  file `.apk` lớn nhất nếu có nhiều) để đưa thẳng cho `FileSaver`.
- `StorageService`: thêm `githubToken/githubOwner/githubRepo/githubBranch/
  githubWorkflowFile/githubConfigured` — cùng pattern key-value trong box
  "settings" như `secretaryProviderId`/`imageGenProviderId` đã có.

**Dependency audit (pubspec.yaml)** — đối chiếu từng package khai báo với
import thực tế trong `lib/`, gỡ 3 package khai báo nhưng 0 chỗ dùng:
`cupertino_icons` (không dùng `CupertinoIcons` ở đâu), `intl` (không dùng
`DateFormat`/`Intl.` — ngày giờ trong app tự format bằng
`DateTime.now()`/`millisecondsSinceEpoch` thủ công), `xml` (các file OOXML
tự dựng bằng `StringBuffer` viết thẳng XML, không qua package `xml`). Đã
`grep` xác nhận thật (không đoán) trước khi xoá — xem lệnh cụ thể nếu cần
lặp lại: `grep -rn "package:<tên>/" lib --include="*.dart"`.

**CHƯA kiểm chứng** (giống mọi phần khác của dự án — không có Flutter SDK ở
môi trường viết code): UI mới trong `ZipEditScreen` chưa build/chạy thử
thật; logic `extractApkFromArtifactZip` dựa trên hiểu biết chuẩn về cách
GitHub Actions đóng gói artifact (đã dùng đúng), nhưng CHƯA test với 1
artifact thật tải về.

### 34.8. Sửa cùng ngày — AI là TUỲ CHỌN cho auto-build, không phải bắt buộc

Người dùng hỏi đúng điểm bất hợp lý: bản đầu bắt buộc phải có Provider AI
mới cho chạy auto-build, dù AI chỉ thật sự cần khi build LỖI. Đã sửa:

- `GithubBuildService.applyAndBuildUntilSuccess()`: `aiApiService`/
  `aiProvider` đổi từ `required` → nullable/tuỳ chọn. Nếu build thành công
  ngay (ví dụ code đã hoàn chỉnh, do nơi khác xuất ra) → KHÔNG đụng tới AI,
  0 token. Nếu lỗi mà không có AI cấu hình → dừng ngay lần lỗi đầu, trả log
  cho người dùng tự đọc thay vì báo lỗi chặn không cho build.
- `ZipEditScreen._runAutoBuild()`: bỏ điều kiện chặn "phải có Provider mới
  cho build" — giờ chỉ cảnh báo trong dialog xác nhận rằng build lỗi sẽ
  không tự sửa được nếu chưa cấu hình AI, không còn CHẶN hẳn.

### 34.9. Làm rõ hiểu nhầm — Python sandbox KHÔNG thay thế JSON DSL/OOXML

Người dùng hỏi liệu `docx_export.dart`/`pptx_export.dart`/`xlsx_export.dart`
(dựng XML OOXML bằng `StringBuffer`) có còn cần thiết không khi đã có
Python sandbox — CÂU TRẢ LỜI: CÓ, vẫn cần, KHÔNG xoá. Lý do: Python sandbox
(Tier 2) cố tình không có mạng nên không cài được `python-docx`/`openpyxl`/
`python-pptx` — những thư viện THẬT SỰ biết viết định dạng .docx/.pptx/
.xlsx. Python trong sandbox chỉ tính toán ra DỮ LIỆU (bảng số, text, hoặc
ảnh PNG nếu tự encode bằng `zlib` — hiếm khi khả thi) rồi nạp vào khối JSON
DSL; việc đóng gói zip + viết đúng cấu trúc XML OOXML thành file mở được
bằng Word/Excel/PowerPoint vẫn hoàn toàn do 3 file exporter này đảm nhiệm.
Xoá chúng = mất hẳn khả năng xuất file, không có gì thay thế được.

## 34. Cập nhật 31/07/2026 — Bỏ FAB to che WebView, gộp icon lên AppBar

Người dùng phản hồi: `FloatingActionButton.extended` "Trích xuất nội dung
trang" quá to, đè lên vùng thao tác của WebView.

**Đã sửa** `webview_capture_screen.dart`:
- Bỏ hẳn `floatingActionButton`.
- Nút trích xuất chính (hay dùng nhất) chuyển thành `IconButton` nhỏ, đặt
  ĐẦU TIÊN trong AppBar actions.
- 3 icon ít dùng hơn (đọc chữ canvas / OCR / cuộn & gom) gộp vào 1
  `PopupMenuButton` "Cách trích xuất khác" — giảm từ 6 icon rời xuống còn 4
  (trích xuất chính, menu công cụ khác, dán nội dung, tải lại), tránh
  AppBar bị chật trên màn hình nhỏ.

## 35. FIX bug thật (01/08/2026) — thư mục mới tạo biến mất ngay lập tức

Người dùng báo: "tạo thư mục xong chả thấy thư mục nào cả". Đây là BUG
THẬT có sẵn từ TRƯỚC khi tôi tham gia (không liên quan tới các tính năng
WebView/export đã làm) — đã tìm ra chính xác trong
`lib/screens/home/conversation_drawer.dart`, hàm `_folderSection`:

```dart
if (convs.isEmpty && folderId != null) return const SizedBox.shrink();
```

Dòng này ẩn thư mục nếu nó KHÔNG có đoạn chat nào bên trong. Nhưng thư mục
MỚI TẠO thì LUÔN rỗng (chưa kịp thêm gì) — nên nó bị ẩn NGAY LẬP TỨC sau
khi tạo, đúng như người dùng mô tả. Không có cách nào truy cập lại thư mục
đó nữa vì nó không hiện ra để bấm vào.

**Đã sửa:**
- Bỏ hẳn điều kiện ẩn thư mục rỗng.
- Thư mục rỗng giờ hiện ra bình thường, kèm dòng chữ xám nhỏ "(Thư mục
  trống — bấm + để tạo đoạn chat mới ở đây)".
- Thêm nút "+" trên mỗi thư mục (bên cạnh mũi tên mở/thu gọn, không thay
  thế nó) — tạo đoạn chat mới NGAY TRONG thư mục đó (`chat.createConversation
  (folderId: folderId)`), giải quyết luôn vấn đề gốc: trước đây thư mục chỉ
  gán được lúc TẠO đoạn chat (`createConversation({folderId})`), không có
  cách nào tạo chat mới trực tiếp từ trong màn hình thư mục.

## Về câu hỏi "icon trích xuất chưa sửa" — không phải bug, cần xác nhận đã build bản mới
Ảnh chụp màn hình cho thấy 1 bong bóng tooltip nổi lên gần vị trí 1 icon,
kèm đúng text "Trích xuất nội dung trang" — đây RẤT GIỐNG hành vi tooltip
CHUẨN của Android/Flutter (tự hiện khi NHẤN GIỮ 1 IconButton có thuộc tính
`tooltip:`), không phải FAB cũ còn sót (FAB đã bị bỏ hẳn ở mục 34). Đã nhắc
người dùng xác nhận có build lại + cài APK MỚI trước khi kết luận đây là
lỗi chưa sửa hay chỉlà chưa cập nhật bản build.

## 35. Cập nhật 04/08/2026 — Cho phép tự cài thư viện Python (.whl) + build thủ công qua AI khác

Người dùng đặt câu hỏi rất đúng: sandbox Python (Tier 2, mục 34) mặc định
chỉ có thư viện chuẩn — nếu không có chỗ để cài thêm, sandbox gần như vô
dụng cho việc thao tác tài liệu thật (docx/xlsx/epub...) vì các thư viện
biết làm việc đó (`openpyxl`, `python-docx`...) không có sẵn. Đã tra cứu và
xác nhận `micropip.install("emfs:/đường/dẫn.whl")` là API THẬT của Pyodide
— cài từ file đã có sẵn trong bộ nhớ ảo, KHÔNG cần mạng — nên xây hẳn tính
năng cho người dùng tự upload `.whl`.

### 35.1. File mới/sửa — cài thư viện `.whl`

- `lib/services/python_wheel_manager.dart` (MỚI): lưu vĩnh viễn các file
  `.whl` người dùng upload vào `<app_docs>/python_wheels/` (dùng
  `path_provider`, đã có sẵn dependency). List/add/remove.
- `assets/sandbox/sandbox.html`: thêm `window.__installWheel(id, fileName,
  base64)` — ghi bytes vào `pyodide.FS` tại `/wheels/<fileName>` rồi
  `micropip.install("emfs:/wheels/<fileName>")`. `ensurePyodide()` giờ tự
  `loadPackage('micropip')` (gói lõi nhỏ, đọc từ `indexURL` local, không
  phải CDN — đã xác nhận qua tài liệu Pyodide, không đoán).
- `lib/services/python_sandbox_service.dart`: thêm `installWheel()` (gọi
  khi vừa upload, cài ngay) + `_autoInstallStoredWheels()` (tự cài lại toàn
  bộ wheel đã lưu mỗi khi sandbox khởi tạo mới — vì WebView là phiên mới
  hoàn toàn mỗi lần app mở lại, không tự nhớ gì). Lỗi cài 1 wheel không làm
  hỏng cả sandbox, chỉ ghi vào `lastWheelInstallErrors`.
- `lib/screens/settings/python_libraries_screen.dart` (MỚI): màn hình
  upload/xem danh sách/xoá `.whl`, gắn vào `conversation_drawer.dart`.
- `secretary_prompt_builder.dart`: sửa `_pythonBlockGuide()` — không còn
  khẳng định tuyệt đối "không thư viện ngoài", mà dạy AI cứ `import` thử,
  gặp `ImportError` thì biết là chưa được cài, KHÔNG đoán bừa gói nào có
  sẵn (vì danh sách phụ thuộc hoàn toàn vào người dùng đã upload gì).

**Giới hạn thành thật (đã ghi rõ trong code, không giấu):** upload `.whl`
KHÔNG đảm bảo chạy được — gói có phần biên dịch C/Rust (numpy thường, lxml
mà `python-docx`/`ebooklib` phụ thuộc...) chỉ chạy được nếu đúng là bản
build riêng cho `wasm32-emscripten` (khác hẳn bản tải từ PyPI cho Windows/
Linux/macOS bình thường) — gói THUẦN Python (`openpyxl` là ví dụ điển hình,
không có phần C) thì luôn cài được bất kể tải từ đâu. Đây không phải giới
hạn của app mà là giới hạn vật lý của việc chạy code biên dịch sẵn cho 1
kiến trúc CPU khác trong trình duyệt.

### 35.2. File mới/sửa — build thủ công qua AI khác (trả lời câu hỏi về workflow tự build)

Người dùng mô tả đúng 1 quy trình: khung chat sinh code → đóng zip → tự
build GitHub → lỗi → log tự đưa lại vào khung chat → bên kia sửa tiếp → lặp
lại tới khi thành công — và hỏi có prompt nào để "bên kia" (khi chỉ xuất
được text, không tự xuất zip) biết cách trả lời đúng cấu trúc để app gộp
lại được không. CÓ — prompt đó đã tồn tại sẵn
(`CodeZipExporter.formatInstructionPrompt`, dùng ở "Cách 2" từ trước), chỉ
là chưa được nối vào luồng auto-build. Đã sửa `zip_edit_screen.dart`:

- "Cách 3" giờ hỏi chọn chế độ trước khi chạy: **(A) App tự sửa qua API**
  (như mục 34, giờ AI là tuỳ chọn — mục 34.8) hoặc **(B) Thủ công qua AI
  khác** (MỚI).
- Chế độ B (`_runAutoBuildManualRelay`): mỗi vòng lỗi, app tự
  `Clipboard.setData` sẵn (log lỗi đã cắt bớt + đúng
  `CodeZipExporter.formatInstructionPrompt` + toàn bộ code hiện tại theo
  `CodeZipExporter.formatForSharing`) — người dùng tự dán sang AI khác
  (ChatGPT/Claude.ai/Gemini web...), đợi trả lời, dán NGƯỢC kết quả vào ô
  trong dialog; app tự `CodeZipExporter.extractFiles` + merge + đẩy lại +
  build lại, lặp tới khi thành công hoặc người dùng bấm "Dừng lại". Giới
  hạn 10 vòng để tránh lặp vô hạn nếu người dùng cứ dán sai định dạng.
  KHÔNG tốn 1 token API nào của app trong suốt chế độ này (khớp đúng ý
  người dùng: "chỉ cần bên kia xuất code là tự build", không bắt buộc có
  model AI trong app).

### 35.3. CHƯA kiểm chứng (như mọi phần khác — không có Flutter SDK/thiết bị thật)

`pyodide.FS.mkdir`/`pyodide.FS.writeFile`/`pyodide.pyimport('micropip')` +
`micropip.install("emfs:...")` đã tra đúng tài liệu chính thức, nhưng CHƯA
chạy thử thật với 1 file `.whl` thật trên thiết bị Android thật. Nếu gặp
lỗi cụ thể khi test, gửi nguyên văn để sửa đúng chỗ.

## 36. Cập nhật 04/08/2026 — thêm định dạng MỚI qua "module Python cố định", không hardcode Dart nữa

Người dùng hỏi đúng: đã có sandbox Python (mục 34/35) rồi thì sao còn phải
viết riêng 1 file Dart (`docx_export.dart` kiểu) cho mỗi định dạng mới? Câu
trả lời: **không cần nữa** — nhưng KHÔNG để AI tự viết code zip/XML từ đầu
mỗi lần chat (dễ sai, ra file hỏng). Giải pháp: viết 1 **module Python cố
định** (đúng 1 lần, y hệt tinh thần "code Dart hardcode" nhưng bằng Python,
chạy qua sandbox có sẵn) — AI chỉ cần sinh DỮ LIỆU (JSON), không cần viết
lại logic đóng gói.

### 36.1. File mới/sửa

- `lib/services/python_builtin_modules.dart` (MỚI): chứa `epubMinPySource`
  — mã nguồn Python CỐ ĐỊNH (chỉ dùng `zipfile`/`io`/`html` chuẩn, không cần
  cài `.whl` nào) build ra `.epub` (EPUB2, tương thích rộng) từ dict
  `{"title","author","chapters":[{"title","paragraphs":[...]}]}`.
- `lib/services/export/dsl_document_builder.dart`: thêm `buildEpub()` — ghép
  JSON DSL (do AI sinh) + `epubMinPySource` (cố định) thành 1 đoạn code,
  chạy qua [PythonSandboxService] ĐÃ CÓ SẴN (không sửa gì ở
  `python_sandbox_service.dart`/`sandbox.html` — đúng ý "chỉ cần add thư
  viện/driver là được", không cần đụng hạ tầng).
- `lib/widgets/export_runner.dart` + `lib/screens/sources/source_documents_screen.dart`:
  thêm `case 'txt'` (KHÔNG qua sandbox/JSON gì cả — `.txt` chỉ là
  `utf8.encode(content)` thẳng, vì bản thân nó không cần "render") và
  `case 'epub'` (gọi `buildEpub`).
- `lib/widgets/export_menu.dart` + `source_documents_screen.dart`: thêm 2
  lựa chọn UI "Văn bản (.txt)" / "Sách điện tử (.epub)".
- `secretary_prompt_builder.dart`: thêm `formatInstruction` cho `'txt'`
  (trả lời văn bản thường) và `'epub'` (schema JSON title/chapters).

### 36.2. Quy tắc từ nay khi cần thêm 1 định dạng file MỚI

KHÔNG viết thêm class Dart kiểu `xxx_export.dart` nữa (trừ khi có lý do đặc
biệt, ví dụ định dạng cần thao tác binary phức tạp mà Python/Pyodide làm
chậm). Thay vào đó:
1. Nếu định dạng chỉ là text thuần (không cấu trúc) → không cần gì cả,
   `utf8.encode` thẳng như `.txt`.
2. Nếu định dạng có cấu trúc (zip+XML như epub, hoặc bất kỳ thứ gì Python
   thư viện chuẩn làm được) → viết 1 hằng số Python cố định trong
   `python_builtin_modules.dart` (như `epubMinPySource`), thêm 1 hàm
   `buildXxx()` trong `dsl_document_builder.dart` gọi qua
   `PythonSandboxService.instance.run()` — TÁI DÙNG nguyên hạ tầng sandbox
   đã có, không sửa `sandbox.html`/`python_sandbox_service.dart`.
3. Nếu định dạng cần thư viện có phần biên dịch C không có sẵn trong
   Pyodide-core → hướng dẫn người dùng upload đúng bản `.whl` build cho
   `wasm32-emscripten` qua màn hình "Thư viện Python cho sandbox" (mục 35),
   hoặc dùng Tier 3 (nhờ AI khác có hạ tầng thật).
4. Thêm case trong `export_runner.dart`/`source_documents_screen.dart` +
   `secretary_prompt_builder.dart` (dạy AI schema JSON) + UI chọn định dạng.

### 36.3. CHƯA kiểm chứng

`epubMinPySource` viết đúng theo hiểu biết chuẩn về cấu trúc EPUB2 (mimetype
không nén ở entry đầu + container.xml + content.opf + toc.ncx), nhưng CHƯA
mở thử bằng 1 trình đọc epub thật (không có môi trường để test). Nếu gặp
lỗi "file epub hỏng/không mở được" khi test thật, gửi lại nguyên văn lỗi +
tên app đọc epub đã dùng để sửa đúng chỗ.

## 37. Cập nhật 04/08/2026 — khắc phục 2 giới hạn tự nhiên của "build thủ công qua AI khác" (mục 35.2)

Người dùng hỏi có khắc phục được không — CÓ, cả 2:

### 37.1. Soi lỗi cú pháp thô TRƯỚC KHI đẩy GitHub

- `lib/utils/quick_syntax_check.dart` (MỚI): `QuickSyntaxCheck.check(files)`
  — KHÔNG phải trình biên dịch thật (app không có Dart/Flutter SDK), chỉ
  đếm cân bằng `{}`/`()`/`[]`/dấu nháy (bỏ qua thô phần sau `//`), và với
  `.json` thì parse thật bằng `dart:convert` (chính xác 100%, không đoán).
  Cố ý CÓ THỂ báo nhầm (ví dụ raw string chứa nháy lẻ) — luôn cho người
  dùng chọn "vẫn đẩy lên" chứ không chặn cứng.
- Gắn vào `_runAutoBuildManualRelay`: hiện cảnh báo ngay trong dialog xác
  nhận trước mỗi lần push — tránh tốn 1 vòng build GitHub (vài phút) chỉ để
  phát hiện lỗi thiếu ngoặc mà đáng lẽ biết ngay từ trước.

### 37.2. Không gửi lại TOÀN BỘ code mỗi vòng nữa

- Vòng 1: vẫn gửi đầy đủ (bắt buộc, AI ngoài chưa có gì để dựa vào).
- Vòng ≥2: tự dò trong log lỗi xem có tên file nào trong `files` xuất hiện
  không (`log.contains(path)`) — nếu có, CHỈ gửi đầy đủ đúng những file đó,
  file còn lại chỉ liệt kê TÊN (không nội dung). Nếu không dò được file nào
  khớp (log không có đường dẫn rõ ràng) → rơi về gửi đầy đủ như cũ (an
  toàn, không thoái lui so với trước).
- Thêm giao thức 1 dòng `SHOW_FILE: đường/dẫn` — nếu AI bên ngoài thấy cần
  xem thêm 1 file KHÔNG có trong danh sách rút gọn, chỉ cần trả lời đúng 1
  dòng đó (không kèm gì khác); app tự nhận diện, gửi lại nội dung file được
  hỏi, hỏi lại lần nữa — KHÔNG tính là 1 vòng build, không đẩy/không tốn
  phút GitHub Actions nào cho bước xin thêm file này.

### 37.3. CHƯA kiểm chứng

Cả 2 phần trên là logic Dart thuần (không đụng sandbox/WebView), rủi ro
thấp hơn các mục trước, nhưng vẫn CHƯA chạy thử thật (không có Flutter SDK
ở môi trường viết code) — đặc biệt là promotion kiểu dữ liệu `String?` →
`String` qua vòng lặp `while (showFileMatch != null)` trong
`zip_edit_screen.dart` (logic đúng theo suy luận, nhưng trình phân tích
Dart thật có thể khó tính hơn — nếu `flutter analyze` báo lỗi kiểu dữ liệu
ở đúng đoạn này, gửi lại nguyên văn để sửa).

## 38. Cập nhật 05/08/2026 — sửa 2 lỗ hổng người dùng phát hiện: sandbox Python bị khoá trong luồng tài liệu, và Tier 3 không cảnh báo điều kiện tiên quyết

Người dùng hỏi đúng 2 điểm: (1) cách tối ưu token hiện tại (sandbox Python
Tier 2) có phủ được MỌI việc Python làm được không, hay chỉ file tài liệu;
(2) nút Tier 3 "nhờ bên kia tự chạy Python" có tính đến trường hợp "bên kia"
chỉ là 1 khung chat không tự chạy được code — lúc đó nút vô dụng — hay
chưa. Kiểm tra code xác nhận ĐÚNG cả 2 là lỗ hổng thật, đã sửa cả 2:

### 38.1. Mở sandbox Python cho MỌI tin nhắn chat, không chỉ luồng xuất tài liệu

Trước đây `PythonSandboxService.instance.run()` (đã có sẵn, hoạt động tốt)
CHỈ được gọi từ `dsl_document_builder.dart` — không có nơi nào trong màn
hình chat bình thường cho phép "chạy thử 1 đoạn Python" cho việc khác ngoài
xuất tài liệu, dù bản thân sandbox hoàn toàn làm được (mọi thứ dùng thư viện
chuẩn Python + wheel đã cài thêm, xem mục 34/35).

- `lib/widgets/runnable_code_block.dart` (MỚI): `RunnableCodeBlockBuilder`
  — 1 `MarkdownElementBuilder` gắn vào tag `pre` (khối code fenced
  ` ```lang ` trong markdown, KHÔNG phải `code` inline trong câu văn — cố ý
  tách để không đụng code inline). Nếu ngôn ngữ khai báo là `python`/`py` →
  vẽ thêm nút ▶ gọi thẳng `PythonSandboxService.instance.run()` (TÁI DÙNG
  nguyên hạ tầng Tier 2 đã có, không sửa `sandbox.html`/service), hiện
  stdout/stderr/error ngay dưới khối code, có nút copy từng phần. Ngôn ngữ
  khác vẫn hiển thị y hệt trước (chỉ code, không nút — không đổi hành vi).
- `lib/widgets/message_bubble.dart`: thêm `builders: {'pre':
  RunnableCodeBlockBuilder()}` vào `MarkdownBody` hiện có — áp dụng cho MỌI
  tin nhắn (user lẫn assistant, mọi đoạn chat, kể cả thảo luận nhóm nhiều
  model) vì đây là nơi DUY NHẤT mọi tin nhắn đi qua để render markdown.
- `pubspec.yaml`: khai báo tường minh `markdown: ^7.2.2` (trước đó chỉ là
  dependency gián tiếp qua `flutter_markdown`, cần import trực tiếp
  `package:markdown/markdown.dart` để thao tác `Element`/tag).
- Giới hạn/an toàn KHÔNG đổi so với Tier 2 cũ: vẫn sandbox cô lập không
  mạng, vẫn timeout 20s, vẫn giới hạn kích cỡ code/output — chỉ mở rộng NƠI
  được phép gọi, không nới ranh giới an toàn.
- Trả lời thẳng câu hỏi gốc: bao phủ được MỌI việc mà sandbox Python (thư
  viện chuẩn + wheel đã cài) làm được, cho MỌI tin nhắn chat — không chỉ
  file tài liệu nữa. Việc cần thư viện ngoài không cài được (C-extension
  không đúng bản wasm32) hoặc cần mạng thì vẫn ngoài khả năng Tier 2, dùng
  Tier 3 (mục dưới) hoặc JSON tĩnh Tier 1.

### 38.2. Tier 3 hỏi xác nhận điều kiện tiên quyết TRƯỚC khi copy, không chỉ ghi chú SAU

Nút "Tier 3: nhờ bên kia tự chạy Python" trước đây bấm là copy prompt ngay,
chỉ ghi tên vài AI cụ thể (Claude.ai/ChatGPT/Colab) trong snackbar HIỆN
**SAU** khi đã copy — người dùng dễ đọc lướt, dán prompt vào 1 khung chat
KHÔNG tự chạy được code (kể cả chính app này) rồi mới biết vô dụng, vì bên
nhận chỉ có thể đưa lại code cho người dùng — mà người dùng thì không có
sẵn môi trường Python (đúng vấn đề ban đầu người dùng nêu).

- `lib/screens/sources/source_documents_screen.dart`
  (`_CompileSheetState._confirmAndCopyTier3`, MỚI): bấm nút giờ mở
  `AlertDialog` hỏi thẳng "bạn có chắc nơi sắp dán vào TỰ CHẠY được code
  không", liệt kê rõ ví dụ ĐÚNG (Claude.ai có bật code execution, ChatGPT
  bản có Code Interpreter, Colab) và nói thẳng trường hợp SAI (khung chat
  thường, kể cả app này) khiến nút vô dụng — kèm gợi ý lối thoát (JSON tĩnh
  Tier 1, hoặc sandbox Tier 2 mới ở mục 38.1 nếu việc đủ đơn giản). Chỉ khi
  người dùng bấm "Có, tiếp tục copy" mới thực sự `Clipboard.setData`.
- Không đổi nội dung `SecretaryPromptBuilder.tier3PythonPrompt` (bản thân
  prompt đã đúng, chỉ thiếu bước xác nhận trước khi dùng).

### 38.3. CHƯA kiểm chứng (như mọi phần khác — không có Flutter SDK/thiết bị thật)

- `MarkdownElementBuilder.visitElementAfterWithContext` + `isBlockElement()`
  đúng theo tài liệu/API `flutter_markdown` ^0.7.3 đã biết, nhưng CHƯA chạy
  thử thật để xác nhận khối ```python ``` render đúng nút ▶ và không vỡ
  layout khi lồng trong `MarkdownBody(selectable: true)`. Nếu build lỗi ở
  đúng chỗ này (ví dụ đổi tên phương thức giữa các bản `flutter_markdown`),
  gửi lại nguyên văn lỗi `flutter analyze`/build để sửa đúng chỗ.
- Version `markdown: ^7.2.2` chọn theo hiểu biết về dependency của
  `flutter_markdown` ^0.7.3 tại thời điểm viết, KHÔNG tra được qua mạng (môi
  trường không có mạng) — nếu `flutter pub get` báo version conflict, xoá
  dòng khai báo `markdown:` tường minh trong `pubspec.yaml` (để nó tự lấy
  bản gián tiếp đúng mà `flutter_markdown` cần) rồi thử lại.

## 39. Cập nhật 05/08/2026 — rà soát 3 yêu cầu gốc + vá 2 lỗ hổng phát hiện thêm

Người dùng yêu cầu rà soát lại, không chỉ hỏi lý thuyết:
1. File build + gốc thư mục để build trên GitHub.
2. Có THẬT SỰ đúng ý "AI phía bên kia (web chat thường, KHÔNG có tool như
   Claude.ai) vẫn nhờ được app này thực hiện tác vụ xuất file" không, hay
   chỉ đúng trên lý thuyết.
3. Sandbox Python đã tổng quát hoá thật chưa: thêm được BẤT KỲ thư viện
   nào chưa, chạy được BẤT KỲ đoạn code nào bên kia đưa chưa.

### 39.1. File build + gốc thư mục — ĐÃ CÓ SẴN, xác nhận lại cách dùng

`.github/workflows/build_apk.yml` (đã có trong zip từ trước, KHÔNG đổi gì
lần này) đã xử lý đúng ý "gốc thư mục" theo 2 cách, người dùng chọn 1:

- **Cách A (khuyên dùng, đỡ thao tác nhất)**: đẩy THẲNG file
  `ai_chat_app_source.zip` (không cần tự giải nén) lên gốc repo GitHub —
  bước đầu tiên của workflow (`Tự giải nén nếu người dùng chỉ upload file
  .zip`) tự tìm, tự giải nén, tự đưa `lib/`, `pubspec.yaml`,
  `.github/workflows/`, `assets/` lên đúng gốc repo trước khi build.
- **Cách B**: tự giải nén trên máy trước, rồi đẩy nguyên nội dung ĐÃ GIẢI
  NÉN (không phải cả file .zip lẫn thư mục cha bọc ngoài) lên gốc repo —
  tức là `pubspec.yaml` phải nằm NGAY gốc repo (`your-repo/pubspec.yaml`),
  không phải `your-repo/ai_chat_app_source/pubspec.yaml`.

Cả 2 cách, workflow tự lo: sinh `android/` (chưa có sẵn trong zip vì môi
trường viết code không có Flutter SDK), tải Pyodide, vá các lỗi Gradle đã
gặp trước đó (xem lịch sử mục 20-34). Chỉ cần bấm "Actions" → chờ workflow
chạy xong → tải APK ở mục "Artifacts" của lần chạy đó.

File `build_apk.yml` cũng được gửi RIÊNG (ngoài trong zip) ở lần trả lời
này để dễ xem trước khi đẩy lên, nhưng đây CHÍNH XÁC là bản trong zip —
không có bản nào khác/mới hơn. (File `build_apk_yml_NOI_DUNG.txt` người
dùng từng gửi kèm là bản CŨ hơn, thiếu bước tải Pyodide — dùng bản trong
zip lần này, đừng dùng lại file .txt cũ đó.)

### 39.2. Xác nhận thật: AI không tool vẫn xuất được file — nhưng phát hiện 1 lỗ hổng thật, đã vá

Kiểm tra lại toàn bộ đường đi (không chỉ đọc code mà lần theo từng bước):

- **Tier 1 (JSON DSL)** — `DslDocumentBuilder`/`DocxExporter`/`PptxExporter`/
  `XlsxExporter` chạy HOÀN TOÀN trong Dart, phía app. AI chỉ cần trả lời
  ĐÚNG cú pháp JSON/markdown quy định bằng VĂN BẢN THUẦN — không cần bất kỳ
  tool/function-calling/code-execution nào phía AI. Đây là điều làm được
  với MỌI model, kể cả model yếu nhất chỉ biết trả lời chữ. **Xác nhận:
  đúng như thiết kế, hoạt động độc lập với khả năng của AI.**
- **Lỗ hổng phát hiện**: luồng "thư ký AI" (`source_documents_screen.dart`)
  đã có nút "Copy prompt định dạng" để báo AI trả lời đúng JSON TRƯỚC khi
  hỏi — nhưng luồng xuất file THÔNG THƯỜNG từ 1 tin nhắn chat bất kỳ
  (`ExportMenu`, nút 📤 trong màn hình chat) thì KHÔNG có bước mồi này —
  chỉ export SAU KHI AI đã trả lời, và nếu AI (nhất là model không "quen"
  định dạng JSON DSL) trả lời văn xuôi bình thường thì rơi vào nhánh dự
  phòng rút gọn (`DocxExporter`/`PptxExporter`/`XlsxExporter` cũ, chỉ hiểu
  markdown/bảng `|` đơn giản — MẤT bảng thật/ảnh/biểu đồ/mục lục/công
  thức Excel). Tức là tính năng ĐÚNG về mặt kỹ thuật (không cần AI có
  tool) nhưng THIẾU 1 bước hướng dẫn khiến chất lượng thực tế phụ thuộc
  may rủi vào việc model có tự nhiên trả lời đúng khuôn hay không.
- **Đã sửa** — `lib/widgets/export_menu.dart`: mỗi dòng định dạng giờ có
  thêm nút 💡 "Copy hướng dẫn định dạng", TÁI DÙNG đúng
  `SecretaryPromptBuilder.formatInstruction()` đã có sẵn (không viết lại
  logic) — bấm để copy, dán vào ĐẦU câu hỏi tiếp theo, để AI trả lời sẵn
  đúng khuôn giàu định dạng ngay từ đầu, không cần đợi export xong mới biết
  thiếu. Có thêm dòng giải thích ngắn ở đầu bottom sheet nói rõ AI không
  cần tool gì, chỉ cần đúng cú pháp.
- **Tier 2 (sandbox)**: cũng không cần AI có tool — AI chỉ cần in code
  Python dạng văn bản trong khối ` ```python `, APP tự chạy (xem mục 38).
- Trả lời thẳng câu hỏi gốc: ĐÚNG, đã xác nhận thật (không chỉ lý thuyết) —
  với điều kiện dùng nút 💡 mới để mồi định dạng trước, hoặc cứ hỏi bình
  thường và chấp nhận bản rút gọn khi model không tự theo đúng JSON.

### 39.3. Sandbox Python tổng quát hoá tới đâu — trả lời thành thật, không phóng đại

**Chạy BẤT KỲ đoạn code nào bên kia đưa**: ĐÚNG, đã tổng quát hoá đủ (từ
mục 38) — nút ▶ ở MỌI khối ` ```python ` trong MỌI tin nhắn chat, không
giới hạn phải đến từ luồng xuất tài liệu. Giới hạn CÒN LẠI không phải do
app cố ý chặn, mà do bản chất WASM/sandbox cô lập (không thể gỡ mà không
phá vỡ mô hình an toàn cố ý):
- Không có mạng lúc code CHẠY (đúng ý đồ ban đầu — nếu code cố `requests.get`
  sẽ lỗi rõ ràng, không phải treo im lặng).
- Timeout cứng 20s, giới hạn kích cỡ code/output (chống 1 đoạn code lỗi/ác
  ý làm app treo/hết bộ nhớ).
- Không đọc được API key/dữ liệu Hive/file thật của app (ranh giới an toàn
  cố ý, xem `python_sandbox_service.dart`).
Trong phạm vi đó, CHẠY ĐƯỢC bất kỳ code Python hợp lệ nào dùng thư viện
chuẩn hoặc đã cài thêm.

**Thêm BẤT KỲ thư viện nào**: TRƯỚC lần trả lời này chỉ làm được 1 nửa —
chỉ hỗ trợ upload file `.whl` THỦ CÔNG (tự tải bằng máy tính, tự chuyển vào
điện thoại) — không có cách nào "thêm nhanh" hơn. Đã bổ sung thêm cách 2:

- `lib/screens/settings/python_libraries_screen.dart`: thêm nút "Cài từ
  URL" — dán link tải trực tiếp 1 file `.whl` (vd trang PyPI của gói, mục
  "Download files"), APP TỰ TẢI (bằng tiến trình chính, vốn đã có mạng để
  gọi API model — KHÔNG phải sandbox tự tải, không đụng ranh giới "sandbox
  không mạng lúc CHẠY code") rồi đưa bytes vào pipeline cài y hệt upload
  thủ công. Đỡ hẳn bước tải bằng máy tính + chuyển file qua điện thoại.
- Dùng `http` package đã có sẵn (không thêm dependency mới).
- **NHƯNG vẫn KHÔNG PHẢI "thêm được mọi thư viện" theo đúng nghĩa đen** —
  đây là giới hạn vật lý, không phải app thiếu tính năng: gói THUẦN Python
  (không phần biên dịch C/Rust — vd `openpyxl`, phần lớn gói xử lý
  văn bản/JSON/toán học thuần) luôn cài được dù tải từ đâu. Gói CÓ phần
  biên dịch (numpy, pandas, lxml, Pillow bản đầy đủ...) CHỈ cài được nếu
  đúng là bản `.whl` build RIÊNG cho kiến trúc `wasm32-emscripten` — khác
  hẳn bản `.whl` thường tải từ PyPI cho Windows/Linux/macOS. Không phải
  mọi gói đều có sẵn bản build wasm32 (tuỳ dự án nguồn có publish hay
  không) — nếu không có, KHÔNG có cách nào lách qua được trong 1 sandbox
  WASM cô lập, kể cả tải "đúng cách" cũng vô ích vì bản build không tồn
  tại. Khi gặp trường hợp này, dùng Tier 3 (nhờ AI khác chạy trên hạ tầng
  thật của họ) thay vì cố trong Tier 2.

### 39.4. CHƯA kiểm chứng

- Nút "Cài từ URL" dùng `http.get` với `Uri.tryParse` + kiểm tra scheme
  http/https — CHƯA test thật với 1 link PyPI thật (môi trường viết code
  không có mạng). Một số CDN có thể trả lỗi 403 nếu thiếu User-Agent —
  nếu gặp, cần thêm header `User-Agent` giả trình duyệt vào request.
- Nút 💡 "Copy hướng dẫn định dạng" ở `ExportMenu` — logic đơn giản
  (Clipboard + SnackBar), rủi ro thấp, nhưng CHƯA chạy thử UI thật để xác
  nhận `trailing` IconButton không bị `ListTile` cắt/chồng layout ở màn
  hình nhỏ.

## 40. Cập nhật 05/08/2026 — 2 lỗi build THẬT từ log GitHub Actions (Build APK #2, FAILED) — đã sửa, có bằng chứng cụ thể lần đầu tiên

Đây là lần ĐẦU TIÊN có log build thật (không phải suy luận "CHƯA kiểm chứng"
nữa) — người dùng gửi nguyên văn log lỗi từ Actions. `flutter build apk
--release` fail ở bước biên dịch Dart (kernel_snapshot_program), đúng 2 lỗi
kiểu dữ liệu:

```
lib/screens/code/zip_edit_screen.dart:497:54: Error: The argument type
'String?' can't be assigned to the parameter type 'String'.
lib/services/export/dsl_document_builder.dart:70:52: Error: The argument
type 'Map<dynamic, dynamic>' can't be assigned to the parameter type
'Map<String, dynamic>'.
```

Cả 2 ĐÚNG như đã cảnh báo trước ở mục 37.3/38.3 ("CHƯA kiểm chứng, có thể
sai kiểu dữ liệu") — giờ có bằng chứng thật, đã sửa cả 2:

### 40.1. `zip_edit_screen.dart:497` — biến `pasted` bị gán lại trong vòng `while`, phân tích Dart không tự thăng hạng non-null qua lần gán lại đó

`var pasted` khai báo kiểu suy ra `String?`. Dù đã `if (pasted == null)
break;` ngay sau khi gán lần đầu, biến này còn bị gán lại (`pasted = next;`)
bên trong 1 vòng `while` phía sau (xử lý giao thức `SHOW_FILE:`) — trình
phân tích Dart THẬT không giữ được trạng thái "đã chắc chắn non-null" qua
lần gán lại trong vòng lặp (khác suy luận logic thông thường của người
đọc). Sửa: gán `pasted` sang 1 biến `final pastedNonNull` MỚI ngay trước
chỗ dùng, kèm 1 lần kiểm tra null nữa (thừa về logic vì chắc chắn không
null tại đó, nhưng cần để trình phân tích tĩnh hài lòng) — dùng
`pastedNonNull` cho `CodeZipExporter.extractFiles(...)`.

### 40.2. `dsl_document_builder.dart:70` — quên bọc `Map<String, dynamic>.from()` cho `block` khi truyền vào `_pythonResultToBlock`

Dòng 69 ĐÃ bọc đúng khi gọi `_runPython` (`Map<String, dynamic>.from(block)`)
nhưng dòng 70 gọi `_pythonResultToBlock(result, block, images)` lại truyền
THẲNG biến `block` gốc (kiểu `Map` không tham số kiểu, tức
`Map<dynamic, dynamic>` sau khi qua `if (block is! Map) continue;`) — trong
khi `_pythonResultToBlock` khai báo tham số kiểu `Map<String, dynamic>`.
Sửa: tính sẵn `final blockMap = Map<String, dynamic>.from(block);` 1 lần,
dùng `blockMap` cho CẢ 2 lệnh gọi (`_runPython` lẫn `_pythonResultToBlock`)
— vừa sửa lỗi kiểu, vừa gọn hơn (không tính `.from()` 2 lần cho cùng dữ
liệu).

### 40.3. Đã rà lại các chỗ tương tự trong CÙNG file để không lặp lỗi

Kiểm tra toàn bộ các chỗ có `if (x is! Map) continue;` rồi dùng `x` sau đó
trong `dsl_document_builder.dart`/`docx_export.dart`/`pptx_export.dart`/
`xlsx_export.dart`/`usage_service.dart` — CHỈ 2 chỗ trên bị thiếu bọc kiểu,
các chỗ còn lại (xử lý `img`/`slide`/`sheet` ở `buildPptx`/`buildXlsx`) đã
bọc `Map<String, dynamic>.from(...)` đúng từ trước, không cần sửa thêm.

### 40.4. Cảnh báo (KHÔNG phải lỗi, build vẫn qua được, chỉ ghi nhận)

Log còn 2 điều đáng chú ý nhưng KHÔNG làm build fail, chưa cần sửa ngay:
- `flutter_markdown 0.7.7+1 (discontinued replaced by flutter_markdown_plus)`
  — gói đã ngừng phát triển, có bản kế thừa `flutter_markdown_plus`. Vẫn
  cài/build được bình thường (chỉ là cảnh báo, không lỗi) — CHƯA đổi ngay
  vì đổi package đồng nghĩa phải viết lại `RunnableCodeBlockBuilder` (mục
  38) theo API mới, rủi ro hơn lợi ích lúc này. Nếu về sau
  `flutter_markdown` bị gỡ khỏi pub.dev hẳn (không chỉ "discontinued"),
  quay lại mục này để migrate.
- Cảnh báo KGP (Kotlin Gradle Plugin) từ `google_mlkit_commons`,
  `google_mlkit_text_recognition`, `share_plus` — Flutter cảnh báo các bản
  Flutter TƯƠNG LAI có thể fail build nếu plugin chưa migrate sang
  "Built-in Kotlin". Hiện KHÔNG fail, chỉ là cảnh báo dự phòng của chính
  Flutter — theo dõi thêm, chưa cần hành động.

### 40.5. CHƯA kiểm chứng

2 lỗi trên đã sửa ĐÚNG NGUYÊN NHÂN theo log thật (không phải đoán) — nhưng
CHƯA có lần build #3 xác nhận qua được hết. Nếu build tiếp tục fail, gửi
NGUYÊN VĂN log mới (kể cả khi lỗi trông giống lỗi cũ) — lỗi kiểu dữ liệu
Dart hay xuất hiện thành cụm nhiều lỗi cùng loại ở các file khác nhau, có
thể còn sót chỗ chưa lộ ra vì trình biên dịch dừng sớm ở lần build trước.
